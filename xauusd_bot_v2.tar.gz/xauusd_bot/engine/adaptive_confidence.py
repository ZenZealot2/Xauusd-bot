"""
engine/adaptive_confidence.py
==============================
Adaptive Confidence Engine.

Layer 1 — Historical Feedback:
  Tracks each component's contribution vs actual trade outcome (WIN/LOSS).
  Adjusts component weights every ADAPTIVE_LOOKBACK_SIGNALS signals.
  Components that historically predict wins get higher weights.
  Components that are uncorrelated get lower weights.

Layer 2 — ML Predictor (optional, scikit-learn):
  Trains a Logistic Regression on (component scores → WIN/LOSS) history.
  Once 30+ labelled signals accumulate, uses ML probability as the
  final confidence override.
  Model is persisted to disk and retrained incrementally.

Layer 3 — Regime filter:
  Tracks recent win rate. If < 40%, automatically raises the
  MIN_CONFIDENCE threshold and sends an admin alert.
"""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Optional

import numpy as np

from config.settings import (
    ADAPTIVE_CONFIDENCE_ENABLED,
    ADAPTIVE_LOOKBACK_SIGNALS,
    ML_CONFIDENCE_ENABLED,
    ML_MODEL_PATH,
    SCORE_WEIGHTS,
    GRADE_THRESHOLDS,
    MIN_CONFIDENCE_SCORE,
)
from database.operations import get_recent_signals
from utils.logger        import get_logger

logger = get_logger(__name__)

# ─── Optional ML import ───────────────────────────────────────────────────────
try:
    import joblib
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import Pipeline
    ML_AVAILABLE = True
except ImportError:
    ML_AVAILABLE = False
    logger.info("scikit-learn not installed — ML confidence disabled.")

# ─────────────────────────────────────────────────────────────────────────────
# Adaptive weights manager
# ─────────────────────────────────────────────────────────────────────────────

_weight_lock   = threading.Lock()
_current_weights: dict[str, float] = {k: float(v) for k, v in SCORE_WEIGHTS.items()}
_adaptive_min_confidence: int = MIN_CONFIDENCE_SCORE


def _load_signal_history(n: int = ADAPTIVE_LOOKBACK_SIGNALS) -> list[dict]:
    """Load recent closed signals from DB."""
    signals = get_recent_signals(limit=n * 3)   # fetch more, filter below
    closed  = [s for s in signals if s.get("status") in ("WIN", "LOSS", "BREAKEVEN")]
    return closed[-n:]


def _parse_score_breakdown(sig: dict) -> dict[str, int] | None:
    """Extract component score breakdown from signal dict (stored as analysis_json)."""
    import json as _json
    try:
        raw = sig.get("analysis_json", "{}")
        if isinstance(raw, str):
            data = _json.loads(raw)
        else:
            data = raw
        bd = data.get("score_breakdown") or sig.get("score_breakdown")
        if isinstance(bd, dict) and len(bd) >= 4:
            return bd
    except Exception:
        pass
    return None


def recalculate_adaptive_weights() -> dict[str, float]:
    """
    Re-compute dynamic weights based on component–outcome correlation
    over the last ADAPTIVE_LOOKBACK_SIGNALS closed signals.

    Algorithm:
      1. For each component, compute mean score in WIN trades and LOSS trades.
      2. Win contribution = mean_win_score / max_score.
      3. Loss contribution = mean_loss_score / max_score.
      4. Discriminative power = win_contrib − loss_contrib.
      5. New weight = base_weight × (1 + power_factor × discriminative_power).
         Clamped to [0.3 × base, 2.0 × base] to prevent wild swings.
      6. Normalise so total = MAX_SCORE (100).
    """
    global _current_weights, _adaptive_min_confidence

    history = _load_signal_history()
    if len(history) < 10:
        logger.debug(f"AdaptiveConf: only {len(history)} labelled signals — using default weights")
        return dict(SCORE_WEIGHTS)

    components = list(SCORE_WEIGHTS.keys())
    win_scores:  dict[str, list[float]] = {c: [] for c in components}
    loss_scores: dict[str, list[float]] = {c: [] for c in components}

    for sig in history:
        bd = _parse_score_breakdown(sig)
        if bd is None:
            continue
        outcome = sig.get("status", "")
        for comp in components:
            raw = bd.get(comp, 0)
            score = float(raw) if isinstance(raw, (int, float)) else 0.0
            if outcome == "WIN":
                win_scores[comp].append(score)
            elif outcome == "LOSS":
                loss_scores[comp].append(score)

    new_weights: dict[str, float] = {}
    total_base = float(sum(SCORE_WEIGHTS.values()))

    for comp in components:
        base_w = float(SCORE_WEIGHTS[comp])
        max_sc = float(SCORE_WEIGHTS[comp])

        w_mean = np.mean(win_scores[comp])  if win_scores[comp]  else base_w * 0.7
        l_mean = np.mean(loss_scores[comp]) if loss_scores[comp] else base_w * 0.5

        w_ratio = w_mean / max_sc if max_sc > 0 else 0.7
        l_ratio = l_mean / max_sc if max_sc > 0 else 0.5
        power   = w_ratio - l_ratio   # Positive = good predictor for wins

        # Dampen adjustment: 0.5 scaling factor
        factor = 1.0 + 0.5 * power
        factor = max(0.3, min(2.0, factor))   # Hard bounds

        new_weights[comp] = base_w * factor

    # Normalise so sum = 100
    w_sum = sum(new_weights.values())
    if w_sum > 0:
        scale = total_base / w_sum
        new_weights = {k: round(v * scale, 2) for k, v in new_weights.items()}

    # Adaptive threshold: if recent win rate < 40% → raise threshold
    wins   = sum(1 for s in history if s.get("status") == "WIN")
    total  = len([s for s in history if s.get("status") in ("WIN", "LOSS")])
    wr     = wins / total if total > 0 else 0.5

    old_min = _adaptive_min_confidence
    if wr < 0.40:
        _adaptive_min_confidence = min(85, MIN_CONFIDENCE_SCORE + 10)
        logger.warning(
            f"AdaptiveConf: Low win rate ({wr:.0%}) — raising threshold to "
            f"{_adaptive_min_confidence}"
        )
    elif wr > 0.60:
        _adaptive_min_confidence = max(65, MIN_CONFIDENCE_SCORE - 5)
    else:
        _adaptive_min_confidence = MIN_CONFIDENCE_SCORE

    with _weight_lock:
        _current_weights = new_weights

    logger.info(
        f"AdaptiveConf: weights recalculated from {len(history)} signals "
        f"(WR={wr:.0%} | threshold={_adaptive_min_confidence})"
    )
    logger.debug(f"AdaptiveConf: new weights = {new_weights}")

    return new_weights


def get_current_weights() -> dict[str, float]:
    """Return the current (possibly adaptive) weight dict."""
    with _weight_lock:
        return dict(_current_weights)


def get_adaptive_threshold() -> int:
    """Return the current adaptive minimum confidence threshold."""
    return _adaptive_min_confidence


# ─────────────────────────────────────────────────────────────────────────────
# ML confidence predictor
# ─────────────────────────────────────────────────────────────────────────────

_ml_pipeline: Optional[Any] = None   # sklearn Pipeline


def _build_feature_vector(score_breakdown: dict[str, int]) -> list[float]:
    """Convert score breakdown to ML feature vector (fixed order)."""
    keys = list(SCORE_WEIGHTS.keys())
    return [float(score_breakdown.get(k, 0)) for k in keys]


def train_ml_model(force: bool = False) -> bool:
    """
    Train / retrain the Logistic Regression model on all labelled history.
    Returns True if model was trained successfully.
    """
    global _ml_pipeline

    if not ML_AVAILABLE or not ML_CONFIDENCE_ENABLED:
        return False

    history = _load_signal_history(n=200)
    labelled = [(s, s.get("status")) for s in history if s.get("status") in ("WIN", "LOSS")]

    if len(labelled) < 20:
        logger.debug(f"ML model: only {len(labelled)} labelled samples — need 20+")
        return False

    X, y = [], []
    for sig, outcome in labelled:
        bd = _parse_score_breakdown(sig)
        if bd is None:
            continue
        X.append(_build_feature_vector(bd))
        y.append(1 if outcome == "WIN" else 0)

    if len(X) < 15:
        return False

    X = np.array(X)
    y = np.array(y)

    pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("clf",    LogisticRegression(
            C=1.0,
            class_weight="balanced",
            max_iter=500,
            random_state=42,
        )),
    ])

    try:
        pipeline.fit(X, y)
        _ml_pipeline = pipeline

        # Persist model
        ML_MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(pipeline, ML_MODEL_PATH)

        # Accuracy estimate (in-sample, rough)
        preds = pipeline.predict(X)
        acc   = float((preds == y).mean())
        logger.info(
            f"ML model: trained on {len(X)} samples | "
            f"in-sample accuracy={acc:.1%}"
        )
        return True
    except Exception as exc:
        logger.error(f"ML model training failed: {exc}")
        return False


def load_ml_model() -> bool:
    """Load persisted ML model from disk."""
    global _ml_pipeline
    if not ML_AVAILABLE or not ML_CONFIDENCE_ENABLED:
        return False
    if not ML_MODEL_PATH.exists():
        return False
    try:
        _ml_pipeline = joblib.load(ML_MODEL_PATH)
        logger.info(f"ML model loaded from {ML_MODEL_PATH}")
        return True
    except Exception as exc:
        logger.warning(f"Failed to load ML model: {exc}")
        return False


def predict_ml_confidence(score_breakdown: dict[str, int]) -> Optional[float]:
    """
    Use the ML model to predict win probability (0.0 – 1.0).
    Returns None if model is not available.
    """
    global _ml_pipeline
    if not ML_AVAILABLE or not ML_CONFIDENCE_ENABLED or _ml_pipeline is None:
        if ML_MODEL_PATH.exists():
            load_ml_model()
        if _ml_pipeline is None:
            return None

    try:
        fv = np.array([_build_feature_vector(score_breakdown)])
        proba = _ml_pipeline.predict_proba(fv)[0]
        win_prob = float(proba[1])   # class 1 = WIN
        return win_prob
    except Exception as exc:
        logger.debug(f"ML predict error: {exc}")
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Composite confidence calculation
# ─────────────────────────────────────────────────────────────────────────────

def calculate_adaptive_score(
    component_raw_scores: dict[str, int],
    score_breakdown: dict[str, int],
) -> tuple[int, str]:
    """
    Compute the final adaptive confidence score.

    Priority:
      1. If ML model available AND predicts well → blend ML + rule-based
      2. If adaptive weights recalculated → use adaptive weights
      3. Otherwise → use base weights (original rule-based)

    Returns (final_score: int, method: str).
    """
    if not ADAPTIVE_CONFIDENCE_ENABLED:
        raw = sum(component_raw_scores.values())
        return min(raw, 100), "rule-based"

    # Adaptive weight-based score
    weights = get_current_weights()
    w_total = sum(weights.values()) or 100.0

    adaptive_score = 0.0
    for comp, raw_score in component_raw_scores.items():
        base_max = float(SCORE_WEIGHTS.get(comp, 5))
        w        = float(weights.get(comp, base_max))
        # Normalise raw_score relative to its component max
        contrib = (raw_score / base_max) * w if base_max > 0 else 0
        adaptive_score += contrib

    # Rescale to 0-100
    adaptive_score = min((adaptive_score / w_total) * 100.0, 100.0)
    method = "adaptive-weights"

    # ML blend (if available)
    ml_prob = predict_ml_confidence(score_breakdown)
    if ml_prob is not None:
        ml_score      = ml_prob * 100.0
        # Blend: 60% adaptive weights, 40% ML
        adaptive_score = 0.60 * adaptive_score + 0.40 * ml_score
        method        = "adaptive-weights+ML"
        logger.debug(f"AdaptiveConf: ML win_prob={ml_prob:.2%} blended score={adaptive_score:.1f}")

    return int(round(adaptive_score)), method


# ─────────────────────────────────────────────────────────────────────────────
# Initialisation
# ─────────────────────────────────────────────────────────────────────────────

def initialise() -> None:
    """Call at startup to load/train the adaptive engine."""
    if ADAPTIVE_CONFIDENCE_ENABLED:
        recalculate_adaptive_weights()

    if ML_CONFIDENCE_ENABLED and ML_AVAILABLE:
        if not load_ml_model():
            train_ml_model()
