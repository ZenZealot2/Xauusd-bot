"""
analysis/session.py
===================
Detects the current Forex trading session based on UTC time.

Sessions (UTC):
  Asian:       00:00 – 09:00   Low liquidity for Gold
  London:      07:00 – 16:00   High liquidity, best for scalping Gold
  New York:    13:00 – 22:00   High liquidity, big moves
  Overlap:     13:00 – 16:00   London + NY overlap — maximum liquidity

Best signal quality:
  1. London-NY Overlap (13:00–16:00 UTC)
  2. London Open     (07:00–10:00 UTC)
  3. NY Open         (13:00–16:00 UTC)
  4. Rest of London / NY session
  5. Asian session (avoid)

Score contribution: max 5 points.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

import pytz

from config.settings import SESSIONS, SCORE_WEIGHTS
from utils.helpers import now_utc, utc_hour, utc_weekday, is_forex_weekend
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SessionResult:
    current_session: str      # 'Asian' | 'London' | 'NewYork' | 'Overlap' | 'Closed'
    is_overlap:      bool
    is_london_open:  bool     # First 3 hours of London session
    is_ny_open:      bool     # First 3 hours of NY session
    is_high_quality: bool     # True = London or NY or Overlap
    is_weekend:      bool
    utc_hour:        int
    description:     str
    score:           int
    reasons:         list[str]


# ─────────────────────────────────────────────────────────────────────────────
# Session detection
# ─────────────────────────────────────────────────────────────────────────────

def get_active_session(hour: int | None = None) -> str:
    """
    Determine the primary trading session for the given UTC hour.
    Priority: Overlap > London > NewYork > Asian > Closed
    """
    h = hour if hour is not None else utc_hour()

    # Weekend check
    if is_forex_weekend():
        return "Closed"

    london_s  = SESSIONS["London"]["start"]
    london_e  = SESSIONS["London"]["end"]
    ny_s      = SESSIONS["NewYork"]["start"]
    ny_e      = SESSIONS["NewYork"]["end"]
    overlap_s = SESSIONS["Overlap"]["start"]
    overlap_e = SESSIONS["Overlap"]["end"]

    in_london  = london_s  <= h < london_e
    in_ny      = ny_s      <= h < ny_e
    in_overlap = overlap_s <= h < overlap_e

    if in_overlap:
        return "Overlap"
    elif in_london:
        return "London"
    elif in_ny:
        return "NewYork"
    elif 0 <= h < 9:
        return "Asian"
    else:
        return "Closed"


def _is_london_open_window(h: int) -> bool:
    """London open: first 3 hours (07:00–10:00 UTC)."""
    lo = SESSIONS["London"].get("open", 7)
    return lo <= h < lo + 3


def _is_ny_open_window(h: int) -> bool:
    """NY open: first 3 hours (13:00–16:00 UTC, but before overlap ends)."""
    ny = SESSIONS["NewYork"].get("open", 13)
    return ny <= h < ny + 3


# ─────────────────────────────────────────────────────────────────────────────
# Quality assessment
# ─────────────────────────────────────────────────────────────────────────────

SESSION_DESCRIPTIONS = {
    "Overlap": "🌍 London–NY Overlap — maximum institutional activity",
    "London":  "🇬🇧 London Session — high volatility for Gold",
    "NewYork": "🇺🇸 New York Session — significant Gold moves",
    "Asian":   "🌏 Asian Session — low liquidity (Gold trades thin)",
    "Closed":  "⛔ Market Closed (weekend)",
}


def session_quality_score(session: str, is_overlap: bool, is_open: bool) -> int:
    """
    Map session to score points:
      Overlap      → 5
      London/NY open → 4
      London/NY    → 3
      Asian        → 1
      Closed       → 0
    """
    if session == "Closed":
        return 0
    if is_overlap:
        return 5
    if is_open:
        return 4
    if session in ("London", "NewYork"):
        return 3
    if session == "Asian":
        return 1
    return 2


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_session() -> SessionResult:
    """
    Detect the current trading session and assign a quality score.
    """
    score   = 0
    reasons: list[str] = []
    max_score = SCORE_WEIGHTS["session_quality"]  # 5

    h = utc_hour()
    weekend = is_forex_weekend()

    session    = get_active_session(h)
    is_overlap = (session == "Overlap")
    is_lo      = _is_london_open_window(h) and not weekend
    is_ny      = _is_ny_open_window(h)     and not weekend
    is_high    = session in ("Overlap", "London", "NewYork") and not weekend

    desc = SESSION_DESCRIPTIONS.get(session, "Unknown session")

    # ── Scoring ──────────────────────────────────────────────────────────────
    raw_score = session_quality_score(session, is_overlap, is_lo or is_ny)
    score     = min(raw_score, max_score)

    if weekend:
        reasons.append("Market closed (weekend) — no signal")
    elif is_overlap:
        reasons.append("London–NY Overlap — maximum liquidity ✅")
    elif is_lo:
        reasons.append("London Open (07:00–10:00 UTC) — high volatility ✅")
    elif is_ny:
        reasons.append("NY Open (13:00–16:00 UTC) — institutional activity ✅")
    elif session == "London":
        reasons.append("London Session — good liquidity")
    elif session == "NewYork":
        reasons.append("New York Session — good liquidity")
    elif session == "Asian":
        reasons.append("Asian Session — low liquidity, avoid Gold scalps ⚠️")

    logger.debug(
        f"Session | hour={h}UTC session={session} overlap={is_overlap} "
        f"lo={is_lo} ny={is_ny} score={score}/{max_score}"
    )

    return SessionResult(
        current_session=session,
        is_overlap=is_overlap,
        is_london_open=is_lo,
        is_ny_open=is_ny,
        is_high_quality=is_high,
        is_weekend=weekend,
        utc_hour=h,
        description=desc,
        score=score,
        reasons=reasons,
    )
