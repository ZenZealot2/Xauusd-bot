"""
database/operations.py
======================
All CRUD operations for the application.
Provides a thread-safe connection factory and typed helper functions.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, date
from pathlib import Path
from typing import Any, Generator

from config.settings import DB_PATH
from database.models import create_tables, seed_default_settings
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Connection management
# ─────────────────────────────────────────────────────────────────────────────

def get_connection() -> sqlite3.Connection:
    """Return a new SQLite connection with row_factory set to Row."""
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn


@contextmanager
def db_conn() -> Generator[sqlite3.Connection, None, None]:
    """Context manager that auto-commits or rolls back."""
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_database() -> None:
    """Initialise the database — call once at startup."""
    conn = get_connection()
    try:
        create_tables(conn)
        seed_default_settings(conn)
        logger.info(f"Database initialised at {DB_PATH}")
    finally:
        conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# User operations
# ─────────────────────────────────────────────────────────────────────────────

def upsert_user(
    telegram_id: int,
    username: str | None = None,
    first_name: str | None = None,
    last_name: str | None = None,
) -> dict:
    """
    Create user if not exists, otherwise update last_seen_at.
    Returns the user row as a dict.
    """
    with db_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO users (telegram_id, username, first_name, last_name)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(telegram_id) DO UPDATE SET
                username      = excluded.username,
                first_name    = excluded.first_name,
                last_name     = excluded.last_name,
                last_seen_at  = datetime('now')
            """,
            (telegram_id, username, first_name, last_name),
        )
        row = cursor.execute(
            "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        return dict(row) if row else {}


def get_user(telegram_id: int) -> dict | None:
    with db_conn() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        return dict(row) if row else None


def get_all_active_users() -> list[dict]:
    with db_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM users WHERE is_active = 1 AND is_banned = 0"
        ).fetchall()
        return [dict(r) for r in rows]


def get_all_users() -> list[dict]:
    with db_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM users ORDER BY created_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]


def count_users() -> dict:
    with db_conn() as conn:
        total   = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        active  = conn.execute("SELECT COUNT(*) FROM users WHERE is_active=1 AND is_banned=0").fetchone()[0]
        premium = conn.execute("SELECT COUNT(*) FROM users WHERE is_premium=1").fetchone()[0]
        return {"total": total, "active": active, "premium": premium}


def ban_user(telegram_id: int) -> None:
    with db_conn() as conn:
        conn.execute(
            "UPDATE users SET is_banned=1 WHERE telegram_id=?", (telegram_id,)
        )


def unban_user(telegram_id: int) -> None:
    with db_conn() as conn:
        conn.execute(
            "UPDATE users SET is_banned=0 WHERE telegram_id=?", (telegram_id,)
        )


def set_premium(telegram_id: int, is_premium: bool = True) -> None:
    with db_conn() as conn:
        conn.execute(
            "UPDATE users SET is_premium=? WHERE telegram_id=?",
            (1 if is_premium else 0, telegram_id),
        )


def increment_user_signals_today(telegram_id: int) -> None:
    today = date.today().isoformat()
    with db_conn() as conn:
        user = conn.execute(
            "SELECT last_signal_date, signals_today FROM users WHERE telegram_id=?",
            (telegram_id,),
        ).fetchone()
        if user:
            if user["last_signal_date"] != today:
                conn.execute(
                    "UPDATE users SET signals_today=1, last_signal_date=? WHERE telegram_id=?",
                    (today, telegram_id),
                )
            else:
                conn.execute(
                    "UPDATE users SET signals_today=signals_today+1 WHERE telegram_id=?",
                    (telegram_id,),
                )


def get_user_signals_today(telegram_id: int) -> int:
    today = date.today().isoformat()
    with db_conn() as conn:
        row = conn.execute(
            "SELECT signals_today, last_signal_date FROM users WHERE telegram_id=?",
            (telegram_id,),
        ).fetchone()
        if row and row["last_signal_date"] == today:
            return row["signals_today"]
        return 0


# ─────────────────────────────────────────────────────────────────────────────
# Signal operations
# ─────────────────────────────────────────────────────────────────────────────

def save_signal(signal: dict[str, Any]) -> int:
    """
    Persist a signal to the database.
    Returns the new signal row id.
    """
    reasons = signal.get("reasons", [])
    reasons_json = json.dumps(reasons) if isinstance(reasons, list) else reasons

    analysis = signal.get("analysis", {})
    analysis_json = json.dumps(analysis) if isinstance(analysis, dict) else "{}"

    with db_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO signals
                (direction, entry, stop_loss, tp1, tp2, tp3,
                 confidence, grade, classification, trend, session,
                 rr_ratio, reasons, analysis_json, chart_path)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                signal.get("direction"),
                signal.get("entry"),
                signal.get("stop_loss"),
                signal.get("tp1"),
                signal.get("tp2"),
                signal.get("tp3"),
                signal.get("confidence"),
                signal.get("grade"),
                signal.get("classification"),
                signal.get("trend"),
                signal.get("session"),
                signal.get("rr_ratio"),
                reasons_json,
                analysis_json,
                signal.get("chart_path"),
            ),
        )
        return cursor.lastrowid  # type: ignore[return-value]


def record_signal_sent(signal_id: int, user_id_db: int) -> None:
    """Record that a signal was sent to a specific user."""
    with db_conn() as conn:
        conn.execute(
            "INSERT INTO signal_recipients (signal_id, user_id) VALUES (?, ?)",
            (signal_id, user_id_db),
        )


def update_signal_result(
    signal_id: int,
    status: str,
    result_tp: int = 0,
    result_pips: float = 0.0,
) -> None:
    """Update signal outcome: WIN | LOSS | BREAKEVEN | EXPIRED."""
    with db_conn() as conn:
        conn.execute(
            """
            UPDATE signals
            SET status=?, result_tp=?, result_pips=?, closed_at=datetime('now')
            WHERE id=?
            """,
            (status.upper(), result_tp, result_pips, signal_id),
        )


def get_recent_signals(limit: int = 10) -> list[dict]:
    with db_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM signals ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_pending_signals() -> list[dict]:
    with db_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM signals WHERE status='PENDING' ORDER BY created_at ASC"
        ).fetchall()
        return [dict(r) for r in rows]


def count_signals_today() -> int:
    today = date.today().isoformat()
    with db_conn() as conn:
        result = conn.execute(
            "SELECT COUNT(*) FROM signals WHERE created_at LIKE ?",
            (f"{today}%",),
        ).fetchone()
        return result[0] if result else 0


def get_last_signal_direction() -> str | None:
    """Returns the direction of the most recent signal (prevents duplicate same-dir signals)."""
    with db_conn() as conn:
        row = conn.execute(
            "SELECT direction FROM signals ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        return row["direction"] if row else None


# ─────────────────────────────────────────────────────────────────────────────
# Performance / statistics
# ─────────────────────────────────────────────────────────────────────────────

def calculate_statistics(period: str = "all") -> dict:
    """
    Calculate win rate, profit factor, etc.

    period: 'daily' | 'weekly' | 'monthly' | 'all'
    """
    where_clause = "WHERE status != 'PENDING'"
    today = date.today().isoformat()

    if period == "daily":
        where_clause += f" AND created_at LIKE '{today}%'"
    elif period == "weekly":
        # Last 7 days
        where_clause += " AND created_at >= datetime('now', '-7 days')"
    elif period == "monthly":
        # This calendar month
        month = today[:7]
        where_clause += f" AND created_at LIKE '{month}%'"

    with db_conn() as conn:
        total = conn.execute(
            f"SELECT COUNT(*) FROM signals {where_clause}"
        ).fetchone()[0]

        wins = conn.execute(
            f"SELECT COUNT(*) FROM signals {where_clause} AND status='WIN'"
        ).fetchone()[0]

        losses = conn.execute(
            f"SELECT COUNT(*) FROM signals {where_clause} AND status='LOSS'"
        ).fetchone()[0]

        be = conn.execute(
            f"SELECT COUNT(*) FROM signals {where_clause} AND status='BREAKEVEN'"
        ).fetchone()[0]

        pending = conn.execute(
            "SELECT COUNT(*) FROM signals WHERE status='PENDING'"
        ).fetchone()[0]

        avg_rr = conn.execute(
            f"SELECT AVG(rr_ratio) FROM signals {where_clause}"
        ).fetchone()[0] or 0.0

        total_pips = conn.execute(
            f"SELECT COALESCE(SUM(result_pips), 0) FROM signals {where_clause}"
        ).fetchone()[0]

        # Profit factor = gross wins / gross losses (in pips)
        gross_win = conn.execute(
            f"SELECT COALESCE(SUM(result_pips), 0) FROM signals {where_clause} AND result_pips > 0"
        ).fetchone()[0]

        gross_loss = abs(conn.execute(
            f"SELECT COALESCE(SUM(result_pips), 0) FROM signals {where_clause} AND result_pips < 0"
        ).fetchone()[0])

        profit_factor = round(gross_win / gross_loss, 2) if gross_loss > 0 else (float("inf") if gross_win > 0 else 0.0)

        win_rate = round((wins / total) * 100, 1) if total > 0 else 0.0

        best = conn.execute(
            f"SELECT direction, entry, confidence FROM signals "
            f"{where_clause} AND status='WIN' ORDER BY result_pips DESC LIMIT 1"
        ).fetchone()

        best_signal = (
            f"{best['direction']} @ {best['entry']} ({best['confidence']}%)" if best else "N/A"
        )

    return {
        "total_signals":  total,
        "wins":           wins,
        "losses":         losses,
        "break_evens":    be,
        "pending":        pending,
        "win_rate":       win_rate,
        "profit_factor":  profit_factor,
        "avg_rr":         round(avg_rr, 2),
        "total_pips":     round(total_pips, 1),
        "best_signal":    best_signal,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Settings operations
# ─────────────────────────────────────────────────────────────────────────────

def get_setting(key: str, default: str = "") -> str:
    with db_conn() as conn:
        row = conn.execute(
            "SELECT value FROM settings WHERE key=?", (key,)
        ).fetchone()
        return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    with db_conn() as conn:
        conn.execute(
            """
            INSERT INTO settings (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')
            """,
            (key, value),
        )


# ─────────────────────────────────────────────────────────────────────────────
# Error logging
# ─────────────────────────────────────────────────────────────────────────────

def log_error(module: str, message: str, traceback: str = "") -> None:
    with db_conn() as conn:
        conn.execute(
            "INSERT INTO error_log (module, message, traceback) VALUES (?, ?, ?)",
            (module, message, traceback),
        )


def get_recent_errors(limit: int = 20) -> list[dict]:
    with db_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM error_log ORDER BY logged_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def count_errors_today() -> int:
    today = date.today().isoformat()
    with db_conn() as conn:
        result = conn.execute(
            "SELECT COUNT(*) FROM error_log WHERE logged_at LIKE ?",
            (f"{today}%",),
        ).fetchone()
        return result[0] if result else 0


# ─────────────────────────────────────────────────────────────────────────────
# Backtest runs
# ─────────────────────────────────────────────────────────────────────────────

def save_backtest_run(result: dict[str, Any]) -> int:
    with db_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO backtest_runs
                (start_date, end_date, total_trades, win_rate,
                 profit_factor, max_drawdown, net_pips, report_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                result.get("start_date"),
                result.get("end_date"),
                result.get("total_trades", 0),
                result.get("win_rate", 0.0),
                result.get("profit_factor", 0.0),
                result.get("max_drawdown", 0.0),
                result.get("net_pips", 0.0),
                json.dumps(result.get("report", {})),
            ),
        )
        return cursor.lastrowid  # type: ignore[return-value]


def get_backtest_runs(limit: int = 10) -> list[dict]:
    with db_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM backtest_runs ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
