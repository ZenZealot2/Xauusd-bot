"""
main.py
=======
Application entry point — updated to initialise adaptive confidence engine,
validate data source, and connect MT5 if enabled.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from telegram.ext import Application

from config.settings import (
    TELEGRAM_BOT_TOKEN, LOG_LEVEL, LOG_FILE, DB_PATH,
    AUTO_TRADE_ENABLED, DATA_SOURCE, ADAPTIVE_CONFIDENCE_ENABLED,
)
from database.operations import init_database
from utils.logger        import setup_logging, get_logger
from scheduler.jobs      import register_jobs

from bot.handlers.start   import get_handlers as start_handlers
from bot.handlers.signals import get_handlers as signal_handlers
from bot.handlers.stats   import get_handlers as stats_handlers
from bot.handlers.admin   import get_handlers as admin_handlers

logger = get_logger(__name__)


def _startup_checks() -> None:
    """Verify configuration and warm up subsystems."""

    # 1. Test data source
    logger.info(f"Data source: {DATA_SOURCE.upper()}")
    try:
        from engine.data_fetcher import get_ohlcv, validate_dataframe, get_data_source_info
        df = get_ohlcv("M15", force_refresh=True)
        if validate_dataframe(df, min_bars=10):
            price = float(df["close"].iloc[-1])
            logger.info(
                f"✅ Data source OK: {get_data_source_info()} "
                f"| Latest XAUUSD: ${price:.2f}"
            )
        else:
            logger.warning("⚠️ Data source returned insufficient data — check API key / connection")
    except Exception as exc:
        logger.error(f"❌ Data source check failed: {exc}")

    # 2. Adaptive confidence engine
    if ADAPTIVE_CONFIDENCE_ENABLED:
        logger.info("Initialising adaptive confidence engine…")
        try:
            from engine.adaptive_confidence import initialise
            initialise()
            logger.info("✅ Adaptive confidence engine ready.")
        except Exception as exc:
            logger.warning(f"Adaptive confidence init failed (non-fatal): {exc}")

    # 3. MT5 auto-trader
    if AUTO_TRADE_ENABLED:
        logger.info("Connecting to MetaTrader 5…")
        try:
            from engine.auto_trader import connect, get_account_summary
            if connect():
                acc = get_account_summary()
                logger.info(
                    f"✅ MT5 connected | Account #{acc.get('login')} "
                    f"| Balance: {acc.get('balance'):.2f} {acc.get('currency')}"
                )
            else:
                logger.warning("⚠️ MT5 connection failed — auto-trading disabled for this session")
        except Exception as exc:
            logger.error(f"MT5 startup error: {exc}")

    # 4. Pre-warm news cache
    try:
        from analysis.news_filter import get_cached_events
        events = get_cached_events(force_refresh=True)
        logger.info(f"✅ News cache loaded: {len(events)} events")
    except Exception as exc:
        logger.warning(f"News cache pre-warm failed: {exc}")


def build_application() -> Application:
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    for handler in (
        start_handlers()
        + signal_handlers()
        + stats_handlers()
        + admin_handlers()
    ):
        app.add_handler(handler)

    register_jobs(app)
    return app


def main() -> None:
    setup_logging(log_level=LOG_LEVEL, log_file=LOG_FILE)

    logger.info("=" * 60)
    logger.info("  XAUUSD AI Signal Bot v2.0 — Starting Up")
    logger.info("=" * 60)

    logger.info(f"Database: {DB_PATH}")
    init_database()
    logger.info("✅ Database ready.")

    _startup_checks()

    logger.info("Building Telegram application…")
    app = build_application()
    logger.info("✅ Bot ready. Starting polling…")

    app.run_polling(
        poll_interval=1.0,
        timeout=30,
        drop_pending_updates=True,
        allowed_updates=["message", "callback_query"],
    )


if __name__ == "__main__":
    main()
