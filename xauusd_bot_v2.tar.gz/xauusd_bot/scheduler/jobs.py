"""
scheduler/jobs.py
=================
Updated jobs:
  1. scan_for_signal        — every SIGNAL_INTERVAL_MINUTES
  2. run_tracker            — every 5 min (outcome auto-close)
  3. manage_auto_trades     — every 1 min (BE + trailing, if MT5 enabled)
  4. daily_report           — 22:00 UTC
  5. refresh_news           — every 60 min
  6. recalibrate_confidence — every 6 hours (adaptive weight refresh + ML retrain)
"""

from __future__ import annotations

import traceback
from datetime import time as dt_time

from telegram.ext import Application, ContextTypes
from telegram.constants import ParseMode

from engine.signal_generator     import generate_signal
from performance.tracker         import run_tracker
from database.operations         import calculate_statistics, count_signals_today, log_error
from analysis.news_filter        import get_cached_events
from utils.helpers               import is_forex_weekend
from utils.logger                import get_logger
from config.settings             import SIGNAL_INTERVAL_MINUTES, ADMIN_CHAT_IDS, AUTO_TRADE_ENABLED

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────

async def job_scan_signal(context: ContextTypes.DEFAULT_TYPE) -> None:
    if is_forex_weekend():
        logger.debug("Scheduler: weekend — skipping scan")
        return

    logger.info("Scheduler: signal scan…")
    try:
        signal = generate_signal()
        if signal is None:
            return

        from bot.handlers.signals import broadcast_signal
        result = await broadcast_signal(signal, context)
        logger.info(
            f"Scheduler: signal #{signal.get('id')} broadcast — "
            f"sent={result['sent']} failed={result['failed']}"
        )
    except Exception as exc:
        tb = traceback.format_exc()
        logger.error(f"Scheduler: job_scan_signal error: {exc}")
        log_error("scheduler.scan", str(exc), tb)


async def job_run_tracker(context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        result = run_tracker()
        if result["closed"] > 0:
            logger.info(
                f"Scheduler: tracker closed {result['closed']} signal(s) | "
                f"W={result.get('wins',0)} L={result.get('losses',0)} "
                f"open_pnl={result.get('open_pnl',0):+.1f}p"
            )
    except Exception as exc:
        logger.error(f"Scheduler: job_run_tracker error: {exc}")


async def job_manage_auto_trades(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Run break-even and trailing stop management for MT5 open positions."""
    if not AUTO_TRADE_ENABLED:
        return
    try:
        from engine.auto_trader import manage_open_positions, is_connected
        if not is_connected():
            return
        result = manage_open_positions()
        if result["be_moved"] + result["trailing_updated"] > 0:
            logger.info(
                f"Scheduler: AutoTrade mgmt | "
                f"BE_moved={result['be_moved']} trailing={result['trailing_updated']}"
            )
    except Exception as exc:
        logger.error(f"Scheduler: job_manage_auto_trades error: {exc}")


async def job_daily_report(context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        stats = calculate_statistics("daily")
        from engine.adaptive_confidence import get_adaptive_threshold
        threshold = get_adaptive_threshold()

        text = (
            f"📊 <b>Daily Report</b>\n"
            f"{'─' * 30}\n"
            f"Signals   : {stats.get('total_signals', 0)}\n"
            f"Win Rate  : {stats.get('win_rate', 0):.1f}%\n"
            f"Net Pips  : {stats.get('total_pips', 0):+.1f}\n"
            f"Prof. Fac : {stats.get('profit_factor', 0):.2f}\n"
            f"Threshold : {threshold} (adaptive)\n"
        )

        for admin_id in ADMIN_CHAT_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id, text=text, parse_mode=ParseMode.HTML,
                )
            except Exception as exc:
                logger.warning(f"Scheduler: daily report to {admin_id} failed: {exc}")
    except Exception as exc:
        logger.error(f"Scheduler: job_daily_report error: {exc}")


async def job_refresh_news(context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        events = get_cached_events(force_refresh=True)
        logger.debug(f"Scheduler: news cache refreshed ({len(events)} events)")
    except Exception as exc:
        logger.warning(f"Scheduler: news refresh failed: {exc}")


async def job_recalibrate_confidence(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Periodically recalibrate adaptive weights and retrain ML model."""
    try:
        from engine.adaptive_confidence import recalculate_adaptive_weights, train_ml_model
        weights = recalculate_adaptive_weights()
        trained = train_ml_model()
        logger.info(
            f"Scheduler: confidence recalibrated | "
            f"ML_trained={trained}"
        )
    except Exception as exc:
        logger.error(f"Scheduler: job_recalibrate_confidence error: {exc}")


# ─────────────────────────────────────────────────────────────────────────────

def register_jobs(app: Application) -> None:
    jq = app.job_queue

    jq.run_repeating(job_scan_signal, interval=SIGNAL_INTERVAL_MINUTES * 60,
                     first=30, name="scan_signal")
    logger.info(f"Scheduler: signal scan every {SIGNAL_INTERVAL_MINUTES} min")

    jq.run_repeating(job_run_tracker, interval=5 * 60,
                     first=60, name="run_tracker")
    logger.info("Scheduler: tracker every 5 min")

    if AUTO_TRADE_ENABLED:
        jq.run_repeating(job_manage_auto_trades, interval=60,
                         first=90, name="manage_auto_trades")
        logger.info("Scheduler: MT5 position management every 1 min")

    jq.run_daily(job_daily_report, time=dt_time(22, 0), name="daily_report")
    logger.info("Scheduler: daily report at 22:00 UTC")

    jq.run_repeating(job_refresh_news, interval=60 * 60,
                     first=10, name="refresh_news")
    logger.info("Scheduler: news refresh every 60 min")

    jq.run_repeating(job_recalibrate_confidence, interval=6 * 3600,
                     first=120, name="recalibrate_confidence")
    logger.info("Scheduler: adaptive recalibration every 6h")

    logger.info("All scheduler jobs registered.")
