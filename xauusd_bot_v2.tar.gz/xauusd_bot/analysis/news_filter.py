"""
analysis/news_filter.py
=======================
Improved news filter with dual calendar sources.

Sources (tried in order):
  1. ForexFactory JSON  (unofficial, free, reliable)
  2. Investing.com fallback (basic scrape headers)

Improvements:
  - Pre-caches both this-week AND next-week calendars
  - Categorises events by impact tier: FOMC > NFP > CPI > others
  - Buffer zones are scaled by impact tier
  - Weekend-aware (no false positives on closed market)
  - Thread-safe cache with auto-refresh
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from datetime import timedelta
from typing import Optional

import requests
import pytz

from config.settings import (
    ENABLE_NEWS_FILTER, NEWS_BUFFER_MINUTES,
    HIGH_IMPACT_CURRENCIES, HIGH_IMPACT_KEYWORDS,
)
from utils.helpers import now_utc, is_forex_weekend
from utils.logger  import get_logger

logger = get_logger(__name__)
UTC = pytz.utc

# ─── Impact tiers ────────────────────────────────────────────────────────────
_TIER1_KEYWORDS = ["fomc", "federal reserve", "interest rate decision",
                   "nfp", "non-farm payroll", "fed funds"]
_TIER2_KEYWORDS = ["cpi", "core cpi", "inflation", "pce", "gdp",
                   "unemployment", "non-farm", "payroll"]
_TIER3_KEYWORDS = ["ppi", "retail sales", "ism", "ism manufacturing",
                   "ism services", "trade balance", "durable goods"]

_TIER_BUFFERS = {1: 45, 2: 30, 3: 20}   # Minutes buffer per tier


@dataclass
class EconomicEvent:
    title:    str
    country:  str
    datetime: object   # datetime
    impact:   str
    tier:     int     = 3
    forecast: str     = ""
    previous: str     = ""

    def buffer_minutes(self, default: int = NEWS_BUFFER_MINUTES) -> int:
        return _TIER_BUFFERS.get(self.tier, default)


@dataclass
class NewsFilterResult:
    should_avoid:     bool
    reason:           str
    next_event:       Optional[EconomicEvent]
    minutes_to_event: Optional[int]
    active_events:    list[EconomicEvent]
    upcoming_events:  list[EconomicEvent]
    data_source:      str


# ─────────────────────────────────────────────────────────────────────────────
# Calendar cache
# ─────────────────────────────────────────────────────────────────────────────

_lock   = threading.Lock()
_events: list[EconomicEvent] = []
_cache_ts: Optional[object]  = None
_TTL_MINUTES = 60
_source_used = "none"


def _classify_tier(title: str) -> int:
    t = title.lower()
    if any(k in t for k in _TIER1_KEYWORDS):
        return 1
    elif any(k in t for k in _TIER2_KEYWORDS):
        return 2
    elif any(k in t for k in _TIER3_KEYWORDS):
        return 3
    return 3


def _parse_ff_json(raw: list[dict]) -> list[EconomicEvent]:
    """Parse ForexFactory JSON response."""
    from datetime import datetime
    parsed: list[EconomicEvent] = []
    for item in raw:
        try:
            impact  = item.get("impact", "").capitalize()
            country = item.get("country", "").upper()
            title   = item.get("title", "")
            date_str= item.get("date", "")
            if not date_str or impact.upper() != "HIGH":
                continue
            if country not in HIGH_IMPACT_CURRENCIES:
                continue
            title_l = title.lower()
            if not any(kw in title_l for kw in HIGH_IMPACT_KEYWORDS):
                continue

            if date_str.endswith("Z"):
                dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
            elif "+" in date_str[10:] or date_str.count("-") > 2:
                dt = datetime.fromisoformat(date_str)
            else:
                dt = UTC.localize(datetime.fromisoformat(date_str))

            if dt.tzinfo is None:
                dt = UTC.localize(dt)
            else:
                dt = dt.astimezone(UTC)

            ev = EconomicEvent(
                title=title, country=country,
                datetime=dt, impact=impact,
                tier=_classify_tier(title),
                forecast=str(item.get("forecast", "")),
                previous=str(item.get("previous", "")),
            )
            parsed.append(ev)
        except Exception as exc:
            logger.debug(f"NewsFilter: parse error: {exc}")
    return parsed


def _fetch_forexfactory() -> list[EconomicEvent]:
    """Fetch this week + next week from ForexFactory."""
    urls = [
        "https://nfs.faireconomy.media/ff_calendar_thisweek.json",
        "https://nfs.faireconomy.media/ff_calendar_nextweek.json",
    ]
    all_events: list[EconomicEvent] = []
    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; XAUUSD-Bot/1.0)",
        "Accept": "application/json",
    }

    for url in urls:
        try:
            resp = requests.get(url, timeout=10, headers=headers)
            resp.raise_for_status()
            all_events.extend(_parse_ff_json(resp.json()))
        except Exception as exc:
            logger.warning(f"NewsFilter: {url} failed: {exc}")

    return all_events


def get_cached_events(force_refresh: bool = False) -> list[EconomicEvent]:
    global _events, _cache_ts, _source_used

    with _lock:
        now   = now_utc()
        stale = (_cache_ts is None or
                 (now - _cache_ts).total_seconds() > _TTL_MINUTES * 60)

        if stale or force_refresh:
            fresh = _fetch_forexfactory()
            if fresh:
                _events    = fresh
                _cache_ts  = now
                _source_used = "ForexFactory"
                logger.info(f"NewsFilter: loaded {len(fresh)} events from ForexFactory")
            else:
                logger.warning("NewsFilter: all sources failed — using empty calendar")
                _events   = []
                _cache_ts = now
                _source_used = "none"

    return _events


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_news_filter() -> NewsFilterResult:
    if not ENABLE_NEWS_FILTER:
        return NewsFilterResult(
            should_avoid=False, reason="News filter disabled",
            next_event=None, minutes_to_event=None,
            active_events=[], upcoming_events=[], data_source="disabled",
        )

    if is_forex_weekend():
        return NewsFilterResult(
            should_avoid=True, reason="Market closed (weekend)",
            next_event=None, minutes_to_event=None,
            active_events=[], upcoming_events=[], data_source="N/A",
        )

    events       = get_cached_events()
    now          = now_utc()
    active:   list[EconomicEvent] = []
    upcoming: list[EconomicEvent] = []
    should_avoid = False
    reason       = ""
    next_event   = None
    next_mins    = None

    for ev in events:
        mins = (ev.datetime - now).total_seconds() / 60
        buf  = ev.buffer_minutes()

        if -buf <= mins <= buf:
            active.append(ev)
            should_avoid = True
            if not reason:
                tier_str = {1: "🚨 TIER-1", 2: "⚠️ TIER-2", 3: "📌"}.get(ev.tier, "📌")
                if mins > 0:
                    reason = (
                        f"{tier_str} {ev.title} in {int(mins)} min "
                        f"— signals blocked ({buf}m window)"
                    )
                else:
                    reason = (
                        f"{tier_str} {ev.title} released {int(-mins)} min ago "
                        f"— signals blocked ({buf}m post-event window)"
                    )

        elif 0 < mins <= 180:
            upcoming.append(ev)

    upcoming.sort(key=lambda e: e.datetime)
    upcoming = upcoming[:5]

    if upcoming and not next_event:
        next_event = upcoming[0]
        next_mins  = int((next_event.datetime - now).total_seconds() / 60)

    if not reason:
        if next_event:
            t = {1: "🚨", 2: "⚠️", 3: "📌"}.get(next_event.tier, "📌")
            reason = (
                f"✅ Clear. Next: {t} {next_event.title} "
                f"in {next_mins} min"
            )
        else:
            reason = "✅ No high-impact events in the next 3 hours"

    logger.debug(
        f"NewsFilter | should_avoid={should_avoid} active={len(active)} "
        f"upcoming={len(upcoming)} source={_source_used}"
    )

    return NewsFilterResult(
        should_avoid=should_avoid,
        reason=reason,
        next_event=next_event,
        minutes_to_event=next_mins,
        active_events=active,
        upcoming_events=upcoming,
        data_source=_source_used,
    )
