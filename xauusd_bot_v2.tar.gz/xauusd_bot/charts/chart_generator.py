"""
charts/chart_generator.py
=========================
Annotated candlestick chart generator.
FIX: Corrected syntax error on logger.debug line.
"""

from __future__ import annotations

import io
from datetime import datetime
from typing import Any, Optional

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import mplfinance as mpf
import numpy as np
import pandas as pd

from config.settings import (
    CHART_STYLE, CHART_LOOKBACK_BARS, CHART_DPI, CHART_FIGSIZE,
    EMA_FAST, EMA_SLOW,
)
from analysis.trend_filter  import calculate_ema
from analysis.order_blocks  import OrderBlock
from analysis.fair_value_gap import FVG
from utils.helpers import round_price
from utils.logger  import get_logger

logger = get_logger(__name__)

# ─── Style palettes ───────────────────────────────────────────────────────────
_DARK = {
    "bg": "#0d1117", "panel_bg": "#161b22", "text": "#e6edf3",
    "grid": "#30363d", "bull_candle": "#26a641", "bear_candle": "#f85149",
    "ema_fast": "#58a6ff", "ema_slow": "#f0883e",
    "entry": "#58a6ff", "sl": "#f85149",
    "tp1": "#3fb950", "tp2": "#26a641", "tp3": "#00d26a",
    "ob_bull": "#26a641", "ob_bear": "#f85149",
    "fvg_bull": "#1f6feb", "fvg_bear": "#da3633",
    "liquidity": "#e3b341",
}
_LIGHT = {
    "bg": "#ffffff", "panel_bg": "#f6f8fa", "text": "#24292f",
    "grid": "#d0d7de", "bull_candle": "#1a7f37", "bear_candle": "#cf222e",
    "ema_fast": "#0550ae", "ema_slow": "#9a6700",
    "entry": "#0550ae", "sl": "#cf222e",
    "tp1": "#1a7f37", "tp2": "#1a7f37", "tp3": "#1a7f37",
    "ob_bull": "#1a7f37", "ob_bear": "#cf222e",
    "fvg_bull": "#0550ae", "fvg_bear": "#8250df",
    "liquidity": "#9a6700",
}
_STYLES = {"dark": _DARK, "light": _LIGHT}

def _s() -> dict:
    return _STYLES.get(CHART_STYLE.lower(), _DARK)


def _hline(ax, price: float, color: str, label: str, lw: float = 1.2, ls: str = "--") -> None:
    ax.axhline(y=price, color=color, linewidth=lw, linestyle=ls, alpha=0.85)
    xlim = ax.get_xlim()
    ax.text(
        xlim[1] * 0.999, price, f" {label} {price:.2f}",
        color=color, fontsize=6.5, va="center", ha="right",
        bbox=dict(facecolor=ax.get_facecolor(), alpha=0.6, edgecolor="none", pad=1),
    )


def generate_signal_chart(
    df: pd.DataFrame,
    signal: dict[str, Any],
    obs:    list[OrderBlock] | None = None,
    fvgs:   list[FVG]        | None = None,
    liquidity_levels: list[float] | None = None,
) -> Optional[io.BytesIO]:
    """
    Generate annotated signal chart. Returns BytesIO PNG or None on failure.
    """
    try:
        style = _s()
        n_bars  = min(CHART_LOOKBACK_BARS, len(df))
        plot_df = df.tail(n_bars).copy()
        plot_df.index = pd.DatetimeIndex(plot_df.index)
        for col in ["open", "high", "low", "close", "volume"]:
            plot_df[col] = plot_df[col].astype(float)

        # EMAs
        ema50  = calculate_ema(plot_df["close"], EMA_FAST).values
        ema200 = calculate_ema(plot_df["close"], EMA_SLOW).values

        ap = [
            mpf.make_addplot(ema50,  color=style["ema_fast"], width=1.2, label=f"EMA{EMA_FAST}"),
            mpf.make_addplot(ema200, color=style["ema_slow"], width=1.8, label=f"EMA{EMA_SLOW}"),
        ]

        mc = mpf.make_marketcolors(
            up=style["bull_candle"], down=style["bear_candle"],
            edge="inherit",
            wick={"up": style["bull_candle"], "down": style["bear_candle"]},
            volume={"up": style["bull_candle"] + "88", "down": style["bear_candle"] + "88"},
        )
        mpl_style = mpf.make_mpf_style(
            marketcolors=mc,
            facecolor=style["bg"], figcolor=style["bg"],
            gridcolor=style["grid"], gridstyle=":", gridaxis="both",
            rc={
                "axes.labelcolor": style["text"],
                "xtick.color":     style["text"],
                "ytick.color":     style["text"],
                "font.family":     "monospace",
            },
        )

        direction  = signal.get("direction", "BUY")
        entry      = signal.get("entry",     0.0)
        stop_loss  = signal.get("stop_loss", 0.0)
        tp1        = signal.get("tp1",       0.0)
        tp2        = signal.get("tp2",       0.0)
        tp3        = signal.get("tp3",       0.0)
        confidence = signal.get("confidence", 0)
        grade      = signal.get("grade",     "B")
        session    = signal.get("session",   "")
        timestamp  = signal.get("timestamp", datetime.utcnow())
        rr         = signal.get("rr_ratio",  0.0)
        method     = signal.get("confidence_method", "rule-based")

        ts_str = timestamp.strftime("%Y-%m-%d %H:%M") if isinstance(timestamp, datetime) else str(timestamp)
        title = (
            f"XAUUSD {direction}  |  {confidence}% ({grade})  |  "
            f"{session}  |  {ts_str} UTC  |  [{method}]"
        )

        fig, axes = mpf.plot(
            plot_df, type="candle", style=mpl_style,
            volume=True, addplot=ap, figsize=CHART_FIGSIZE,
            title=title, tight_layout=True, returnfig=True,
            warn_too_much_data=9999,
        )

        ax    = axes[0]
        ax_v  = axes[2]
        ax.set_facecolor(style["panel_bg"])
        ax_v.set_facecolor(style["panel_bg"])

        # Horizontal lines
        _hline(ax, entry,     style["entry"], "ENTRY", lw=1.8, ls="-")
        _hline(ax, stop_loss, style["sl"],    "SL",    lw=1.4, ls="--")
        _hline(ax, tp1,       style["tp1"],   "TP1",   lw=1.2, ls="--")
        _hline(ax, tp2,       style["tp2"],   "TP2",   lw=1.2, ls="--")
        _hline(ax, tp3,       style["tp3"],   "TP3",   lw=1.2, ls=":")

        n_plot = len(plot_df)

        # Order Block zones
        if obs:
            for ob in obs[-5:]:
                if ob.mitigated:
                    continue
                x_start = max(0, ob.bar_index - (len(df) - n_plot))
                color   = style["ob_bull"] if ob.kind == "bullish" else style["ob_bear"]
                try:
                    ax.axhspan(ob.bottom, ob.top,
                               xmin=x_start / n_plot, xmax=1.0,
                               color=color, alpha=0.12)
                    ax.axhline(y=ob.mid, color=color, lw=0.5, ls=":", alpha=0.5)
                except Exception:
                    pass

        # FVG zones
        if fvgs:
            for fvg in fvgs[-5:]:
                if fvg.mitigated:
                    continue
                x_start = max(0, fvg.bar_index - (len(df) - n_plot))
                color   = style["fvg_bull"] if fvg.kind == "bullish" else style["fvg_bear"]
                try:
                    ax.axhspan(fvg.bottom, fvg.top,
                               xmin=x_start / n_plot, xmax=1.0,
                               color=color, alpha=0.10)
                except Exception:
                    pass

        # Liquidity levels
        if liquidity_levels:
            for lv in liquidity_levels[-4:]:
                ax.axhline(y=lv, color=style["liquidity"], lw=0.8, ls=":", alpha=0.6)

        # SL/TP fill zones
        try:
            if direction == "BUY":
                ax.axhspan(stop_loss, entry, color=style["sl"],  alpha=0.06)
                ax.axhspan(entry,     tp1,   color=style["tp1"], alpha=0.04)
            else:
                ax.axhspan(entry,     stop_loss, color=style["sl"],  alpha=0.06)
                ax.axhspan(tp1,       entry,     color=style["tp1"], alpha=0.04)
        except Exception:
            pass

        # Info box
        reasons = signal.get("reasons", [])
        reason_str = "\n".join(f"✓ {r[:45]}" for r in reasons[:4])
        info = (
            f"Dir:  {direction}\n"
            f"Entry:{entry:.2f}  SL:{stop_loss:.2f}\n"
            f"TP1:  {tp1:.2f}  RR:1:{rr:.1f}\n"
            f"Conf: {confidence}% {grade}\n"
            f"\n{reason_str}"
        )
        ax.text(
            0.01, 0.99, info,
            transform=ax.transAxes, fontsize=6.5,
            verticalalignment="top", color=style["text"], fontfamily="monospace",
            bbox=dict(facecolor=style["bg"], alpha=0.78,
                      edgecolor=style["grid"], boxstyle="round,pad=0.3"),
        )

        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=CHART_DPI, bbox_inches="tight",
                    facecolor=style["bg"])
        plt.close(fig)
        buf.seek(0)
        # ✅ FIX: was missing closing parenthesis in original
        logger.debug(f"Chart generated: {len(buf.getvalue())} bytes")
        return buf

    except Exception as exc:
        logger.error(f"Chart generation failed: {exc}", exc_info=True)
        plt.close("all")
        return None
