"""
engine/auto_trader.py
=====================
Optional MetaTrader 5 auto-trading integration.

Features:
  - Open BUY / SELL trades based on signals
  - Automatic SL / TP placement
  - Break-even automation (move SL to entry when TP1 hit)
  - Trailing stop management
  - Close positions on TP/SL confirmation
  - Max concurrent open positions guard

Requires MetaTrader5 Python package AND Windows with MT5 terminal installed.
On Linux/Mac: set AUTO_TRADE_ENABLED=false (signals only, no execution).

Enabled via .env:  AUTO_TRADE_ENABLED=true
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Optional

from config.settings import (
    AUTO_TRADE_ENABLED,
    AUTO_TRADE_LOT_SIZE,
    AUTO_TRADE_MAGIC,
    AUTO_TRADE_MAX_OPEN,
    AUTO_TRADE_SLIPPAGE,
    MT5_LOGIN, MT5_PASSWORD, MT5_SERVER, MT5_SYMBOL,
)
from utils.helpers import round_price
from utils.logger  import get_logger

logger = get_logger(__name__)

# ─── Optional MT5 import ──────────────────────────────────────────────────────
try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    mt5 = None
    MT5_AVAILABLE = False

# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TradeResult:
    success:      bool
    ticket:       int         = 0
    message:      str         = ""
    entry_price:  float       = 0.0
    volume:       float       = 0.0
    error_code:   int         = 0


@dataclass
class OpenPosition:
    ticket:    int
    symbol:    str
    direction: str            # 'BUY' | 'SELL'
    volume:    float
    open_price:float
    sl:        float
    tp:        float
    profit:    float
    magic:     int


# ─────────────────────────────────────────────────────────────────────────────
# Connection management
# ─────────────────────────────────────────────────────────────────────────────

_connected: bool = False


def _check_available() -> bool:
    """Guard: return False with warning if MT5 or auto-trade is not available."""
    if not AUTO_TRADE_ENABLED:
        logger.debug("AutoTrader: disabled in settings.")
        return False
    if not MT5_AVAILABLE:
        logger.warning("AutoTrader: MetaTrader5 package not installed.")
        return False
    return True


def connect() -> bool:
    """Connect to MetaTrader 5 terminal. Returns True on success."""
    global _connected
    if not _check_available():
        return False
    if _connected:
        return True

    try:
        ok = mt5.initialize(
            login=MT5_LOGIN,
            password=MT5_PASSWORD,
            server=MT5_SERVER,
        )
        if not ok:
            err = mt5.last_error()
            logger.error(f"AutoTrader: MT5 initialize failed: {err}")
            return False

        info = mt5.account_info()
        if info is None:
            logger.error("AutoTrader: could not retrieve account info")
            return False

        _connected = True
        logger.info(
            f"AutoTrader: connected | Account #{info.login} "
            f"| Balance: {info.balance:.2f} {info.currency} "
            f"| Server: {MT5_SERVER}"
        )
        return True

    except Exception as exc:
        logger.error(f"AutoTrader: connect() error: {exc}")
        return False


def disconnect() -> None:
    global _connected
    if MT5_AVAILABLE and _connected:
        mt5.shutdown()
        _connected = False
        logger.info("AutoTrader: MT5 disconnected.")


def is_connected() -> bool:
    if not MT5_AVAILABLE or not _connected:
        return False
    try:
        return mt5.terminal_info() is not None
    except Exception:
        return False


def _ensure_connected() -> bool:
    if not is_connected():
        return connect()
    return True


# ─────────────────────────────────────────────────────────────────────────────
# Symbol info helpers
# ─────────────────────────────────────────────────────────────────────────────

def get_symbol_info() -> dict | None:
    """Return symbol tick info dict."""
    if not _ensure_connected():
        return None
    info = mt5.symbol_info(MT5_SYMBOL)
    if info is None:
        logger.error(f"AutoTrader: symbol {MT5_SYMBOL} not found in MT5")
        return None
    tick = mt5.symbol_info_tick(MT5_SYMBOL)
    return {
        "bid":    tick.bid,
        "ask":    tick.ask,
        "spread": round((tick.ask - tick.bid) / mt5.symbol_info(MT5_SYMBOL).point, 1),
        "digits": info.digits,
        "point":  info.point,
        "volume_min": info.volume_min,
        "volume_max": info.volume_max,
        "volume_step": info.volume_step,
    }


def _normalise_volume(vol: float) -> float:
    """Round volume to symbol's volume step."""
    if not MT5_AVAILABLE or not _connected:
        return vol
    info = mt5.symbol_info(MT5_SYMBOL)
    if info is None:
        return vol
    step = info.volume_step
    vol = max(info.volume_min, min(info.volume_max, round(vol / step) * step))
    return round(vol, 2)


# ─────────────────────────────────────────────────────────────────────────────
# Open trade
# ─────────────────────────────────────────────────────────────────────────────

def open_trade(
    direction: str,
    signal: dict[str, Any],
    lot_size: float | None = None,
) -> TradeResult:
    """
    Open a BUY or SELL position based on the signal dict.

    Parameters
    ----------
    direction : 'BUY' | 'SELL'
    signal    : Signal dict (must contain entry, stop_loss, tp1)
    lot_size  : Override default lot size from settings
    """
    if not _check_available():
        return TradeResult(False, message="AutoTrader disabled or MT5 unavailable")

    if not _ensure_connected():
        return TradeResult(False, message="MT5 connection failed")

    # Guard: max concurrent positions
    open_pos = get_open_positions()
    if len(open_pos) >= AUTO_TRADE_MAX_OPEN:
        msg = f"Max open positions reached ({AUTO_TRADE_MAX_OPEN})"
        logger.warning(f"AutoTrader: {msg}")
        return TradeResult(False, message=msg)

    # Get current prices
    tick = mt5.symbol_info_tick(MT5_SYMBOL)
    if tick is None:
        return TradeResult(False, message="Cannot get current tick")

    price = tick.ask if direction.upper() == "BUY" else tick.bid

    vol      = _normalise_volume(lot_size or AUTO_TRADE_LOT_SIZE)
    sl_price = round_price(float(signal.get("stop_loss", 0)), 2)
    tp_price = round_price(float(signal.get("tp1", 0)), 2)

    order_type = mt5.ORDER_TYPE_BUY if direction.upper() == "BUY" else mt5.ORDER_TYPE_SELL

    request = {
        "action":      mt5.TRADE_ACTION_DEAL,
        "symbol":      MT5_SYMBOL,
        "volume":      vol,
        "type":        order_type,
        "price":       price,
        "sl":          sl_price,
        "tp":          tp_price,
        "deviation":   AUTO_TRADE_SLIPPAGE,
        "magic":       AUTO_TRADE_MAGIC,
        "comment":     f"XAUUSD AI Bot | conf={signal.get('confidence', 0)}%",
        "type_time":   mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)

    if result is None:
        return TradeResult(False, message=f"order_send returned None: {mt5.last_error()}")

    if result.retcode != mt5.TRADE_RETCODE_DONE:
        msg = f"MT5 order failed: retcode={result.retcode} ({result.comment})"
        logger.error(f"AutoTrader: {msg}")
        return TradeResult(False, error_code=result.retcode, message=msg)

    logger.info(
        f"AutoTrader: ✅ {direction} opened | ticket={result.order} "
        f"price={result.price:.2f} SL={sl_price} TP={tp_price} vol={vol}"
    )
    return TradeResult(
        success=True,
        ticket=result.order,
        entry_price=result.price,
        volume=vol,
        message="Order executed successfully",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Manage open positions
# ─────────────────────────────────────────────────────────────────────────────

def get_open_positions() -> list[OpenPosition]:
    """Return all open positions opened by this bot (filtered by magic number)."""
    if not _ensure_connected():
        return []
    try:
        positions = mt5.positions_get(symbol=MT5_SYMBOL) or []
        result = []
        for p in positions:
            if p.magic != AUTO_TRADE_MAGIC:
                continue
            result.append(OpenPosition(
                ticket=p.ticket,
                symbol=p.symbol,
                direction="BUY" if p.type == 0 else "SELL",
                volume=p.volume,
                open_price=p.price_open,
                sl=p.sl,
                tp=p.tp,
                profit=p.profit,
                magic=p.magic,
            ))
        return result
    except Exception as exc:
        logger.error(f"AutoTrader: get_open_positions error: {exc}")
        return []


def modify_sl_tp(ticket: int, new_sl: float, new_tp: float) -> bool:
    """Modify SL and TP of an existing position."""
    if not _ensure_connected():
        return False
    request = {
        "action":   mt5.TRADE_ACTION_SLTP,
        "position": ticket,
        "sl":       round_price(new_sl, 2),
        "tp":       round_price(new_tp, 2),
    }
    result = mt5.order_send(request)
    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
        logger.info(f"AutoTrader: modified #{ticket} SL={new_sl:.2f} TP={new_tp:.2f}")
        return True
    logger.warning(f"AutoTrader: modify failed: {result.comment if result else 'None'}")
    return False


def close_position(ticket: int) -> bool:
    """Close a specific position by ticket number."""
    if not _ensure_connected():
        return False
    positions = mt5.positions_get(ticket=ticket)
    if not positions:
        logger.warning(f"AutoTrader: position #{ticket} not found")
        return False

    pos  = positions[0]
    tick = mt5.symbol_info_tick(MT5_SYMBOL)
    if tick is None:
        return False

    close_type  = mt5.ORDER_TYPE_SELL if pos.type == 0 else mt5.ORDER_TYPE_BUY
    close_price = tick.bid             if pos.type == 0 else tick.ask

    request = {
        "action":      mt5.TRADE_ACTION_DEAL,
        "symbol":      MT5_SYMBOL,
        "volume":      pos.volume,
        "type":        close_type,
        "position":    ticket,
        "price":       close_price,
        "deviation":   AUTO_TRADE_SLIPPAGE,
        "magic":       AUTO_TRADE_MAGIC,
        "comment":     "XAUUSD AI Bot — Close",
        "type_time":   mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    result = mt5.order_send(request)
    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
        logger.info(f"AutoTrader: ✅ Closed #{ticket} at {close_price:.2f}")
        return True
    logger.error(f"AutoTrader: close failed for #{ticket}: {result.comment if result else 'None'}")
    return False


# ─────────────────────────────────────────────────────────────────────────────
# Break-even and Trailing Stop automation
# ─────────────────────────────────────────────────────────────────────────────

def manage_open_positions() -> dict[str, int]:
    """
    Called by the scheduler to:
    1. Move SL to break-even when TP1 is reached.
    2. Apply trailing stop based on ATR.

    Returns {"be_moved": N, "trailing_updated": M}.
    """
    if not AUTO_TRADE_ENABLED or not _ensure_connected():
        return {"be_moved": 0, "trailing_updated": 0}

    positions  = get_open_positions()
    be_count   = 0
    trail_count = 0

    tick = mt5.symbol_info_tick(MT5_SYMBOL)
    if tick is None:
        return {"be_moved": 0, "trailing_updated": 0}

    current_bid = tick.bid
    current_ask = tick.ask

    for pos in positions:
        entry   = pos.open_price
        current = current_bid if pos.direction == "BUY" else current_ask
        risk    = abs(entry - pos.sl) if pos.sl else 0

        if risk <= 0:
            continue

        reward = abs(current - entry)
        rr     = reward / risk

        # Break-even: RR reached 1:1 and SL is still at original
        if rr >= 1.0 and pos.direction == "BUY" and pos.sl < entry:
            be_sl = entry + (risk * 0.05)   # 5% buffer above entry
            if modify_sl_tp(pos.ticket, be_sl, pos.tp):
                logger.info(f"AutoTrader: Break-even set for #{pos.ticket}")
                be_count += 1

        elif rr >= 1.0 and pos.direction == "SELL" and pos.sl > entry:
            be_sl = entry - (risk * 0.05)
            if modify_sl_tp(pos.ticket, be_sl, pos.tp):
                logger.info(f"AutoTrader: Break-even set for #{pos.ticket}")
                be_count += 1

        # Trailing stop: if RR > 1.5, trail SL at 1.5× ATR behind price
        # (simplified — ATR not available here; use 0.5 × risk as trail distance)
        trail_distance = risk * 0.5
        if rr >= 1.5:
            if pos.direction == "BUY":
                trail_sl = current - trail_distance
                if trail_sl > pos.sl:
                    modify_sl_tp(pos.ticket, trail_sl, pos.tp)
                    trail_count += 1
            else:
                trail_sl = current + trail_distance
                if trail_sl < pos.sl:
                    modify_sl_tp(pos.ticket, trail_sl, pos.tp)
                    trail_count += 1

    return {"be_moved": be_count, "trailing_updated": trail_count}


def get_account_summary() -> dict:
    """Return basic account info for admin panel."""
    if not _ensure_connected():
        return {"error": "Not connected"}
    info = mt5.account_info()
    if info is None:
        return {"error": "Cannot retrieve account"}
    return {
        "login":    info.login,
        "balance":  info.balance,
        "equity":   info.equity,
        "margin":   info.margin,
        "free_margin": info.margin_free,
        "currency": info.currency,
        "profit":   info.profit,
        "leverage": info.leverage,
        "server":   MT5_SERVER,
    }
