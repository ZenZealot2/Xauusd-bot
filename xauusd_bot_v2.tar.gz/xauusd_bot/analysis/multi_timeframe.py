"""
analysis/multi_timeframe.py
===========================
Orchestrates analysis across all timeframes and checks alignment.

Timeframe roles:
  H4 + H1  → Trend direction (must agree)
  M15      → Setup (BOS, OB, FVG)
  M5 / M1  → Entry refinement

A signal is only valid when:
  1. H4 and H1 trend agree (both Bullish or both Bearish)
  2. M15 shows a valid setup (BOS + OB or FVG)
  3. Session is London / NY / Overlap
  4. No high-impact news blocking the window
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import pandas as pd

from engine.data_fetcher import get_ohlcv, validate_dataframe
from analysis.market_structure import analyse_market_structure, MarketStructureResult
from analysis.smart_money     import analyse_smart_money,     SmartMoneyResult
from analysis.fair_value_gap  import analyse_fvg,             FVGResult
from analysis.order_blocks    import analyse_order_blocks,    OrderBlockResult
from analysis.trend_filter    import analyse_trend,           TrendFilterResult
from analysis.momentum        import analyse_momentum,        MomentumResult
from analysis.volume          import analyse_volume,          VolumeResult
from analysis.session         import analyse_session,         SessionResult
from analysis.news_filter     import analyse_news_filter,     NewsFilterResult
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Per-timeframe result bundle
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TimeframeAnalysis:
    timeframe:        str
    df:               pd.DataFrame
    market_structure: Optional[MarketStructureResult] = None
    smart_money:      Optional[SmartMoneyResult]      = None
    fvg:              Optional[FVGResult]              = None
    order_blocks:     Optional[OrderBlockResult]       = None
    trend:            Optional[TrendFilterResult]      = None
    momentum:         Optional[MomentumResult]         = None
    volume:           Optional[VolumeResult]           = None


# ─────────────────────────────────────────────────────────────────────────────
# Full MTF analysis container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MTFAnalysisResult:
    # Individual timeframe results
    h4:   TimeframeAnalysis
    h1:   TimeframeAnalysis
    m15:  TimeframeAnalysis
    m5:   TimeframeAnalysis
    m1:   TimeframeAnalysis

    # Cross-timeframe aggregates
    session:       SessionResult
    news:          NewsFilterResult
    current_price: float

    # Alignment verdict
    trend_aligned:    bool     # H4 and H1 agree on direction
    htf_direction:    str      # 'Bullish' | 'Bearish' | 'Sideways'
    signal_direction: str      # 'BUY' | 'SELL' | ''
    setup_valid:      bool     # M15 has a valid OB/FVG + BOS setup
    can_generate:     bool     # All filters pass

    blocking_reason:  str      # Why can_generate is False (if applicable)


# ─────────────────────────────────────────────────────────────────────────────
# Per-timeframe full analysis runner
# ─────────────────────────────────────────────────────────────────────────────

def _run_tf_analysis(
    tf: str,
    direction: str = "",
    run_trend: bool = True,
) -> TimeframeAnalysis:
    """
    Run all applicable analysis modules on a single timeframe DataFrame.
    """
    df = get_ohlcv(tf)
    tfa = TimeframeAnalysis(timeframe=tf, df=df)

    if not validate_dataframe(df, min_bars=50):
        logger.warning(f"MTF: {tf} data invalid or insufficient.")
        return tfa

    current_price = float(df["close"].iloc[-1])

    # Market Structure
    try:
        tfa.market_structure = analyse_market_structure(df)
    except Exception as e:
        logger.error(f"MTF [{tf}] market_structure error: {e}")

    # Smart Money (requires swing points from market structure)
    if tfa.market_structure:
        try:
            tfa.smart_money = analyse_smart_money(
                df,
                tfa.market_structure.swing_highs,
                tfa.market_structure.swing_lows,
                signal_direction=direction,
            )
        except Exception as e:
            logger.error(f"MTF [{tf}] smart_money error: {e}")

    # FVG
    try:
        tfa.fvg = analyse_fvg(df, current_price, signal_direction=direction)
    except Exception as e:
        logger.error(f"MTF [{tf}] fvg error: {e}")

    # Order Blocks
    try:
        tfa.order_blocks = analyse_order_blocks(df, current_price, signal_direction=direction)
    except Exception as e:
        logger.error(f"MTF [{tf}] order_blocks error: {e}")

    # Trend (only for HTF and M15)
    if run_trend:
        try:
            tfa.trend = analyse_trend(df, signal_direction=direction)
        except Exception as e:
            logger.error(f"MTF [{tf}] trend error: {e}")

    # Momentum
    try:
        tfa.momentum = analyse_momentum(df, signal_direction=direction)
    except Exception as e:
        logger.error(f"MTF [{tf}] momentum error: {e}")

    # Volume
    try:
        tfa.volume = analyse_volume(df, signal_direction=direction)
    except Exception as e:
        logger.error(f"MTF [{tf}] volume error: {e}")

    return tfa


# ─────────────────────────────────────────────────────────────────────────────
# Alignment checker
# ─────────────────────────────────────────────────────────────────────────────

def _check_trend_alignment(h4: TimeframeAnalysis, h1: TimeframeAnalysis) -> tuple[bool, str, str]:
    """
    Returns (aligned: bool, htf_direction: str, signal_direction: str).
    """
    h4_dir = (h4.trend.direction if h4.trend else None) or \
             (h4.market_structure.trend if h4.market_structure else "Sideways")
    h1_dir = (h1.trend.direction if h1.trend else None) or \
             (h1.market_structure.trend if h1.market_structure else "Sideways")

    if h4_dir == "Sideways" or h1_dir == "Sideways":
        # Partial alignment: use whichever is not sideways
        if h4_dir != "Sideways" and h1_dir == "Sideways":
            return True, h4_dir, "BUY" if h4_dir == "Bullish" else "SELL"
        if h1_dir != "Sideways" and h4_dir == "Sideways":
            return True, h1_dir, "BUY" if h1_dir == "Bullish" else "SELL"
        return False, "Sideways", ""

    if h4_dir == h1_dir:
        sig = "BUY" if h4_dir == "Bullish" else "SELL"
        return True, h4_dir, sig

    return False, "Conflicting", ""


def _check_setup_valid(m15: TimeframeAnalysis, direction: str) -> bool:
    """
    M15 setup is valid when there is at least one of:
    - Recent BOS or CHOCH in the signal direction
    - Price in an active OB aligned with direction
    - Price in an active FVG aligned with direction
    """
    valid = False

    if m15.market_structure:
        bos   = m15.market_structure.last_bos
        choch = m15.market_structure.last_choch
        if bos and (
            (direction == "BUY"  and bos.direction == "bullish") or
            (direction == "SELL" and bos.direction == "bearish")
        ):
            valid = True
        if choch and (
            (direction == "BUY"  and choch.direction == "bullish") or
            (direction == "SELL" and choch.direction == "bearish")
        ):
            valid = True

    if m15.order_blocks and m15.order_blocks.price_in_ob:
        valid = True

    if m15.fvg and m15.fvg.price_in_fvg:
        valid = True

    return valid


# ─────────────────────────────────────────────────────────────────────────────
# Main MTF orchestrator
# ─────────────────────────────────────────────────────────────────────────────

def run_full_analysis() -> MTFAnalysisResult:
    """
    Entry point: run analysis on all timeframes, check alignment,
    and return a complete MTFAnalysisResult.

    Step 1: Session + News pre-filter (fast, no data fetching)
    Step 2: H4 + H1 trend alignment
    Step 3: M15 setup check
    Step 4: M5 + M1 entry refinement
    """
    logger.info("MTF: Starting full multi-timeframe analysis...")

    # ── Step 1: Pre-filters ──────────────────────────────────────────────────
    session_result = analyse_session()
    news_result    = analyse_news_filter()

    if session_result.is_weekend:
        return _early_exit("Market closed — weekend", session_result, news_result)

    if news_result.should_avoid:
        return _early_exit(news_result.reason, session_result, news_result)

    if not session_result.is_high_quality:
        # Asian session: still analyse but flag as low quality
        logger.info(f"MTF: Low quality session ({session_result.current_session}) — continuing scan")

    # ── Step 2: H4 + H1 trend (no direction hint yet) ────────────────────────
    h4  = _run_tf_analysis("H4", run_trend=True)
    h1  = _run_tf_analysis("H1", run_trend=True)

    trend_aligned, htf_direction, signal_direction = _check_trend_alignment(h4, h1)

    if not trend_aligned or signal_direction == "":
        logger.info(f"MTF: HTF trend not aligned (H4={h4.trend and h4.trend.direction}, H1={h1.trend and h1.trend.direction})")
        return _early_exit(
            f"H4/H1 trends not aligned ({htf_direction})",
            session_result, news_result,
            h4=h4, h1=h1,
        )

    logger.info(f"MTF: HTF trend aligned → {htf_direction} | Signal direction: {signal_direction}")

    # ── Step 3: M15 setup with direction hint ────────────────────────────────
    m15 = _run_tf_analysis("M15", direction=signal_direction, run_trend=True)

    setup_valid = _check_setup_valid(m15, signal_direction)

    if not setup_valid:
        logger.info("MTF: M15 setup not valid — no OB/FVG/BOS aligned with direction")
        return _early_exit(
            f"No valid M15 setup for {signal_direction}",
            session_result, news_result,
            h4=h4, h1=h1, m15=m15,
            htf_direction=htf_direction, signal_direction=signal_direction, trend_aligned=True,
        )

    # ── Step 4: Entry TFs ────────────────────────────────────────────────────
    m5 = _run_tf_analysis("M5", direction=signal_direction, run_trend=False)
    m1 = _run_tf_analysis("M1", direction=signal_direction, run_trend=False)

    # Current price from M1 (most up-to-date)
    current_price = float(m1.df["close"].iloc[-1]) if validate_dataframe(m1.df) else (
        float(m5.df["close"].iloc[-1]) if validate_dataframe(m5.df) else 0.0
    )

    logger.info(
        f"MTF: Analysis complete | price={current_price:.2f} "
        f"direction={signal_direction} setup_valid={setup_valid}"
    )

    return MTFAnalysisResult(
        h4=h4, h1=h1, m15=m15, m5=m5, m1=m1,
        session=session_result,
        news=news_result,
        current_price=current_price,
        trend_aligned=trend_aligned,
        htf_direction=htf_direction,
        signal_direction=signal_direction,
        setup_valid=setup_valid,
        can_generate=True,
        blocking_reason="",
    )


def _early_exit(
    reason: str,
    session: SessionResult,
    news: NewsFilterResult,
    h4: Optional[TimeframeAnalysis] = None,
    h1: Optional[TimeframeAnalysis] = None,
    m15: Optional[TimeframeAnalysis] = None,
    htf_direction: str = "Sideways",
    signal_direction: str = "",
    trend_aligned: bool = False,
) -> MTFAnalysisResult:
    """Return an early-exit result with can_generate=False."""
    empty_tf = TimeframeAnalysis(timeframe="", df=pd.DataFrame())
    return MTFAnalysisResult(
        h4=h4   or empty_tf,
        h1=h1   or empty_tf,
        m15=m15 or empty_tf,
        m5=empty_tf,
        m1=empty_tf,
        session=session,
        news=news,
        current_price=0.0,
        trend_aligned=trend_aligned,
        htf_direction=htf_direction,
        signal_direction=signal_direction,
        setup_valid=False,
        can_generate=False,
        blocking_reason=reason,
    )
