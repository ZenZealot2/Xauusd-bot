"""
analysis/smart_money.py
=======================
Improved Smart Money Concept detection.

Improvements:
  - Sweep requires BOTH wick-through AND close back across level
  - Sweep strength measured by: body close beyond wick extreme
  - Multi-touch liquidity pools (3+ touches) scored higher
  - Inducement now validated against volume
  - Stop hunt: requires minimum pip deviation beyond level
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

from config.settings import LIQUIDITY_TOLERANCE_PCT, SWING_LOOKBACK, SCORE_WEIGHTS
from analysis.market_structure import SwingPoint
from utils.helpers import is_close
from utils.logger  import get_logger

logger = get_logger(__name__)


@dataclass
class LiquidityLevel:
    price:     float
    kind:      str        # 'buy_side' | 'sell_side'
    touches:   int  = 1
    swept:     bool = False
    sweep_bar: int  = -1
    strength:  str  = "weak"   # 'weak' | 'moderate' | 'strong'


@dataclass
class LiquiditySweep:
    level:        float
    kind:         str       # 'buy_side_swept' | 'sell_side_swept'
    bar_index:    int
    reversal:     bool = False
    wick_pips:    float = 0.0   # How far price went beyond level
    close_pips:   float = 0.0   # How far close returned
    strength:     str   = "weak"


@dataclass
class SmartMoneyResult:
    liquidity_levels:  list[LiquidityLevel]
    sweeps:            list[LiquiditySweep]
    last_sweep:        Optional[LiquiditySweep]
    buy_side_levels:   list[float]
    sell_side_levels:  list[float]
    inducement_levels: list[float]
    score:             int
    reasons:           list[str]


# ─────────────────────────────────────────────────────────────────────────────
# Equal levels detection
# ─────────────────────────────────────────────────────────────────────────────

def detect_equal_levels(
    swing_highs: list[SwingPoint],
    swing_lows:  list[SwingPoint],
    tolerance:   float = LIQUIDITY_TOLERANCE_PCT,
) -> tuple[list[LiquidityLevel], list[LiquidityLevel]]:
    """
    Group swing highs/lows by price proximity.
    Levels with 3+ touches are classified as 'strong' liquidity pools.
    """
    def _group(points: list[SwingPoint], kind: str) -> list[LiquidityLevel]:
        if not points:
            return []
        sorted_pts = sorted(points, key=lambda p: p.price)
        groups: list[list[SwingPoint]] = [[sorted_pts[0]]]

        for pt in sorted_pts[1:]:
            median = np.median([p.price for p in groups[-1]])
            if is_close(pt.price, median, tolerance):
                groups[-1].append(pt)
            else:
                groups.append([pt])

        levels: list[LiquidityLevel] = []
        for g in groups:
            if len(g) < 2:
                continue
            avg   = float(np.mean([p.price for p in g]))
            n_t   = len(g)
            strength = "strong" if n_t >= 3 else "moderate" if n_t == 2 else "weak"
            levels.append(LiquidityLevel(price=avg, kind=kind, touches=n_t, strength=strength))
        return levels

    return _group(swing_highs, "buy_side"), _group(swing_lows, "sell_side")


# ─────────────────────────────────────────────────────────────────────────────
# Sweep detection (improved validation)
# ─────────────────────────────────────────────────────────────────────────────

def detect_liquidity_sweeps(
    df:               pd.DataFrame,
    buy_side_levels:  list[LiquidityLevel],
    sell_side_levels: list[LiquidityLevel],
    confirm_bars:     int = 3,
    min_wick_pips:    float = 1.0,
) -> list[LiquiditySweep]:
    """
    Improved sweep detection:
    1. Wick must exceed level by at least min_wick_pips
    2. Close must be CLEARLY back on the opposite side
    3. Confirmation: next confirm_bars must stay on close side
    4. Sweep strength based on wick size vs close recovery
    """
    sweeps: list[LiquiditySweep] = []
    highs  = df["high"].values
    lows   = df["low"].values
    closes = df["close"].values
    opens  = df["open"].values
    n      = len(df)
    min_w  = min_wick_pips * 0.10   # Convert to price

    # ── Sell-side sweeps (bullish) ────────────────────────────────────────
    for level in sell_side_levels:
        lv = level.price
        for i in range(SWING_LOOKBACK, n - confirm_bars):
            wick_below = lv - lows[i]
            if wick_below < min_w:
                continue      # not enough deviation below

            close_above = closes[i] - lv
            if close_above <= 0:
                continue      # close didn't recover above level

            # Confirm: next bars stay above level
            fut = closes[i + 1: i + 1 + confirm_bars]
            if len(fut) == 0 or fut.min() < lv:
                continue

            wick_pips  = round(wick_below  / 0.10, 1)
            close_pips = round(close_above / 0.10, 1)
            strength   = "strong" if wick_pips >= 3 and close_pips >= 2 else \
                         "moderate" if wick_pips >= 1.5 else "weak"

            sweep = LiquiditySweep(
                level=lv, kind="sell_side_swept", bar_index=i,
                reversal=True, wick_pips=wick_pips,
                close_pips=close_pips, strength=strength,
            )
            sweeps.append(sweep)
            level.swept     = True
            level.sweep_bar = i
            break

    # ── Buy-side sweeps (bearish) ─────────────────────────────────────────
    for level in buy_side_levels:
        lv = level.price
        for i in range(SWING_LOOKBACK, n - confirm_bars):
            wick_above = highs[i] - lv
            if wick_above < min_w:
                continue

            close_below = lv - closes[i]
            if close_below <= 0:
                continue

            fut = closes[i + 1: i + 1 + confirm_bars]
            if len(fut) == 0 or fut.max() > lv:
                continue

            wick_pips  = round(wick_above  / 0.10, 1)
            close_pips = round(close_below / 0.10, 1)
            strength   = "strong" if wick_pips >= 3 and close_pips >= 2 else \
                         "moderate" if wick_pips >= 1.5 else "weak"

            sweep = LiquiditySweep(
                level=lv, kind="buy_side_swept", bar_index=i,
                reversal=True, wick_pips=wick_pips,
                close_pips=close_pips, strength=strength,
            )
            sweeps.append(sweep)
            level.swept     = True
            level.sweep_bar = i
            break

    sweeps.sort(key=lambda s: s.bar_index)
    return sweeps


# ─────────────────────────────────────────────────────────────────────────────
# Inducement detection (volume-validated)
# ─────────────────────────────────────────────────────────────────────────────

def detect_inducement(
    df: pd.DataFrame,
    swing_highs: list[SwingPoint],
    swing_lows: list[SwingPoint],
) -> list[float]:
    """
    Inducement = minor swing that lures retail traders before the real move.
    Now validates with volume: inducement followed by high-volume reversal.
    """
    inducement: list[float] = []
    closes = df["close"].values
    vols   = df["volume"].values
    n      = len(df)
    if n < 20:
        return inducement

    avg_range  = float(np.mean(df["high"].values - df["low"].values))
    avg_volume = float(np.mean(vols)) if len(vols) > 5 else 1.0

    for sh in swing_highs[-12:]:
        idx = sh.index + 1
        if idx >= n:
            continue
        bar_range = df["high"].iloc[idx] - df["low"].iloc[idx]
        # Reversal bar must be large AND have above-average volume
        if (bar_range > 1.5 * avg_range and closes[idx] < sh.price and
                vols[idx] > avg_volume * 1.2):
            inducement.append(sh.price)

    for sl in swing_lows[-12:]:
        idx = sl.index + 1
        if idx >= n:
            continue
        bar_range = df["high"].iloc[idx] - df["low"].iloc[idx]
        if (bar_range > 1.5 * avg_range and closes[idx] > sl.price and
                vols[idx] > avg_volume * 1.2):
            inducement.append(sl.price)

    return inducement


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_smart_money(
    df: pd.DataFrame,
    swing_highs: list[SwingPoint],
    swing_lows:  list[SwingPoint],
    signal_direction: str = "",
) -> SmartMoneyResult:
    score   = 0
    reasons: list[str] = []
    max_sc  = SCORE_WEIGHTS["liquidity_sweep"]

    eq_highs, eq_lows = detect_equal_levels(swing_highs, swing_lows)
    sweeps = detect_liquidity_sweeps(df, eq_highs, eq_lows)
    inducement = detect_inducement(df, swing_highs, swing_lows)

    last_sweep = sweeps[-1] if sweeps else None
    all_levels = eq_highs + eq_lows

    # ── Scoring ──────────────────────────────────────────────────────────────
    if all_levels:
        strong = [lv for lv in all_levels if lv.strength == "strong"]
        score += 3 + len(strong)
        reasons.append(
            f"Liquidity pools: {len(eq_highs)} buy-side, {len(eq_lows)} sell-side"
            + (f" ({len(strong)} strong)" if strong else "")
        )
        score = min(score, 5)

    valid_sweeps = [s for s in sweeps if s.reversal]
    if valid_sweeps:
        last = valid_sweeps[-1]
        aligned = (
            (signal_direction == "BUY"  and last.kind == "sell_side_swept") or
            (signal_direction == "SELL" and last.kind == "buy_side_swept")
        )
        strength_bonus = {"strong": 4, "moderate": 3, "weak": 2}.get(last.strength, 2)
        score += strength_bonus

        kind_str = "Sell-Side" if last.kind == "sell_side_swept" else "Buy-Side"
        reasons.append(
            f"{last.strength.capitalize()} {kind_str} sweep @ {last.level:.2f} "
            f"(wick={last.wick_pips:.1f}p, close={last.close_pips:.1f}p)"
        )

        if aligned:
            score += 3
            reasons.append(f"Sweep aligns with {signal_direction} direction ✅")

    if inducement:
        score += 2
        reasons.append(f"Volume-validated inducement @ {inducement[-1]:.2f}")

    score = min(score, max_sc)
    logger.debug(
        f"SmartMoney | levels={len(all_levels)} sweeps={len(valid_sweeps)} "
        f"inducement={len(inducement)} score={score}/{max_sc}"
    )

    return SmartMoneyResult(
        liquidity_levels=all_levels,
        sweeps=sweeps,
        last_sweep=last_sweep,
        buy_side_levels=[lv.price for lv in eq_highs],
        sell_side_levels=[lv.price for lv in eq_lows],
        inducement_levels=inducement,
        score=score,
        reasons=reasons,
    )
