"""
utils/formatters.py
===================
Functions that turn signal dicts and statistics into Telegram-ready message strings.
All messages use MarkdownV2 escaping where required.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from utils.helpers import round_price


# ─────────────────────────────────────────────────────────────────────────────
# Telegram MarkdownV2 safe escaping
# ─────────────────────────────────────────────────────────────────────────────

_MD_SPECIAL = r"\_*[]()~`>#+-=|{}.!"


def escape_md(text: str) -> str:
    """Escape all MarkdownV2 special characters."""
    for ch in _MD_SPECIAL:
        text = text.replace(ch, f"\\{ch}")
    return text


# ─────────────────────────────────────────────────────────────────────────────
# Grade / Classification display
# ─────────────────────────────────────────────────────────────────────────────

GRADE_EMOJI: dict[str, str] = {
    "A+": "🏆",
    "A":  "⭐",
    "B":  "✅",
    "C":  "🔔",
}

CLASSIFICATION_EMOJI: dict[str, str] = {
    "ELITE":  "🚀",
    "STRONG": "💪",
    "NORMAL": "📊",
}

DIRECTION_EMOJI: dict[str, str] = {
    "BUY":  "🟢",
    "SELL": "🔴",
}

TREND_EMOJI: dict[str, str] = {
    "Bullish":  "📈",
    "Bearish":  "📉",
    "Sideways": "↔️",
}


# ─────────────────────────────────────────────────────────────────────────────
# Signal message formatter
# ─────────────────────────────────────────────────────────────────────────────

def format_signal_message(signal: dict[str, Any]) -> str:
    """
    Build the full Telegram signal message from a signal dict.

    Expected keys in *signal*:
        direction, classification, grade, confidence,
        entry, stop_loss, tp1, tp2, tp3,
        rr_ratio, trend, session, reasons,
        timestamp (datetime or str)
    """
    direction: str   = signal.get("direction", "BUY")
    classification   = signal.get("classification", "NORMAL")
    grade: str       = signal.get("grade", "B")
    confidence: int  = signal.get("confidence", 70)
    entry: float     = signal.get("entry", 0.0)
    stop_loss: float = signal.get("stop_loss", 0.0)
    tp1: float       = signal.get("tp1", 0.0)
    tp2: float       = signal.get("tp2", 0.0)
    tp3: float       = signal.get("tp3", 0.0)
    rr_ratio: float  = signal.get("rr_ratio", 0.0)
    trend: str       = signal.get("trend", "Bullish")
    session: str     = signal.get("session", "London")
    reasons: list    = signal.get("reasons", [])
    timestamp        = signal.get("timestamp", datetime.utcnow())

    if isinstance(timestamp, datetime):
        ts_str = timestamp.strftime("%Y-%m-%d %H:%M UTC")
    else:
        ts_str = str(timestamp)

    dir_emoji    = DIRECTION_EMOJI.get(direction, "")
    class_emoji  = CLASSIFICATION_EMOJI.get(classification, "📊")
    grade_emoji  = GRADE_EMOJI.get(grade, "")
    trend_emoji  = TREND_EMOJI.get(trend, "")

    # Risk indicator
    risk_pips = abs(entry - stop_loss) / 0.10
    reward_pips_tp1 = abs(tp1 - entry) / 0.10

    # Build reasons block
    reasons_block = "\n".join(f"✅ {r}" for r in reasons) if reasons else "✅ Multiple confirmations"

    # Header depends on classification
    header = f"{class_emoji} {classification} XAUUSD {direction} SIGNAL {dir_emoji}"

    message = (
        f"{header}\n"
        f"{'─' * 38}\n"
        f"\n"
        f"🎯 <b>Entry:</b>          <code>{round_price(entry)}</code>\n"
        f"🛑 <b>Stop Loss:</b>      <code>{round_price(stop_loss)}</code>\n"
        f"🏁 <b>Take Profit 1:</b>  <code>{round_price(tp1)}</code>\n"
        f"🏁 <b>Take Profit 2:</b>  <code>{round_price(tp2)}</code>\n"
        f"🏁 <b>Take Profit 3:</b>  <code>{round_price(tp3)}</code>\n"
        f"\n"
        f"{'─' * 38}\n"
        f"\n"
        f"🤖 <b>AI Confidence:</b>  <b>{confidence}%</b>\n"
        f"{grade_emoji} <b>Signal Grade:</b>   <b>{grade}</b>\n"
        f"{trend_emoji} <b>Trend:</b>          {trend}\n"
        f"🌍 <b>Session:</b>        {session}\n"
        f"📐 <b>Risk/Reward:</b>    1:{rr_ratio}\n"
        f"\n"
        f"{'─' * 38}\n"
        f"\n"
        f"<b>📋 Reasons:</b>\n"
        f"{reasons_block}\n"
        f"\n"
        f"{'─' * 38}\n"
        f"⏰ <i>{ts_str}</i>\n"
        f"\n"
        f"⚠️ <i>Not financial advice. Trade responsibly.</i>"
    )

    return message


# ─────────────────────────────────────────────────────────────────────────────
# Stats / Performance formatter
# ─────────────────────────────────────────────────────────────────────────────

def format_stats_message(stats: dict[str, Any], period: str = "All Time") -> str:
    """Format performance statistics into a Telegram message."""
    total        = stats.get("total_signals", 0)
    wins         = stats.get("wins", 0)
    losses       = stats.get("losses", 0)
    pending      = stats.get("pending", 0)
    win_rate     = stats.get("win_rate", 0.0)
    profit_factor= stats.get("profit_factor", 0.0)
    avg_rr       = stats.get("avg_rr", 0.0)
    best_signal  = stats.get("best_signal", "N/A")
    total_pips   = stats.get("total_pips", 0.0)

    emoji_wr = "🟢" if win_rate >= 60 else "🟡" if win_rate >= 50 else "🔴"

    return (
        f"📊 <b>Performance Report — {period}</b>\n"
        f"{'─' * 38}\n"
        f"\n"
        f"📨 <b>Total Signals:</b>   {total}\n"
        f"✅ <b>Wins:</b>            {wins}\n"
        f"❌ <b>Losses:</b>          {losses}\n"
        f"⏳ <b>Pending:</b>         {pending}\n"
        f"\n"
        f"{emoji_wr} <b>Win Rate:</b>       {win_rate:.1f}%\n"
        f"⚖️ <b>Profit Factor:</b>  {profit_factor:.2f}\n"
        f"📐 <b>Average RR:</b>     1:{avg_rr:.2f}\n"
        f"💰 <b>Total Pips:</b>     {total_pips:+.1f}\n"
        f"\n"
        f"{'─' * 38}\n"
        f"🏆 <b>Best Signal:</b>    {best_signal}\n"
    )


def format_admin_stats(stats: dict[str, Any]) -> str:
    """Format admin-level stats (users, revenue, errors)."""
    total_users   = stats.get("total_users", 0)
    active_users  = stats.get("active_users", 0)
    premium_users = stats.get("premium_users", 0)
    signals_today = stats.get("signals_today", 0)
    errors_today  = stats.get("errors_today", 0)
    uptime        = stats.get("uptime", "N/A")

    return (
        f"🛠 <b>Admin Dashboard</b>\n"
        f"{'─' * 38}\n"
        f"\n"
        f"👥 <b>Total Users:</b>     {total_users}\n"
        f"🟢 <b>Active (24h):</b>   {active_users}\n"
        f"💎 <b>Premium:</b>        {premium_users}\n"
        f"\n"
        f"📡 <b>Signals Today:</b>  {signals_today}\n"
        f"⚠️ <b>Errors Today:</b>  {errors_today}\n"
        f"⏱ <b>Uptime:</b>         {uptime}\n"
    )


def format_signal_summary_line(signal: dict[str, Any]) -> str:
    """One-line summary of a signal (for lists)."""
    direction = signal.get("direction", "BUY")
    entry     = signal.get("entry", 0.0)
    confidence= signal.get("confidence", 0)
    grade     = signal.get("grade", "C")
    timestamp = signal.get("timestamp", "")
    if isinstance(timestamp, datetime):
        ts_str = timestamp.strftime("%H:%M")
    else:
        ts_str = str(timestamp)[:5]

    dir_emoji = DIRECTION_EMOJI.get(direction, "")
    return f"{dir_emoji} {direction} @ {entry:.2f} | {confidence}% | Grade {grade} | {ts_str}"


def format_welcome_message(first_name: str) -> str:
    """Welcome message sent on /start."""
    return (
        f"👋 <b>Welcome, {first_name}!</b>\n"
        f"\n"
        f"🤖 <b>XAUUSD AI Signal Bot</b>\n"
        f"Professional Gold Trading Signals powered by Smart Money Concepts\n"
        f"\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"\n"
        f"📡 <b>What I do:</b>\n"
        f"• Scan M1, M5, M15, H1, H4 timeframes\n"
        f"• Detect Order Blocks, FVGs & Liquidity\n"
        f"• AI Confidence Scoring (0–100%)\n"
        f"• Entry, Stop Loss & 3× Take Profits\n"
        f"• Chart screenshots with every signal\n"
        f"\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"\n"
        f"<b>Commands:</b>\n"
        f"/signal  — Request a manual scan now\n"
        f"/stats   — View performance statistics\n"
        f"/help    — Show all commands\n"
        f"\n"
        f"⚠️ <i>Not financial advice.</i>"
    )


def format_help_message() -> str:
    """Full help text."""
    return (
        f"📖 <b>XAUUSD Signal Bot — Commands</b>\n"
        f"{'─' * 38}\n"
        f"\n"
        f"<b>User Commands:</b>\n"
        f"/start    — Register and welcome message\n"
        f"/signal   — Run a manual market scan\n"
        f"/stats    — Your signal performance\n"
        f"/help     — This help message\n"
        f"\n"
        f"<b>Admin Commands:</b>\n"
        f"/admin    — Admin dashboard\n"
        f"/users    — List registered users\n"
        f"/broadcast <i>msg</i> — Send message to all users\n"
        f"/signals  — Recent signal history\n"
        f"/logs     — Last 20 log lines\n"
        f"/reports  — Weekly performance report\n"
    )
