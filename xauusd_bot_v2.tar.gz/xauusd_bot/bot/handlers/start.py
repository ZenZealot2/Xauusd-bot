"""
bot/handlers/start.py
=====================
Handles:
  /start   — Register user and show welcome
  /help    — Command reference
  Callback: main_menu navigation
"""

from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
from telegram.constants import ParseMode

from database.operations import upsert_user
from bot.keyboards.menus import main_menu, stats_period_menu
from utils.formatters    import format_welcome_message, format_help_message
from utils.logger        import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# /start
# ─────────────────────────────────────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user:
        return

    # Register / update user in DB
    upsert_user(
        telegram_id=user.id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name,
    )

    text = format_welcome_message(user.first_name or "Trader")
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu(),
    )
    logger.info(f"User {user.id} ({user.username}) started the bot.")


# ─────────────────────────────────────────────────────────────────────────────
# /help
# ─────────────────────────────────────────────────────────────────────────────

async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        format_help_message(),
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu(),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callback handler for main menu buttons
# ─────────────────────────────────────────────────────────────────────────────

async def cb_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "help":
        await query.edit_message_text(
            format_help_message(),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu(),
        )

    elif data == "cancel":
        await query.edit_message_text("✅ Cancelled.", reply_markup=main_menu())

    else:
        # Pass control back to the calling handler (e.g. stats buttons)
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Handler builders (imported by main.py)
# ─────────────────────────────────────────────────────────────────────────────

def get_handlers():
    return [
        CommandHandler("start", cmd_start),
        CommandHandler("help",  cmd_help),
        CallbackQueryHandler(cb_main_menu, pattern="^(help|cancel)$"),
    ]
