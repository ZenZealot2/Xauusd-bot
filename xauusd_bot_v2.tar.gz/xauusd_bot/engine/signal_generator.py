"""
engine/signal_generator.py
==========================
Updated signal pipeline integrating:
  - Adaptive confidence scoring
  - Auto-trader execution (if enabled)
  - Per-signal confidence method tracking
  - Duplicate signal guard (same direction within 15 min)
"""

from __future__ import annotations

import json
import traceback
from datetime import datetime, timedelta
from typing import Any, Optional

from analysis.multi_timeframe  import run_full_analysis
from engine.confidence         import calculate_confidence
from engine.risk_management    import calculate_risk_parameters
from engine.adaptive_confidence import get_adaptive_threshold
from database.operations        import (
    save_signal, count_signals_today,
    get_last_signal_direction, log_error,
    get_recent_signals,
)
from config.settings import (
    MIN_CONFIDENCE_SCORE, MAX_SIGNALS_PER_DAY, MIN_RR_RATIO,
    AUTO_TRADE_ENABLED,
)
from utils.helpers import now_utc, round_price
from utils.logger  import get_logger

logger = get_logger(__name__)

# ── Duplicate signal guard ────────────────────────────────────────────────────
_DUPLICATE_GUARD_MINUTES = 15   # Don't repeat same direction within this window
_last_signal_time: Optional[datetime] = None
_last_signal_dir:  Optional[str]      = None


def _is_duplicate(direction: str) -> bool:
    global _last_signal_time, _last_signal_dir
    if _last_signal_time is None or _last_signal_dir != direction:
        return False
    age = (now_utc() - _last_signal_time).total_seconds() / 60
    return age < _DUPLICATE_GUARD_MINUTES


def _record_signal_generated(direction: str) -> None:
    global _last_signal_time, _last_signal_dir
    _last_signal_time = now_utc()
    _last_signal_dir  = direction


# ─────────────────────────────────────────────────────────────────────────────
# Signal dict builder
# ─────────────────────────────────────────────────────────────────────────────

def _build_signal(mtf, confidence, risk) -> dict[str, Any]:
    reasons = [r for r in confidence.all_reasons
               if r.strip() and "⚠️" not in r][:8]

    return {
        "direction":           risk.direction,
        "classification":      confidence.classification,
        "grade":               confidence.grade,
        "confidence":          confidence.total_score,
        "confidence_method":   confidence.method,
        "threshold_used":      confidence.threshold_used,
        "entry":               risk.entry,
        "stop_loss":           risk.stop_loss,
        "tp1":                 risk.tp1,
        "tp2":                 risk.tp2,
        "tp3":                 risk.tp3,
        "rr_ratio":            risk.rr_tp2,
        "rr_tp1":              risk.rr_tp1,
        "rr_tp2":              risk.rr_tp2,
        "rr_tp3":              risk.rr_tp3,
        "risk_pips":           risk.risk_pips,
        "lots":                risk.position_size_lots,
        "dollar_risk":         risk.dollar_risk,
        "break_even":          risk.break_even,
        "trailing_pips":       risk.trailing_stop_pips,
        "sl_method":           risk.sl_method,
        "trend":               mtf.htf_direction,
        "session":             mtf.session.current_session,
        "session_desc":        mtf.session.description,
        "reasons":             reasons,
        "timestamp":           now_utc(),
        "news_status":         mtf.news.reason,
        "score_breakdown":     confidence.score_breakdown,
        "analysis": {
            "h4_trend":   mtf.h4.trend.direction   if mtf.h4.trend   else "N/A",
            "h1_trend":   mtf.h1.trend.direction   if mtf.h1.trend   else "N/A",
            "m15_trend":  (mtf.m15.market_structure.trend
                           if mtf.m15.market_structure else "N/A"),
            "rsi":        mtf.m5.momentum.rsi            if mtf.m5.momentum else 0,
            "macd":       mtf.m5.momentum.macd_direction if mtf.m5.momentum else "neutral",
            "atr":        mtf.m5.momentum.atr            if mtf.m5.momentum else 0,
            "session":    mtf.session.current_session,
            "rvol":       mtf.m15.volume.rvol         if mtf.m15.volume         else 0,
            "bos":        bool(mtf.m15.market_structure and mtf.m15.market_structure.last_bos),
            "choch":      bool(mtf.m15.market_structure and mtf.m15.market_structure.last_choch),
            "in_ob":      bool(mtf.m15.order_blocks and mtf.m15.order_blocks.price_in_ob),
            "in_fvg":     bool(mtf.m15.fvg          and mtf.m15.fvg.price_in_fvg),
            "sweep":      bool(mtf.m15.smart_money   and mtf.m15.smart_money.last_sweep),
            "score_breakdown": confidence.score_breakdown,
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# Validation guards
# ─────────────────────────────────────────────────────────────────────────────

def _validate(signal, mtf, confidence, risk) -> tuple[bool, str]:
    threshold = get_adaptive_threshold()

    if confidence.total_score < threshold:
        return False, f"Score {confidence.total_score} < adaptive threshold {threshold}"

    if not confidence.should_generate:
        return False, f"Class={confidence.classification} below threshold"

    if risk.rr_tp1 < MIN_RR_RATIO:
        return False, f"RR {risk.rr_tp1:.1f} < minimum {MIN_RR_RATIO}"

    if risk.entry <= 0 or risk.stop_loss <= 0 or risk.tp1 <= 0:
        return False, "Invalid risk parameters (zero/negative)"

    if risk.direction == "BUY" and risk.stop_loss >= risk.entry:
        return False, "BUY: SL must be below entry"

    if risk.direction == "SELL" and risk.stop_loss <= risk.entry:
        return False, "SELL: SL must be above entry"

    if count_signals_today() >= MAX_SIGNALS_PER_DAY:
        return False, f"Daily signal cap reached ({MAX_SIGNALS_PER_DAY})"

    if mtf.session.current_session == "Closed":
        return False, "Market closed"

    if mtf.news.should_avoid:
        return False, mtf.news.reason

    if _is_duplicate(risk.direction):
        return False, f"Duplicate {risk.direction} signal within {_DUPLICATE_GUARD_MINUTES} min"

    return True, ""


# ─────────────────────────────────────────────────────────────────────────────
# Main generator
# ─────────────────────────────────────────────────────────────────────────────

def generate_signal() -> Optional[dict[str, Any]]:
    """
    Full signal generation pipeline.
    Returns a signal dict (already persisted to DB) or None.
    """
    logger.info("SignalGenerator: starting scan…")

    try:
        # 1. Multi-timeframe analysis
        mtf = run_full_analysis()
        if not mtf.can_generate:
            logger.info(f"SignalGenerator: blocked — {mtf.blocking_reason}")
            return None

        # 2. Adaptive confidence scoring
        confidence = calculate_confidence(mtf)
        if not confidence.should_generate:
            logger.info(
                f"SignalGenerator: insufficient confidence — "
                f"{confidence.total_score}/100 ({confidence.grade}) "
                f"[{confidence.method}] threshold={confidence.threshold_used}"
            )
            return None

        # 3. Risk parameters
        ob  = mtf.m15.order_blocks.matching_ob if mtf.m15.order_blocks else None
        fvg_match = None
        if mtf.m15.fvg and mtf.m15.fvg.price_in_fvg:
            fvg_match = next(
                (f for f in reversed(mtf.m15.fvg.active_fvgs)
                 if f.price_in_fvg(mtf.current_price)),
                None,
            )

        sh = mtf.m15.market_structure.swing_highs if mtf.m15.market_structure else []
        sl = mtf.m15.market_structure.swing_lows  if mtf.m15.market_structure else []

        risk = calculate_risk_parameters(
            df=mtf.m15.df,
            direction=mtf.signal_direction,
            current_price=mtf.current_price,
            ob=ob, fvg=fvg_match,
            swing_highs=sh, swing_lows=sl,
        )

        # 4. Build and validate signal
        signal = _build_signal(mtf, confidence, risk)
        is_valid, reason = _validate(signal, mtf, confidence, risk)
        if not is_valid:
            logger.info(f"SignalGenerator: validation failed — {reason}")
            return None

        # 5. Persist to DB
        signal_id = save_signal(signal)
        signal["id"] = signal_id
        _record_signal_generated(risk.direction)

        logger.info(
            f"✅ SIGNAL #{signal_id} | {signal['direction']} | "
            f"entry={signal['entry']} SL={signal['stop_loss']} "
            f"conf={signal['confidence']}% ({signal['grade']}) "
            f"[{confidence.method}]"
        )

        # 6. Auto-trade execution (if enabled)
        if AUTO_TRADE_ENABLED:
            _execute_auto_trade(signal)

        return signal

    except Exception as exc:
        tb = traceback.format_exc()
        logger.error(f"SignalGenerator: error: {exc}\n{tb}")
        log_error("signal_generator", str(exc), tb)
        return None


def _execute_auto_trade(signal: dict[str, Any]) -> None:
    """Attempt to open a trade via MT5 auto-trader."""
    try:
        from engine.auto_trader import open_trade, is_connected, connect
        if not is_connected():
            connect()
        result = open_trade(signal["direction"], signal)
        if result.success:
            logger.info(
                f"AutoTrade: order opened | ticket={result.ticket} "
                f"price={result.entry_price:.2f}"
            )
        else:
            logger.warning(f"AutoTrade: order failed — {result.message}")
    except Exception as exc:
        logger.error(f"AutoTrade: execution error: {exc}")


def run_manual_scan() -> Optional[dict[str, Any]]:
    """Triggered by /signal command."""
    logger.info("SignalGenerator: manual scan requested.")
    return generate_signal()
