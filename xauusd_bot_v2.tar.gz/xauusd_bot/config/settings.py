"""
config/settings.py
==================
Centralised configuration. All env variables are loaded and type-cast here.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

# ─── Telegram ────────────────────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
if not TELEGRAM_BOT_TOKEN:
    raise ValueError("TELEGRAM_BOT_TOKEN is not set in .env")

_raw_admins = os.getenv("ADMIN_CHAT_IDS", "")
ADMIN_CHAT_IDS: list[int] = (
    [int(x.strip()) for x in _raw_admins.split(",") if x.strip()]
    if _raw_admins else []
)
CHANNEL_ID: str = os.getenv("CHANNEL_ID", "")

# ─── Data Source ─────────────────────────────────────────────────────────────
DATA_SOURCE: str = os.getenv("DATA_SOURCE", "twelvedata").lower()
TWELVEDATA_API_KEY: str = os.getenv("TWELVEDATA_API_KEY", "")
TWELVEDATA_SYMBOL: str = os.getenv("TWELVEDATA_SYMBOL", "XAU/USD")
MT5_LOGIN: int = int(os.getenv("MT5_LOGIN", "0"))
MT5_PASSWORD: str = os.getenv("MT5_PASSWORD", "")
MT5_SERVER: str = os.getenv("MT5_SERVER", "")
MT5_SYMBOL: str = os.getenv("MT5_SYMBOL", "XAUUSD")
GOLD_TICKER: str = os.getenv("GOLD_TICKER", "GC=F")  # yfinance fallback

TIMEFRAMES = ["M1", "M5", "M15", "H1", "H4"]

# TwelveData interval mapping
TWELVEDATA_INTERVALS: dict[str, str] = {
    "M1": "1min", "M5": "5min", "M15": "15min", "H1": "1h", "H4": "4h",
}
# yfinance fallback intervals
YFINANCE_INTERVALS: dict[str, str] = {
    "M1": "1m", "M5": "5m", "M15": "15m", "H1": "1h", "H4": "1h",
}
YFINANCE_PERIODS: dict[str, str] = {
    "M1": "5d", "M5": "60d", "M15": "60d", "H1": "2y", "H4": "2y",
}
BARS_TO_KEEP: dict[str, int] = {
    "M1": 300, "M5": 300, "M15": 300, "H1": 200, "H4": 200,
}
# Cache TTLs in seconds (TwelveData API budget-aware)
CACHE_TTL: dict[str, int] = {
    "M1": 30, "M5": 60, "M15": 180, "H1": 600, "H4": 900,
}
# TwelveData: refresh HTFs less often to save API credits
TD_REFRESH_EVERY: dict[str, int] = {
    "M1": 1, "M5": 1, "M15": 3, "H1": 6, "H4": 12,
}  # multiples of SIGNAL_INTERVAL_MINUTES

# ─── Auto-Trading (MT5) ──────────────────────────────────────────────────────
AUTO_TRADE_ENABLED: bool = os.getenv("AUTO_TRADE_ENABLED", "false").lower() == "true"
AUTO_TRADE_LOT_SIZE: float = float(os.getenv("AUTO_TRADE_LOT_SIZE", "0.01"))
AUTO_TRADE_MAGIC: int = int(os.getenv("AUTO_TRADE_MAGIC", "202400"))
AUTO_TRADE_MAX_OPEN: int = int(os.getenv("AUTO_TRADE_MAX_OPEN", "2"))
AUTO_TRADE_SLIPPAGE: int = int(os.getenv("AUTO_TRADE_SLIPPAGE", "3"))

# ─── Signal Settings ─────────────────────────────────────────────────────────
SIGNAL_INTERVAL_MINUTES: int = int(os.getenv("SIGNAL_INTERVAL_MINUTES", "5"))
MIN_CONFIDENCE_SCORE: int = int(os.getenv("MIN_CONFIDENCE_SCORE", "70"))
MAX_SIGNALS_PER_DAY: int = int(os.getenv("MAX_SIGNALS_PER_DAY", "10"))

# ─── Adaptive Confidence ─────────────────────────────────────────────────────
ADAPTIVE_CONFIDENCE_ENABLED: bool = os.getenv("ADAPTIVE_CONFIDENCE_ENABLED", "true").lower() == "true"
ADAPTIVE_LOOKBACK_SIGNALS: int = int(os.getenv("ADAPTIVE_LOOKBACK_SIGNALS", "30"))
ML_CONFIDENCE_ENABLED: bool = os.getenv("ML_CONFIDENCE_ENABLED", "false").lower() == "true"
ML_MODEL_PATH: Path = BASE_DIR / "database" / "confidence_model.pkl"

# ─── Risk Management ─────────────────────────────────────────────────────────
ACCOUNT_BALANCE: float = float(os.getenv("ACCOUNT_BALANCE", "10000"))
RISK_PER_TRADE_PCT: float = float(os.getenv("RISK_PER_TRADE_PCT", "1.0"))
MIN_RR_RATIO: float = float(os.getenv("MIN_RR_RATIO", "2.0"))

# ─── Backtesting Realism ─────────────────────────────────────────────────────
BT_SPREAD_PIPS: float = float(os.getenv("BT_SPREAD_PIPS", "3.0"))
BT_SLIPPAGE_PIPS: float = float(os.getenv("BT_SLIPPAGE_PIPS", "1.0"))
BT_COMMISSION_PER_LOT: float = float(os.getenv("BT_COMMISSION_PER_LOT", "0.0"))

# ─── Analysis Parameters ─────────────────────────────────────────────────────
SWING_LOOKBACK: int = 5
FVG_MIN_SIZE_PIPS: float = 1.0          # Raised from 0.5 → stricter filter
FVG_MAX_AGE_BARS: int = 50              # Ignore FVGs older than this
OB_MIN_MOVE_MULTIPLIER: float = 1.5
OB_MAX_AGE_BARS: int = 80              # Ignore OBs older than this
EMA_FAST: int = 50
EMA_SLOW: int = 200
RSI_PERIOD: int = 14
RSI_OVERBOUGHT: int = 70
RSI_OVERSOLD: int = 30
MACD_FAST: int = 12
MACD_SLOW: int = 26
MACD_SIGNAL: int = 9
ATR_PERIOD: int = 14
ATR_SL_MULTIPLIER: float = 1.5
VOLUME_MA_PERIOD: int = 20
VOLUME_SPIKE_THRESHOLD: float = 1.5
LIQUIDITY_TOLERANCE_PCT: float = 0.002  # 0.2%
BOS_MIN_BREAK_PIPS: float = 1.0         # Min pips to confirm a BOS

# ─── Confidence Score Weights (baseline) ─────────────────────────────────────
SCORE_WEIGHTS: dict[str, int] = {
    "market_structure":       20,
    "liquidity_sweep":        15,
    "order_block":            15,
    "fvg":                    15,
    "trend_alignment":        15,
    "volume_confirmation":    10,
    "momentum_confirmation":   5,
    "session_quality":         5,
}
MAX_SCORE: int = sum(SCORE_WEIGHTS.values())  # 100

# Grade thresholds
GRADE_THRESHOLDS: dict[str, int] = {
    "ELITE": 90, "STRONG": 80, "NORMAL": 70,
}

# ─── News Filter ─────────────────────────────────────────────────────────────
ENABLE_NEWS_FILTER: bool = os.getenv("ENABLE_NEWS_FILTER", "true").lower() == "true"
NEWS_BUFFER_MINUTES: int = int(os.getenv("NEWS_BUFFER_MINUTES", "30"))
HIGH_IMPACT_CURRENCIES: list[str] = ["USD"]
HIGH_IMPACT_KEYWORDS: list[str] = [
    "nfp", "non-farm", "fomc", "cpi", "interest rate", "gdp",
    "unemployment", "pce", "retail sales", "ism", "ppi", "fed",
    "federal reserve", "payroll", "inflation",
]

# ─── Trading Sessions (UTC) ──────────────────────────────────────────────────
SESSIONS: dict[str, dict] = {
    "Asian":   {"start": 0,  "end": 9,  "score": 1, "open": 0},
    "London":  {"start": 7,  "end": 16, "score": 5, "open": 7},
    "NewYork": {"start": 13, "end": 22, "score": 4, "open": 13},
    "Overlap": {"start": 13, "end": 16, "score": 5},
}

# ─── Chart ───────────────────────────────────────────────────────────────────
CHART_STYLE: str = os.getenv("CHART_STYLE", "dark")
CHART_LOOKBACK_BARS: int = int(os.getenv("CHART_LOOKBACK_BARS", "100"))
CHART_DPI: int = 150
CHART_FIGSIZE: tuple[int, int] = (16, 10)

# ─── Database ────────────────────────────────────────────────────────────────
DB_PATH: Path = BASE_DIR / os.getenv("DB_PATH", "database/xauusd_bot.db")

# ─── Logging ─────────────────────────────────────────────────────────────────
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_FILE: Path = BASE_DIR / os.getenv("LOG_FILE", "logs/bot.log")

# ─── Subscription ────────────────────────────────────────────────────────────
SUBSCRIPTION_ENABLED: bool = os.getenv("SUBSCRIPTION_ENABLED", "false").lower() == "true"
FREE_SIGNAL_LIMIT: int = int(os.getenv("FREE_SIGNAL_LIMIT", "3"))
