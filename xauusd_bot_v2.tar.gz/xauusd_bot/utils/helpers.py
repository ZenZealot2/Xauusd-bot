"""
utils/helpers.py
================
General-purpose helper functions used across the project.
"""

from __future__ import annotations

import time
import functools
from datetime import datetime, timezone
from typing import Any, Callable, TypeVar

import pytz

from utils.logger import get_logger

logger = get_logger(__name__)
F = TypeVar("F", bound=Callable[..., Any])

# ─────────────────────────────────────────────────────────────────────────────
# Time helpers
# ─────────────────────────────────────────────────────────────────────────────

UTC = pytz.utc


def now_utc() -> datetime:
    """Return current UTC datetime (timezone-aware)."""
    return datetime.now(tz=UTC)


def to_utc(dt: datetime) -> datetime:
    """Ensure a datetime is timezone-aware UTC."""
    if dt.tzinfo is None:
        return UTC.localize(dt)
    return dt.astimezone(UTC)


def utc_hour() -> int:
    """Return current UTC hour (0–23)."""
    return now_utc().hour


def utc_minute() -> int:
    """Return current UTC minute (0–59)."""
    return now_utc().minute


def utc_weekday() -> int:
    """Return current UTC weekday: 0=Monday … 6=Sunday."""
    return now_utc().weekday()


def is_forex_weekend() -> bool:
    """Markets are closed Saturday 22:00 UTC → Sunday 22:00 UTC."""
    wd = utc_weekday()
    h = utc_hour()
    if wd == 5:          # Saturday — always closed
        return True
    if wd == 6 and h < 22:   # Sunday before 22:00 UTC
        return True
    return False


def timestamp_ms() -> int:
    """Return current Unix timestamp in milliseconds."""
    return int(time.time() * 1000)


# ─────────────────────────────────────────────────────────────────────────────
# Price / numeric helpers
# ─────────────────────────────────────────────────────────────────────────────

def round_price(price: float, decimals: int = 2) -> float:
    """Round a price to the given decimal places."""
    return round(price, decimals)


def pct_change(old: float, new: float) -> float:
    """Percentage change from old to new."""
    if old == 0:
        return 0.0
    return ((new - old) / abs(old)) * 100.0


def is_close(a: float, b: float, tolerance: float = 0.002) -> bool:
    """Return True if |a - b| / mid ≤ tolerance (default 0.2%)."""
    mid = (abs(a) + abs(b)) / 2
    if mid == 0:
        return a == b
    return abs(a - b) / mid <= tolerance


def pip_distance(price_a: float, price_b: float) -> float:
    """
    For XAUUSD / Gold, 1 pip = $0.10.
    Returns |a - b| in pips.
    """
    return abs(price_a - price_b) / 0.10


def pips_to_price(pips: float) -> float:
    """Convert pips to price distance for Gold."""
    return pips * 0.10


def calculate_rr(entry: float, stop_loss: float, take_profit: float) -> float:
    """Calculate Risk:Reward ratio."""
    risk = abs(entry - stop_loss)
    reward = abs(take_profit - entry)
    if risk == 0:
        return 0.0
    return round(reward / risk, 2)


# ─────────────────────────────────────────────────────────────────────────────
# Direction helpers
# ─────────────────────────────────────────────────────────────────────────────

def opposite_direction(direction: str) -> str:
    """BUY → SELL, SELL → BUY."""
    return "SELL" if direction.upper() == "BUY" else "BUY"


def direction_sign(direction: str) -> int:
    """BUY → +1, SELL → -1."""
    return 1 if direction.upper() == "BUY" else -1


# ─────────────────────────────────────────────────────────────────────────────
# Decorators
# ─────────────────────────────────────────────────────────────────────────────

def retry(max_attempts: int = 3, delay: float = 2.0, exceptions: tuple = (Exception,)):
    """
    Decorator: retry a function up to *max_attempts* times on specified exceptions.

    Usage:
        @retry(max_attempts=3, delay=1.5, exceptions=(requests.RequestException,))
        def fetch_data(): ...
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exc: Exception | None = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:
                    last_exc = exc
                    logger.warning(
                        f"[retry] {func.__name__} attempt {attempt}/{max_attempts} "
                        f"failed: {exc}"
                    )
                    if attempt < max_attempts:
                        time.sleep(delay)
            logger.error(f"[retry] {func.__name__} exhausted all {max_attempts} attempts.")
            raise last_exc  # type: ignore[misc]
        return wrapper  # type: ignore[return-value]
    return decorator


def safe_execute(default: Any = None):
    """
    Decorator: return *default* instead of raising on any exception.
    Logs the exception as an error.

    Usage:
        @safe_execute(default={})
        def risky_function(): ...
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as exc:
                logger.error(f"[safe_execute] {func.__name__} raised: {exc}", exc_info=True)
                return default
        return wrapper  # type: ignore[return-value]
    return decorator


# ─────────────────────────────────────────────────────────────────────────────
# List / data-structure helpers
# ─────────────────────────────────────────────────────────────────────────────

def clamp(value: float, min_val: float, max_val: float) -> float:
    """Clamp value between min and max."""
    return max(min_val, min(max_val, value))


def flatten(nested: list) -> list:
    """Flatten one level of nesting."""
    return [item for sublist in nested for item in sublist]


def chunk(lst: list, size: int) -> list[list]:
    """Split list into chunks of *size*."""
    return [lst[i: i + size] for i in range(0, len(lst), size)]


def safe_get(d: dict, *keys, default=None):
    """Safely navigate a nested dict: safe_get(d, 'a', 'b', 'c', default=0)."""
    for key in keys:
        if not isinstance(d, dict):
            return default
        d = d.get(key, default)
    return d
