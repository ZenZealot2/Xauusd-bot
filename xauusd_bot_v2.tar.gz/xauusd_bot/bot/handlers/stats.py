"""
bot/handlers/stats.py
=====================
Handles:
  /stats           — Personal signal performance
  Callback: stats_daily / stats_weekly / stats_monthly / stats_all
"""

from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
from telegram.constants import ParseMode

from database.operations  import calculate_statistics
from bot.keyboards.menus  import main_menu, stats_period_menu
from utils.formatters     import format_stats_message
from utils.logger         import get_logger

logger = get_logger(__name__)

_PERIOD_MAP = {
    "stats_daily":   ("daily",   "Today"),
    "stats_weekly":  ("weekly",  "This Week"),
    "stats_monthly": ("monthly", "This Month"),
    "stats_all":     ("all",     "All Time"),
    "my_stats":      ("all",     "All Time"),
}


async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    stats = calculate_statistics("all")
    text  = format_stats_message(stats, period="All Time")
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=stats_period_menu(),
    )


async def cb_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    data  = query.data

    period_key, label = _PERIOD_MAP.get(data, ("all", "All Time"))
    stats = calculate_statistics(period_key)
    text  = format_stats_message(stats, period=label)

    await query.edit_message_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=stats_period_menu(),
    )


def get_handlers():
    pattern = "^(my_stats|stats_daily|stats_weekly|stats_monthly|stats_all)$"
    return [
        CommandHandler("stats", cmd_stats),
        CallbackQueryHandler(cb_stats, pattern=pattern),
    ]
