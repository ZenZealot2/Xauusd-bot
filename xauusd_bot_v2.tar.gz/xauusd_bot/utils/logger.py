"""
utils/logger.py
===============
Production logging setup: coloured console output + rotating file handler.
Import `get_logger(__name__)` in every module.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path


# ─── ANSI colour codes ───────────────────────────────────────────────────────
class _Colours:
    RESET   = "\033[0m"
    RED     = "\033[91m"
    YELLOW  = "\033[93m"
    GREEN   = "\033[92m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"
    GREY    = "\033[90m"


class _ColourFormatter(logging.Formatter):
    """Formatter that adds colours per log level for the console handler."""

    LEVEL_COLOURS = {
        logging.DEBUG:    _Colours.GREY,
        logging.INFO:     _Colours.CYAN,
        logging.WARNING:  _Colours.YELLOW,
        logging.ERROR:    _Colours.RED,
        logging.CRITICAL: _Colours.RED,
    }

    FMT = "{colour}[{levelname:<8}]{reset} {grey}{asctime}{reset}  {name}  {message}"

    def format(self, record: logging.LogRecord) -> str:
        colour = self.LEVEL_COLOURS.get(record.levelno, _Colours.WHITE)
        fmt = self.FMT.format(
            colour=colour,
            grey=_Colours.GREY,
            reset=_Colours.RESET,
            levelname=record.levelname,
            asctime="%(asctime)s",
            name="%(name)s",
            message="%(message)s",
        )
        formatter = logging.Formatter(fmt, datefmt="%Y-%m-%d %H:%M:%S", style="%")
        return formatter.format(record)


# ─── Global initialisation flag ──────────────────────────────────────────────
_initialised: bool = False


def setup_logging(log_level: str = "INFO", log_file: Path | str | None = None) -> None:
    """
    Call once at application startup (from main.py).

    Parameters
    ----------
    log_level : str
        One of DEBUG | INFO | WARNING | ERROR | CRITICAL
    log_file : Path | str | None
        If provided, logs are also written to this rotating file.
    """
    global _initialised
    if _initialised:
        return

    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    root = logging.getLogger()
    root.setLevel(numeric_level)

    # ── Console handler ──────────────────────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(_ColourFormatter())
    root.addHandler(console_handler)

    # ── Rotating file handler ────────────────────────────────────────────────
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            log_path,
            maxBytes=10 * 1024 * 1024,   # 10 MB
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(
            logging.Formatter(
                fmt="[%(levelname)-8s] %(asctime)s  %(name)s  %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        root.addHandler(file_handler)

    # Silence noisy third-party libraries
    for lib in ("httpx", "httpcore", "telegram", "apscheduler", "yfinance",
                "urllib3", "asyncio"):
        logging.getLogger(lib).setLevel(logging.WARNING)

    _initialised = True


def get_logger(name: str) -> logging.Logger:
    """Return a named logger. Use as: logger = get_logger(__name__)"""
    return logging.getLogger(name)
