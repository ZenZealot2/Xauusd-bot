"""
analysis/trend_filter.py
========================
Trend filter using EMA 50 and EMA 200.

Rules:
  Bullish:  price > EMA50 > EMA200  (or Golden Cross recently)
  Bearish:  price < EMA50 < EMA200  (or Death Cross recently)
  Sideways: EMA50 and EMA200 are flat / tangled

Score contribution: max 15 points.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

from config.settings import EMA_FAST, EMA_SLOW, SCORE_WEIGHTS
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TrendFilterResult:
    direction:    str        # 'Bullish' | 'Bearish' | 'Sideways'
    ema_fast:     float      # Latest EMA50 value
    ema_slow:     float      # Latest EMA200 value
    current_price:float
    golden_cross: bool       # EMA50 crossed above EMA200 recently
    death_cross:  bool       # EMA50 crossed below EMA200 recently
    above_fast:   bool       # Price > EMA50
    above_slow:   bool       # Price > EMA200
    slope_fast:   float      # EMA50 slope over last 5 bars (% per bar)
    slope_slow:   float      # EMA200 slope over last 5 bars
    score:        int
    reasons:      list[str]


# ─────────────────────────────────────────────────────────────────────────────
# EMA calculation
# ─────────────────────────────────────────────────────────────────────────────

def calculate_ema(series: pd.Series, period: int) -> pd.Series:
    """
    Exponential Moving Average using pandas ewm.
    adjust=False matches most trading platform behaviour.
    """
    return series.ewm(span=period, adjust=False).mean()


def ema_slope_pct(ema_series: pd.Series, lookback: int = 5) -> float:
    """
    Calculate the slope of an EMA over the last *lookback* bars.
    Returns slope as % change per bar (positive = upward).
    """
    if len(ema_series) < lookback + 1:
        return 0.0
    recent = ema_series.iloc[-lookback - 1:]
    start  = float(recent.iloc[0])
    end    = float(recent.iloc[-1])
    if start == 0:
        return 0.0
    return ((end - start) / abs(start)) * 100.0 / lookback


# ─────────────────────────────────────────────────────────────────────────────
# Cross detection
# ─────────────────────────────────────────────────────────────────────────────

def detect_cross(
    ema_fast: pd.Series,
    ema_slow: pd.Series,
    lookback: int = 20,
) -> tuple[bool, bool]:
    """
    Check if a golden cross (fast crosses above slow) or
    death cross (fast crosses below slow) occurred in the last *lookback* bars.

    Returns (golden_cross, death_cross).
    """
    if len(ema_fast) < lookback + 2:
        return False, False

    recent_fast = ema_fast.iloc[-lookback:]
    recent_slow = ema_slow.iloc[-lookback:]

    golden_cross = False
    death_cross  = False

    for i in range(1, len(recent_fast)):
        prev_diff = float(recent_fast.iloc[i - 1]) - float(recent_slow.iloc[i - 1])
        curr_diff = float(recent_fast.iloc[i])     - float(recent_slow.iloc[i])

        if prev_diff <= 0 < curr_diff:
            golden_cross = True
        elif prev_diff >= 0 > curr_diff:
            death_cross = True

    return golden_cross, death_cross


# ─────────────────────────────────────────────────────────────────────────────
# Trend direction
# ─────────────────────────────────────────────────────────────────────────────

def determine_trend(
    price: float,
    ema_fast_val: float,
    ema_slow_val: float,
    slope_fast: float,
) -> str:
    """
    Determine overall trend direction.

    Bullish:  price > EMA50 AND EMA50 > EMA200 AND slope > 0
    Bearish:  price < EMA50 AND EMA50 < EMA200 AND slope < 0
    Sideways: everything else
    """
    above_fast = price > ema_fast_val
    above_slow = price > ema_slow_val
    fast_above_slow = ema_fast_val > ema_slow_val

    if above_fast and above_slow and fast_above_slow and slope_fast > 0:
        return "Bullish"
    elif not above_fast and not above_slow and not fast_above_slow and slope_fast < 0:
        return "Bearish"
    else:
        return "Sideways"


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_trend(
    df: pd.DataFrame,
    signal_direction: str = "",
) -> TrendFilterResult:
    """
    Full trend filter analysis.

    Parameters
    ----------
    df               : OHLCV DataFrame (preferably H1 or H4)
    signal_direction : 'BUY' | 'SELL' | ''
    """
    score   = 0
    reasons: list[str] = []
    max_score = SCORE_WEIGHTS["trend_alignment"]  # 15

    if len(df) < EMA_SLOW + 10:
        return TrendFilterResult(
            direction="Sideways",
            ema_fast=0.0, ema_slow=0.0,
            current_price=0.0,
            golden_cross=False, death_cross=False,
            above_fast=False, above_slow=False,
            slope_fast=0.0, slope_slow=0.0,
            score=0,
            reasons=["Insufficient data for trend filter"],
        )

    closes = df["close"]
    ema_fast_series = calculate_ema(closes, EMA_FAST)
    ema_slow_series = calculate_ema(closes, EMA_SLOW)

    ema_fast_val  = float(ema_fast_series.iloc[-1])
    ema_slow_val  = float(ema_slow_series.iloc[-1])
    current_price = float(closes.iloc[-1])

    slope_fast = ema_slope_pct(ema_fast_series, lookback=5)
    slope_slow = ema_slope_pct(ema_slow_series, lookback=5)

    golden_cross, death_cross = detect_cross(ema_fast_series, ema_slow_series, lookback=30)

    above_fast = current_price > ema_fast_val
    above_slow = current_price > ema_slow_val

    direction = determine_trend(current_price, ema_fast_val, ema_slow_val, slope_fast)

    # ── Scoring ──────────────────────────────────────────────────────────────
    # Is the detected trend aligned with the intended trade direction?
    direction_aligned = (
        (signal_direction == "BUY"  and direction == "Bullish") or
        (signal_direction == "SELL" and direction == "Bearish") or
        signal_direction == ""
    )

    if direction_aligned and direction != "Sideways":
        score += 8
        reasons.append(f"EMA trend aligned: {direction}")

    if direction_aligned and direction != "Sideways":
        # Extra points for slope confirmation
        if (signal_direction == "BUY"  and slope_fast > 0.01) or \
           (signal_direction == "SELL" and slope_fast < -0.01):
            score += 3
            reasons.append(
                f"EMA50 slope confirms direction ({slope_fast:+.3f}%/bar)"
            )

    if golden_cross and signal_direction in ("BUY", ""):
        score += 2
        reasons.append("Golden Cross (EMA50 crossed above EMA200) ✅")
    elif death_cross and signal_direction in ("SELL", ""):
        score += 2
        reasons.append("Death Cross (EMA50 crossed below EMA200) ✅")

    # EMA separation (clear spread = stronger trend)
    ema_sep_pct = abs(ema_fast_val - ema_slow_val) / ema_slow_val * 100 if ema_slow_val > 0 else 0
    if ema_sep_pct > 0.3 and direction_aligned and direction != "Sideways":
        score += 2
        reasons.append(f"EMA separation = {ema_sep_pct:.2f}% (strong trend)")

    score = min(score, max_score)

    logger.debug(
        f"TrendFilter | direction={direction} EMA50={ema_fast_val:.2f} "
        f"EMA200={ema_slow_val:.2f} GC={golden_cross} DC={death_cross} "
        f"slope_fast={slope_fast:+.4f} score={score}/{max_score}"
    )

    return TrendFilterResult(
        direction=direction,
        ema_fast=ema_fast_val,
        ema_slow=ema_slow_val,
        current_price=current_price,
        golden_cross=golden_cross,
        death_cross=death_cross,
        above_fast=above_fast,
        above_slow=above_slow,
        slope_fast=slope_fast,
        slope_slow=slope_slow,
        score=score,
        reasons=reasons,
    )
