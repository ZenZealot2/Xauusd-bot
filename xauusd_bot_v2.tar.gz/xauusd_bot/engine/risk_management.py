"""
engine/risk_management.py
=========================
Calculates all trade parameters:
  Entry, Stop Loss, Take Profit 1/2/3,
  Position size (1% risk), Risk:Reward ratio,
  Break-even and trailing stop suggestions.

Stop Loss placement priority:
  1. Below/above nearest swing point (if within 1.5× ATR)
  2. Below/above matching OB or FVG zone
  3. ATR × 1.5 fallback

Take Profits:
  TP1 = 1:2 RR
  TP2 = 1:3 RR
  TP3 = 1:5 RR  (swing high/low target if available)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

from config.settings import (
    ACCOUNT_BALANCE,
    RISK_PER_TRADE_PCT,
    MIN_RR_RATIO,
    ATR_PERIOD,
    ATR_SL_MULTIPLIER,
)
from analysis.market_structure import SwingPoint
from analysis.order_blocks     import OrderBlock
from analysis.fair_value_gap   import FVG
from utils.helpers import round_price, calculate_rr
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RiskParameters:
    direction:           str
    entry:               float
    stop_loss:           float
    tp1:                 float
    tp2:                 float
    tp3:                 float
    rr_tp1:              float   # Risk:Reward at TP1
    rr_tp2:              float
    rr_tp3:              float
    risk_pips:           float   # Distance to SL in pips
    position_size_lots:  float   # Lots for 1% account risk
    dollar_risk:         float   # Dollar amount at risk
    break_even:          float   # Price to move SL to BE (at TP1)
    trailing_stop_pips:  float   # Trailing stop size (ATR-based)
    sl_method:           str     # How SL was determined
    valid:               bool    # Meets MIN_RR_RATIO requirement


# ─────────────────────────────────────────────────────────────────────────────
# ATR (local helper)
# ─────────────────────────────────────────────────────────────────────────────

def _latest_atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> float:
    """Calculate ATR and return the most recent value."""
    high  = df["high"]
    low   = df["low"]
    prev  = df["close"].shift(1)

    tr = pd.concat([
        high - low,
        (high - prev).abs(),
        (low  - prev).abs(),
    ], axis=1).max(axis=1)

    atr = tr.ewm(alpha=1 / period, adjust=False).mean()
    return float(atr.iloc[-1]) if not atr.empty else 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Stop Loss calculation
# ─────────────────────────────────────────────────────────────────────────────

def calculate_stop_loss(
    entry: float,
    direction: str,
    atr: float,
    swing_highs: list[SwingPoint] | None = None,
    swing_lows:  list[SwingPoint] | None = None,
    ob: Optional[OrderBlock] = None,
    fvg: Optional[FVG] = None,
    buffer_pct: float = 0.001,   # 0.1% buffer beyond SL level
) -> tuple[float, str]:
    """
    Determine the best stop loss for the trade.

    Returns (stop_loss_price, method_description).
    """
    atr_sl = atr * ATR_SL_MULTIPLIER
    candidates: list[tuple[float, str]] = []
    buffer = entry * buffer_pct

    if direction.upper() == "BUY":
        # SL should be BELOW entry

        # Swing low (nearest below entry, within 2× ATR)
        if swing_lows:
            sl_candidates = sorted(
                [s for s in swing_lows if s.price < entry and (entry - s.price) <= 2 * atr],
                key=lambda s: entry - s.price
            )
            if sl_candidates:
                sl_price = sl_candidates[0].price - buffer
                candidates.append((sl_price, "Below nearest swing low"))

        # OB bottom
        if ob and ob.kind == "bullish":
            sl_price = ob.bottom - buffer
            candidates.append((sl_price, "Below bullish Order Block"))

        # FVG bottom
        if fvg and fvg.kind == "bullish":
            sl_price = fvg.bottom - buffer
            candidates.append((sl_price, "Below bullish FVG"))

        # ATR fallback
        candidates.append((entry - atr_sl, f"ATR({ATR_PERIOD}) × {ATR_SL_MULTIPLIER}"))

        # Pick the closest one to entry (smallest risk) that's still valid
        valid = [(p, m) for p, m in candidates if p < entry]
        if valid:
            valid.sort(key=lambda x: entry - x[0])   # smallest distance first
            return round_price(valid[0][0]), valid[0][1]

    else:  # SELL
        # SL should be ABOVE entry
        if swing_highs:
            sh_candidates = sorted(
                [s for s in swing_highs if s.price > entry and (s.price - entry) <= 2 * atr],
                key=lambda s: s.price - entry
            )
            if sh_candidates:
                sl_price = sh_candidates[0].price + buffer
                candidates.append((sl_price, "Above nearest swing high"))

        if ob and ob.kind == "bearish":
            sl_price = ob.top + buffer
            candidates.append((sl_price, "Above bearish Order Block"))

        if fvg and fvg.kind == "bearish":
            sl_price = fvg.top + buffer
            candidates.append((sl_price, "Above bearish FVG"))

        candidates.append((entry + atr_sl, f"ATR({ATR_PERIOD}) × {ATR_SL_MULTIPLIER}"))

        valid = [(p, m) for p, m in candidates if p > entry]
        if valid:
            valid.sort(key=lambda x: x[0] - entry)
            return round_price(valid[0][0]), valid[0][1]

    # Ultimate fallback
    fallback = entry - atr_sl if direction.upper() == "BUY" else entry + atr_sl
    return round_price(fallback), "ATR fallback"


# ─────────────────────────────────────────────────────────────────────────────
# Take profit calculation
# ─────────────────────────────────────────────────────────────────────────────

def calculate_take_profits(
    entry: float,
    stop_loss: float,
    direction: str,
    swing_highs: list[SwingPoint] | None = None,
    swing_lows:  list[SwingPoint] | None = None,
) -> tuple[float, float, float]:
    """
    Calculate TP1 (1:2), TP2 (1:3), TP3 (1:5 or next swing extreme).
    Returns (tp1, tp2, tp3).
    """
    risk = abs(entry - stop_loss)

    if direction.upper() == "BUY":
        tp1 = entry + risk * 2.0
        tp2 = entry + risk * 3.0
        tp3 = entry + risk * 5.0

        # If a swing high target is within 1:4–1:7 range, use it as TP3
        if swing_highs:
            far_highs = [
                s.price for s in swing_highs
                if entry < s.price < entry + risk * 7.0
            ]
            if far_highs:
                tp3_candidate = max(far_highs)
                rr_candidate  = (tp3_candidate - entry) / risk
                if rr_candidate >= 4.0:
                    tp3 = tp3_candidate

    else:
        tp1 = entry - risk * 2.0
        tp2 = entry - risk * 3.0
        tp3 = entry - risk * 5.0

        if swing_lows:
            far_lows = [
                s.price for s in swing_lows
                if entry > s.price > entry - risk * 7.0
            ]
            if far_lows:
                tp3_candidate = min(far_lows)
                rr_candidate  = (entry - tp3_candidate) / risk
                if rr_candidate >= 4.0:
                    tp3 = tp3_candidate

    return round_price(tp1), round_price(tp2), round_price(tp3)


# ─────────────────────────────────────────────────────────────────────────────
# Position sizing (1% risk model)
# ─────────────────────────────────────────────────────────────────────────────

def calculate_position_size(
    entry: float,
    stop_loss: float,
    account_balance: float = ACCOUNT_BALANCE,
    risk_pct: float = RISK_PER_TRADE_PCT,
) -> tuple[float, float]:
    """
    Calculate position size in lots for given risk %.

    For XAUUSD standard lot (100 oz):
      $1 per pip per 0.01 lot  →  $10 per pip per 0.1 lot  →  $100 per pip per 1 lot

    pip = $0.10
    risk_dollars = balance × risk_pct / 100
    position_size = risk_dollars / (pips_at_risk × pip_value_per_lot)

    Returns (position_size_lots, dollar_risk).
    """
    risk_dollars = account_balance * (risk_pct / 100)
    pips_at_risk = abs(entry - stop_loss) / 0.10
    pip_value_per_lot = 100.0   # USD per pip per lot for Gold

    if pips_at_risk <= 0:
        return 0.01, risk_dollars

    position_size = risk_dollars / (pips_at_risk * pip_value_per_lot)
    position_size = max(0.01, round(position_size, 2))

    return position_size, round(risk_dollars, 2)


# ─────────────────────────────────────────────────────────────────────────────
# Entry refinement
# ─────────────────────────────────────────────────────────────────────────────

def refine_entry(
    direction: str,
    current_price: float,
    ob: Optional[OrderBlock] = None,
    fvg: Optional[FVG] = None,
) -> float:
    """
    Suggest the best entry price.

    For BUY:
      - Middle of OB (if price is in OB) or FVG mid
      - Otherwise: current market price

    For SELL: same logic inverted.
    """
    if direction.upper() == "BUY":
        if ob and ob.kind == "bullish" and ob.price_in_ob(current_price):
            # Entry at OB mid (slight discount)
            return round_price(ob.mid)
        if fvg and fvg.kind == "bullish" and fvg.price_in_fvg(current_price):
            return round_price(fvg.mid)
    else:
        if ob and ob.kind == "bearish" and ob.price_in_ob(current_price):
            return round_price(ob.mid)
        if fvg and fvg.kind == "bearish" and fvg.price_in_fvg(current_price):
            return round_price(fvg.mid)

    return round_price(current_price)


# ─────────────────────────────────────────────────────────────────────────────
# Main calculation
# ─────────────────────────────────────────────────────────────────────────────

def calculate_risk_parameters(
    df: pd.DataFrame,
    direction: str,
    current_price: float,
    ob: Optional[OrderBlock] = None,
    fvg: Optional[FVG] = None,
    swing_highs: list[SwingPoint] | None = None,
    swing_lows:  list[SwingPoint] | None = None,
) -> RiskParameters:
    """
    Build the complete RiskParameters object for a potential trade.

    Parameters
    ----------
    df            : OHLCV DataFrame (used for ATR)
    direction     : 'BUY' | 'SELL'
    current_price : Latest price
    ob            : Matching Order Block (optional)
    fvg           : Matching FVG (optional)
    swing_highs   : From market structure
    swing_lows    : From market structure
    """
    atr = _latest_atr(df)

    # Refine entry
    entry = refine_entry(direction, current_price, ob, fvg)

    # Stop loss
    sl, sl_method = calculate_stop_loss(
        entry, direction, atr, swing_highs, swing_lows, ob, fvg
    )

    # Take profits
    tp1, tp2, tp3 = calculate_take_profits(entry, sl, direction, swing_highs, swing_lows)

    # RR ratios
    rr1 = calculate_rr(entry, sl, tp1)
    rr2 = calculate_rr(entry, sl, tp2)
    rr3 = calculate_rr(entry, sl, tp3)

    # Position size
    lots, dollar_risk = calculate_position_size(entry, sl)

    # Risk in pips
    risk_pips = abs(entry - sl) / 0.10

    # Break even: move SL to entry + a few pips when TP1 is hit
    be_buffer = abs(entry - sl) * 0.05   # 5% beyond entry
    if direction.upper() == "BUY":
        break_even = round_price(entry + be_buffer)
    else:
        break_even = round_price(entry - be_buffer)

    # Trailing stop: 1× ATR
    trailing_pips = atr / 0.10

    # Validate RR
    valid = rr1 >= MIN_RR_RATIO

    logger.debug(
        f"RiskMgmt | dir={direction} entry={entry} sl={sl} "
        f"tp1={tp1} tp2={tp2} tp3={tp3} rr1={rr1} valid={valid} "
        f"sl_method={sl_method}"
    )

    return RiskParameters(
        direction=direction,
        entry=entry,
        stop_loss=sl,
        tp1=tp1,
        tp2=tp2,
        tp3=tp3,
        rr_tp1=rr1,
        rr_tp2=rr2,
        rr_tp3=rr3,
        risk_pips=round(risk_pips, 1),
        position_size_lots=lots,
        dollar_risk=dollar_risk,
        break_even=break_even,
        trailing_stop_pips=round(trailing_pips, 1),
        sl_method=sl_method,
        valid=valid,
    )
