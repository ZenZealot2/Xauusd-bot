"""
analysis/market_structure.py
============================
Improved market structure analysis.

Key improvements over v1:
  - BOS confirmed by CLOSE (not just wick) beyond level
  - BOS requires minimum pip break (BOS_MIN_BREAK_PIPS) to filter micro-breaks
  - CHOCH detection now validates against current trend context
  - Swing points use adaptive lookback based on ATR
  - Trend classification uses weighted HH/HL/LH/LL scoring
  - Premium/discount zone calculation for confluence
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

from config.settings import SWING_LOOKBACK, SCORE_WEIGHTS, BOS_MIN_BREAK_PIPS
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class SwingPoint:
    index:  int
    price:  float
    kind:   str      # 'high' | 'low'
    bar:    object   = field(repr=False, default=None)
    strength: float  = 1.0   # Relative strength (how far it stands out)


@dataclass
class StructureEvent:
    kind:      str      # 'BOS' | 'CHOCH'
    direction: str      # 'bullish' | 'bearish'
    price:     float
    bar_index: int
    break_pips: float  = 0.0
    confirmed:  bool   = True


@dataclass
class MarketStructureResult:
    trend:             str
    swing_highs:       list[SwingPoint]
    swing_lows:        list[SwingPoint]
    last_bos:          Optional[StructureEvent]
    last_choch:        Optional[StructureEvent]
    hh_hl:             bool
    lh_ll:             bool
    structure_events:  list[StructureEvent]
    premium_zone:      float    # Upper 50% of last major swing range
    discount_zone:     float    # Lower 50% of last major swing range
    equilibrium:       float    # 50% of last major swing range
    score:             int
    reasons:           list[str]


# ─────────────────────────────────────────────────────────────────────────────
# ATR helper (avoid circular import)
# ─────────────────────────────────────────────────────────────────────────────

def _atr_simple(df: pd.DataFrame, period: int = 14) -> float:
    high, low, close = df["high"].values, df["low"].values, df["close"].values
    n = len(df)
    tr = np.maximum(high[1:] - low[1:],
         np.maximum(np.abs(high[1:] - close[:-1]),
                    np.abs(low[1:]  - close[:-1])))
    if len(tr) < period:
        return float(np.mean(tr)) if len(tr) > 0 else 1.0
    return float(np.mean(tr[-period:]))


# ─────────────────────────────────────────────────────────────────────────────
# Swing detection
# ─────────────────────────────────────────────────────────────────────────────

def find_swing_highs(df: pd.DataFrame, left: int = SWING_LOOKBACK,
                     right: int = SWING_LOOKBACK) -> list[SwingPoint]:
    """
    Detect pivot highs. Strength = how much the high exceeds neighbors
    relative to ATR (filters noise).
    """
    highs = df["high"].values
    n     = len(df)
    atr   = _atr_simple(df)
    pts: list[SwingPoint] = []

    for i in range(left, n - right):
        window = np.concatenate([highs[i - left: i], highs[i + 1: i + right + 1]])
        h      = highs[i]
        if h <= window.max():
            continue
        strength = (h - window.max()) / atr if atr > 0 else 1.0
        if strength < 0.1:   # too weak to be meaningful
            continue
        pts.append(SwingPoint(index=i, price=float(h), kind="high",
                               bar=df.iloc[i], strength=strength))
    return pts


def find_swing_lows(df: pd.DataFrame, left: int = SWING_LOOKBACK,
                    right: int = SWING_LOOKBACK) -> list[SwingPoint]:
    lows = df["low"].values
    n    = len(df)
    atr  = _atr_simple(df)
    pts: list[SwingPoint] = []

    for i in range(left, n - right):
        window = np.concatenate([lows[i - left: i], lows[i + 1: i + right + 1]])
        l      = lows[i]
        if l >= window.min():
            continue
        strength = (window.min() - l) / atr if atr > 0 else 1.0
        if strength < 0.1:
            continue
        pts.append(SwingPoint(index=i, price=float(l), kind="low",
                               bar=df.iloc[i], strength=strength))
    return pts


# ─────────────────────────────────────────────────────────────────────────────
# HH/HL/LH/LL classification
# ─────────────────────────────────────────────────────────────────────────────

def classify_swings(swing_highs: list[SwingPoint],
                    swing_lows: list[SwingPoint]) -> tuple[str, bool, bool]:
    """Return (trend, hh_hl, lh_ll) using weighted scoring over last 4 swings."""
    if len(swing_highs) < 2 or len(swing_lows) < 2:
        return "Sideways", False, False

    sh = sorted(swing_highs, key=lambda x: x.index)[-4:]
    sl = sorted(swing_lows,  key=lambda x: x.index)[-4:]

    bull_score = 0
    bear_score = 0

    # Each consecutive higher high = +1 bull, lower = +1 bear
    for i in range(1, len(sh)):
        if sh[i].price > sh[i-1].price: bull_score += 1
        elif sh[i].price < sh[i-1].price: bear_score += 1

    # Each consecutive higher low = +1 bull, lower = +1 bear
    for i in range(1, len(sl)):
        if sl[i].price > sl[i-1].price: bull_score += 1
        elif sl[i].price < sl[i-1].price: bear_score += 1

    hh_hl = bull_score >= 3
    lh_ll = bear_score >= 3

    if bull_score > bear_score:
        return "Bullish", hh_hl, lh_ll
    elif bear_score > bull_score:
        return "Bearish", hh_hl, lh_ll
    return "Sideways", False, False


# ─────────────────────────────────────────────────────────────────────────────
# BOS / CHOCH detection (improved)
# ─────────────────────────────────────────────────────────────────────────────

def detect_bos_choch(df: pd.DataFrame, swing_highs: list[SwingPoint],
                     swing_lows: list[SwingPoint],
                     current_trend: str) -> list[StructureEvent]:
    """
    Improved BOS/CHOCH detection:
    - Only confirmed by CLOSE (not wick) beyond the level
    - Requires BOS_MIN_BREAK_PIPS minimum break distance
    - Classifies correctly based on trend context
    - Uses only the MOST RECENT significant swing high/low
    """
    events: list[StructureEvent] = []
    closes = df["close"].values
    n      = len(df)
    min_break = BOS_MIN_BREAK_PIPS * 0.10   # Convert pips to price

    all_sh = sorted(swing_highs, key=lambda x: x.index)
    all_sl = sorted(swing_lows,  key=lambda x: x.index)

    # Consider last 6 swing points only (most relevant)
    recent_sh = all_sh[-6:]
    recent_sl = all_sl[-6:]

    # Check bullish breaks (close above swing high)
    for sh in recent_sh:
        for i in range(sh.index + 1, n):
            break_size = closes[i] - sh.price
            if break_size >= min_break:
                kind = "BOS" if current_trend == "Bullish" else "CHOCH"
                events.append(StructureEvent(
                    kind=kind, direction="bullish",
                    price=sh.price, bar_index=i,
                    break_pips=round(break_size / 0.10, 1),
                ))
                break   # one break per swing level

    # Check bearish breaks (close below swing low)
    for sl in recent_sl:
        for i in range(sl.index + 1, n):
            break_size = sl.price - closes[i]
            if break_size >= min_break:
                kind = "BOS" if current_trend == "Bearish" else "CHOCH"
                events.append(StructureEvent(
                    kind=kind, direction="bearish",
                    price=sl.price, bar_index=i,
                    break_pips=round(break_size / 0.10, 1),
                ))
                break

    events.sort(key=lambda e: e.bar_index)
    return events


# ─────────────────────────────────────────────────────────────────────────────
# Premium / Discount / Equilibrium zones
# ─────────────────────────────────────────────────────────────────────────────

def calculate_pd_zones(swing_highs: list[SwingPoint],
                       swing_lows: list[SwingPoint]) -> tuple[float, float, float]:
    """
    Premium = upper 50% of recent swing range (good for SELL entries)
    Discount = lower 50% of recent swing range (good for BUY entries)
    Equilibrium = 50% level (50% of the total range)
    """
    if not swing_highs or not swing_lows:
        return 0.0, 0.0, 0.0

    sh = sorted(swing_highs, key=lambda x: x.index)
    sl = sorted(swing_lows,  key=lambda x: x.index)

    recent_high = sh[-1].price if sh else 0.0
    recent_low  = sl[-1].price if sl else 0.0

    if recent_high <= recent_low:
        return 0.0, 0.0, 0.0

    equilibrium    = (recent_high + recent_low) / 2
    premium_zone   = equilibrium        # above this = premium
    discount_zone  = equilibrium        # below this = discount
    return premium_zone, discount_zone, equilibrium


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_market_structure(df: pd.DataFrame) -> MarketStructureResult:
    score   = 0
    reasons: list[str] = []
    max_sc  = SCORE_WEIGHTS["market_structure"]

    min_bars = SWING_LOOKBACK * 2 + 10
    if len(df) < min_bars:
        return MarketStructureResult(
            trend="Sideways", swing_highs=[], swing_lows=[],
            last_bos=None, last_choch=None, hh_hl=False, lh_ll=False,
            structure_events=[], premium_zone=0, discount_zone=0, equilibrium=0,
            score=0, reasons=["Insufficient data"],
        )

    swing_highs = find_swing_highs(df)
    swing_lows  = find_swing_lows(df)

    trend, hh_hl, lh_ll = classify_swings(swing_highs, swing_lows)
    events = detect_bos_choch(df, swing_highs, swing_lows, trend)

    last_bos   = next((e for e in reversed(events) if e.kind == "BOS"),   None)
    last_choch = next((e for e in reversed(events) if e.kind == "CHOCH"), None)

    prem, disc, equil = calculate_pd_zones(swing_highs, swing_lows)

    # ── Scoring ──────────────────────────────────────────────────────────────
    if trend in ("Bullish", "Bearish"):
        score += 6
        reasons.append(f"Clear {trend} market structure")

    if hh_hl:
        score += 4
        reasons.append("HH + HL confirmed (bullish continuation)")
    elif lh_ll:
        score += 4
        reasons.append("LH + LL confirmed (bearish continuation)")

    if last_bos:
        score += 6
        reasons.append(
            f"Bullish BOS" if last_bos.direction == "bullish"
            else f"Bearish BOS"
            f" @ {last_bos.price:.2f} (+{last_bos.break_pips:.1f} pips)"
        )

    if last_choch:
        score += 4
        reasons.append(
            f"CHOCH ({last_choch.direction.capitalize()}) — potential reversal"
        )

    score = min(score, max_sc)
    logger.debug(
        f"MktStructure | trend={trend} HH/HL={hh_hl} LH/LL={lh_ll} "
        f"bos={last_bos and last_bos.price:.2f} score={score}/{max_sc}"
    )

    return MarketStructureResult(
        trend=trend,
        swing_highs=swing_highs,
        swing_lows=swing_lows,
        last_bos=last_bos,
        last_choch=last_choch,
        hh_hl=hh_hl,
        lh_ll=lh_ll,
        structure_events=events,
        premium_zone=prem,
        discount_zone=disc,
        equilibrium=equil,
        score=score,
        reasons=reasons,
    )
