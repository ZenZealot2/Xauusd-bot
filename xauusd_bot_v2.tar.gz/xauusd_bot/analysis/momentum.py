"""
analysis/momentum.py
====================
Momentum analysis using RSI 14, MACD (12/26/9), and ATR 14.

Detects:
  - Momentum expansion (strong move beginning)
  - Momentum weakness (move running out of steam)
  - Divergences (price vs RSI)

Score contribution: max 5 points.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

from config.settings import (
    RSI_PERIOD, RSI_OVERBOUGHT, RSI_OVERSOLD,
    MACD_FAST, MACD_SLOW, MACD_SIGNAL,
    ATR_PERIOD, SCORE_WEIGHTS,
)
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MomentumResult:
    rsi:              float
    rsi_signal:       str        # 'bullish' | 'bearish' | 'neutral' | 'overbought' | 'oversold'
    macd:             float
    macd_signal_line: float
    macd_histogram:   float
    macd_direction:   str        # 'bullish' | 'bearish' | 'neutral'
    atr:              float
    atr_pct:          float      # ATR as % of price (volatility measure)
    expansion:        bool       # Momentum expanding
    weakness:         bool       # Momentum weakening
    bullish_div:      bool       # Bullish divergence (price LL but RSI HL)
    bearish_div:      bool       # Bearish divergence (price HH but RSI LH)
    score:            int
    reasons:          list[str]


# ─────────────────────────────────────────────────────────────────────────────
# RSI
# ─────────────────────────────────────────────────────────────────────────────

def calculate_rsi(closes: pd.Series, period: int = RSI_PERIOD) -> pd.Series:
    """Wilder's smoothed RSI."""
    delta  = closes.diff()
    gain   = delta.clip(lower=0)
    loss   = (-delta).clip(lower=0)

    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()

    rs  = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50)


def interpret_rsi(rsi: float, direction: str = "") -> str:
    """Return RSI condition string."""
    if rsi >= RSI_OVERBOUGHT:
        return "overbought"
    elif rsi <= RSI_OVERSOLD:
        return "oversold"
    elif rsi > 55 and direction in ("BUY", ""):
        return "bullish"
    elif rsi < 45 and direction in ("SELL", ""):
        return "bearish"
    return "neutral"


# ─────────────────────────────────────────────────────────────────────────────
# MACD
# ─────────────────────────────────────────────────────────────────────────────

def calculate_macd(
    closes: pd.Series,
    fast: int   = MACD_FAST,
    slow: int   = MACD_SLOW,
    signal: int = MACD_SIGNAL,
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """
    Returns (macd_line, signal_line, histogram).
    """
    ema_fast = closes.ewm(span=fast, adjust=False).mean()
    ema_slow = closes.ewm(span=slow, adjust=False).mean()
    macd_line   = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram   = macd_line - signal_line
    return macd_line, signal_line, histogram


def interpret_macd(macd: float, sig: float, hist: float, prev_hist: float) -> str:
    """Return 'bullish', 'bearish', or 'neutral'."""
    if macd > sig and hist > 0 and hist > prev_hist:
        return "bullish"
    elif macd < sig and hist < 0 and hist < prev_hist:
        return "bearish"
    return "neutral"


# ─────────────────────────────────────────────────────────────────────────────
# ATR
# ─────────────────────────────────────────────────────────────────────────────

def calculate_atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> pd.Series:
    """Average True Range."""
    high  = df["high"]
    low   = df["low"]
    prev_close = df["close"].shift(1)

    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low  - prev_close).abs(),
    ], axis=1).max(axis=1)

    atr = tr.ewm(alpha=1 / period, adjust=False).mean()
    return atr


# ─────────────────────────────────────────────────────────────────────────────
# Divergence detection
# ─────────────────────────────────────────────────────────────────────────────

def detect_divergence(
    closes: pd.Series,
    rsi: pd.Series,
    lookback: int = 30,
) -> tuple[bool, bool]:
    """
    Simplified divergence detection.
    - Bullish div: price makes LL but RSI makes HL
    - Bearish div: price makes HH but RSI makes LH

    Returns (bullish_div, bearish_div).
    """
    if len(closes) < lookback:
        return False, False

    price_slice = closes.iloc[-lookback:]
    rsi_slice   = rsi.iloc[-lookback:]

    # Split into two halves
    mid = lookback // 2
    p_first  = price_slice.iloc[:mid]
    p_second = price_slice.iloc[mid:]
    r_first  = rsi_slice.iloc[:mid]
    r_second = rsi_slice.iloc[mid:]

    # Bullish divergence
    price_ll = p_second.min() < p_first.min()   # price lower low
    rsi_hl   = r_second.min() > r_first.min()   # RSI higher low
    bullish_div = price_ll and rsi_hl

    # Bearish divergence
    price_hh = p_second.max() > p_first.max()   # price higher high
    rsi_lh   = r_second.max() < r_first.max()   # RSI lower high
    bearish_div = price_hh and rsi_lh

    return bullish_div, bearish_div


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_momentum(
    df: pd.DataFrame,
    signal_direction: str = "",
) -> MomentumResult:
    """
    Full momentum analysis.

    Parameters
    ----------
    df               : OHLCV DataFrame (M15 or M5 preferred for entry)
    signal_direction : 'BUY' | 'SELL' | ''
    """
    score   = 0
    reasons: list[str] = []
    max_score = SCORE_WEIGHTS["momentum_confirmation"]  # 5

    closes = df["close"]
    n      = len(df)

    if n < MACD_SLOW + MACD_SIGNAL + 5:
        return MomentumResult(
            rsi=50, rsi_signal="neutral",
            macd=0, macd_signal_line=0, macd_histogram=0,
            macd_direction="neutral",
            atr=0, atr_pct=0,
            expansion=False, weakness=False,
            bullish_div=False, bearish_div=False,
            score=0, reasons=["Insufficient data for momentum analysis"],
        )

    # ── RSI ──────────────────────────────────────────────────────────────────
    rsi_series   = calculate_rsi(closes)
    rsi_val      = float(rsi_series.iloc[-1])
    rsi_signal   = interpret_rsi(rsi_val, signal_direction)

    # ── MACD ─────────────────────────────────────────────────────────────────
    macd_line, sig_line, histogram = calculate_macd(closes)
    macd_val      = float(macd_line.iloc[-1])
    macd_sig_val  = float(sig_line.iloc[-1])
    hist_val      = float(histogram.iloc[-1])
    prev_hist_val = float(histogram.iloc[-2]) if n >= 2 else 0.0
    macd_dir      = interpret_macd(macd_val, macd_sig_val, hist_val, prev_hist_val)

    # ── ATR ──────────────────────────────────────────────────────────────────
    atr_series = calculate_atr(df)
    atr_val    = float(atr_series.iloc[-1])
    current_px = float(closes.iloc[-1])
    atr_pct    = (atr_val / current_px * 100) if current_px > 0 else 0.0

    # ── Expansion / Weakness ─────────────────────────────────────────────────
    # Expansion: ATR increasing over last 5 bars → volatility picking up
    if n >= 6:
        atr_5_ago  = float(atr_series.iloc[-6])
        expansion  = atr_val > atr_5_ago * 1.2   # ATR 20% above 5 bars ago
        weakness   = atr_val < atr_5_ago * 0.8   # ATR 20% below
    else:
        expansion = False
        weakness  = False

    # ── Divergence ──────────────────────────────────────────────────────────
    bullish_div, bearish_div = detect_divergence(closes, rsi_series)

    # ── Scoring ──────────────────────────────────────────────────────────────
    dir_momentum_aligned = (
        (signal_direction == "BUY"  and (rsi_signal in ("bullish", "oversold") or macd_dir == "bullish")) or
        (signal_direction == "SELL" and (rsi_signal in ("bearish", "overbought") or macd_dir == "bearish")) or
        signal_direction == ""
    )

    # Penalise if RSI is extreme opposite
    if (signal_direction == "BUY"  and rsi_val >= RSI_OVERBOUGHT) or \
       (signal_direction == "SELL" and rsi_val <= RSI_OVERSOLD):
        score -= 2
        reasons.append(f"RSI extreme against direction ({rsi_val:.1f}) ⚠️")
    elif dir_momentum_aligned:
        score += 2
        reasons.append(f"RSI ({rsi_val:.1f}) confirms direction")

    if macd_dir != "neutral" and (
        (signal_direction == "BUY"  and macd_dir == "bullish") or
        (signal_direction == "SELL" and macd_dir == "bearish") or
        signal_direction == ""
    ):
        score += 2
        reasons.append(f"MACD {macd_dir} momentum")

    if expansion:
        score += 1
        reasons.append(f"ATR expanding (momentum pick-up): {atr_val:.2f}")

    if (signal_direction == "BUY"  and bullish_div) or \
       (signal_direction == "SELL" and bearish_div):
        score += 1
        reasons.append("Momentum divergence confirms setup ✅")

    score = max(0, min(score, max_score))

    logger.debug(
        f"Momentum | RSI={rsi_val:.1f} MACD={macd_dir} ATR={atr_val:.2f} "
        f"expansion={expansion} score={score}/{max_score}"
    )

    return MomentumResult(
        rsi=rsi_val,
        rsi_signal=rsi_signal,
        macd=macd_val,
        macd_signal_line=macd_sig_val,
        macd_histogram=hist_val,
        macd_direction=macd_dir,
        atr=atr_val,
        atr_pct=atr_pct,
        expansion=expansion,
        weakness=weakness,
        bullish_div=bullish_div,
        bearish_div=bearish_div,
        score=score,
        reasons=reasons,
    )
