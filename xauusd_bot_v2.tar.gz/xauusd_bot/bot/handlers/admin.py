"""
bot/handlers/admin.py
=====================
Admin panel — updated with:
  - Auto-trader status + manual open/close
  - Adaptive confidence weight display
  - Data source status
  - Per-session/grade performance
"""

from __future__ import annotations

import time
from datetime import date, timedelta

from telegram import Update
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
from telegram.constants import ParseMode
from telegram.error import TelegramError

from database.operations import (
    count_users, get_all_users, calculate_statistics,
    get_recent_errors, count_errors_today, get_recent_signals,
    count_signals_today,
)
from performance.backtester import run_backtest, format_backtest_report
from performance.tracker    import get_performance_summary, format_tracker_report
from bot.keyboards.menus    import admin_menu, main_menu
from utils.formatters       import format_admin_stats, format_stats_message
from utils.logger           import get_logger
from config.settings        import ADMIN_CHAT_IDS, AUTO_TRADE_ENABLED

logger = get_logger(__name__)
_BOT_START_TIME = time.time()


def is_admin(uid: int) -> bool:
    return uid in ADMIN_CHAT_IDS


def _uptime() -> str:
    s = int(time.time() - _BOT_START_TIME)
    h, r = divmod(s, 3600); m, s = divmod(r, 60)
    return f"{h}h {m}m {s}s"


async def _guard(update: Update) -> bool:
    user = update.effective_user
    if not user or not is_admin(user.id):
        await update.effective_message.reply_text("⛔ Admin only.")
        return False
    return True


# ── /admin ────────────────────────────────────────────────────────────────────
async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update): return

    from engine.data_fetcher           import get_data_source_info
    from engine.adaptive_confidence    import get_adaptive_threshold, get_current_weights

    uc      = count_users()
    weights = get_current_weights()
    top_w   = sorted(weights.items(), key=lambda x: x[1], reverse=True)[:3]
    top_str = " | ".join(f"{k[:6]}:{v:.0f}" for k, v in top_w)

    text = (
        f"🛠 <b>Admin Dashboard</b>\n{'─'*36}\n\n"
        f"👥 Users: {uc['total']} total / {uc['active']} active / {uc['premium']} premium\n"
        f"📡 Signals today: {count_signals_today()}\n"
        f"⚠️ Errors today: {count_errors_today()}\n"
        f"⏱ Uptime: {_uptime()}\n\n"
        f"📊 Data: <code>{get_data_source_info()}</code>\n"
        f"🤖 AutoTrade: {'✅ ON' if AUTO_TRADE_ENABLED else '❌ OFF'}\n\n"
        f"🧠 Adaptive threshold: <b>{get_adaptive_threshold()}</b>\n"
        f"🔝 Top weights: {top_str}"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=admin_menu())


# ── /users ────────────────────────────────────────────────────────────────────
async def cmd_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update): return
    users = get_all_users()
    lines = [f"<b>👥 Users ({len(users)}):</b>\n"]
    for u in users[:20]:
        p = "💎" if u.get("is_premium") else "🆓"
        b = "🚫" if u.get("is_banned")  else ""
        lines.append(
            f"{p}{b} <code>{u['telegram_id']}</code> "
            f"@{u.get('username') or 'N/A'} {u.get('first_name') or ''}"
        )
    if len(users) > 20:
        lines.append(f"… and {len(users)-20} more")
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=admin_menu())


# ── /broadcast ────────────────────────────────────────────────────────────────
async def cmd_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update): return
    if not context.args:
        await update.message.reply_text("Usage: /broadcast <i>message</i>", parse_mode=ParseMode.HTML)
        return
    msg = " ".join(context.args)
    from database.operations import get_all_active_users
    users = get_all_active_users()
    sent = failed = 0
    await update.message.reply_text(f"📢 Broadcasting to {len(users)} users…")
    for u in users:
        uid = u.get("telegram_id")
        if not uid: continue
        try:
            await context.bot.send_message(
                chat_id=uid, text=f"📢 <b>Announcement:</b>\n\n{msg}", parse_mode=ParseMode.HTML,
            )
            sent += 1
        except TelegramError:
            failed += 1
    await update.message.reply_text(f"✅ Done: {sent} sent, {failed} failed", reply_markup=admin_menu())


# ── /signals ──────────────────────────────────────────────────────────────────
async def cmd_admin_signals(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update): return
    recent = get_recent_signals(limit=10)
    if not recent:
        await update.message.reply_text("No signals yet.")
        return
    lines = [f"<b>📡 Recent Signals:</b>\n"]
    for s in recent:
        lines.append(
            f"  #{s['id']} {s.get('direction')} @ {s.get('entry'):.2f} | "
            f"{s.get('confidence')}% {s.get('grade')} | {s.get('status')} | "
            f"{str(s.get('created_at',''))[:16]}"
        )
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=admin_menu())


# ── /logs ─────────────────────────────────────────────────────────────────────
async def cmd_logs(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update): return
    errors = get_recent_errors(limit=10)
    if not errors:
        await update.message.reply_text("✅ No errors logged.")
        return
    lines = ["<b>⚠️ Last 10 Errors:</b>\n"]
    for e in errors:
        lines.append(
            f"  [{str(e.get('logged_at',''))[:16]}] "
            f"<code>{e.get('module','?')}</code>: {str(e.get('message',''))[:80]}"
        )
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=admin_menu())


# ── /reports ──────────────────────────────────────────────────────────────────
async def cmd_reports(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update): return
    summary = get_performance_summary()
    text    = format_tracker_report(summary)
    await update.message.reply_text(
        f"<pre>{text}</pre>", parse_mode=ParseMode.HTML, reply_markup=admin_menu(),
    )


# ── /mt5 — auto-trader status ─────────────────────────────────────────────────
async def cmd_mt5(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update): return
    if not AUTO_TRADE_ENABLED:
        await update.message.reply_text("❌ AUTO_TRADE_ENABLED=false in .env")
        return
    try:
        from engine.auto_trader import get_account_summary, get_open_positions, is_connected
        if not is_connected():
            await update.message.reply_text("⚠️ MT5 not connected.")
            return
        acc  = get_account_summary()
        poss = get_open_positions()
        lines = [
            f"<b>🤖 MT5 Account</b>\n{'─'*30}",
            f"Login   : {acc.get('login')}",
            f"Balance : {acc.get('balance'):.2f} {acc.get('currency')}",
            f"Equity  : {acc.get('equity'):.2f}",
            f"P&L     : {acc.get('profit'):+.2f}",
            f"Free Mrg: {acc.get('free_margin'):.2f}",
            f"Leverage: 1:{acc.get('leverage')}",
            f"\n<b>Open Positions ({len(poss)}):</b>",
        ]
        for p in poss:
            lines.append(
                f"  #{p.ticket} {p.direction} {p.volume}L "
                f"@ {p.open_price:.2f} | P&L: {p.profit:+.2f}"
            )
        if not poss:
            lines.append("  No open positions")
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)
    except Exception as exc:
        await update.message.reply_text(f"❌ MT5 error: {exc}")


# ── /confidence — adaptive engine status ──────────────────────────────────────
async def cmd_confidence(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update): return
    try:
        from engine.adaptive_confidence import (
            get_current_weights, get_adaptive_threshold,
            _load_signal_history, ADAPTIVE_CONFIDENCE_ENABLED,
        )
        from config.settings import SCORE_WEIGHTS
        weights   = get_current_weights()
        threshold = get_adaptive_threshold()
        history   = _load_signal_history()

        lines = [
            f"<b>🧠 Adaptive Confidence Engine</b>",
            f"{'─'*34}",
            f"Enabled  : {'✅' if ADAPTIVE_CONFIDENCE_ENABLED else '❌'}",
            f"Threshold: {threshold} (default: {SCORE_WEIGHTS.get('market_structure',20)}+…)",
            f"Samples  : {len(history)} labelled signals",
            f"",
            f"<b>Dynamic Weights vs Baseline:</b>",
        ]
        for comp, w in sorted(weights.items(), key=lambda x: -x[1]):
            base = SCORE_WEIGHTS.get(comp, 0)
            diff = w - base
            arrow = "↑" if diff > 0.5 else ("↓" if diff < -0.5 else "=")
            lines.append(
                f"  {comp[:20]:<20} {w:5.1f} (base {base}) {arrow}"
            )
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)
    except Exception as exc:
        await update.message.reply_text(f"❌ Error: {exc}")


# ── Callback dispatcher ───────────────────────────────────────────────────────
async def cb_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    user  = update.effective_user
    if not user or not is_admin(user.id):
        await query.answer("⛔ Admin only.", show_alert=True)
        return

    data = query.data

    if data == "admin_stats":
        uc = count_users()
        from engine.data_fetcher import get_data_source_info
        text = format_admin_stats({
            "total_users":   uc["total"],
            "active_users":  uc["active"],
            "premium_users": uc["premium"],
            "signals_today": count_signals_today(),
            "errors_today":  count_errors_today(),
            "uptime":        _uptime(),
        }) + f"\n📊 Data: {get_data_source_info()}"
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=admin_menu())

    elif data == "admin_signals":
        recent = get_recent_signals(limit=5)
        lines  = ["<b>📡 Recent 5 Signals:</b>\n"]
        for s in recent:
            lines.append(
                f"  #{s['id']} {s.get('direction')} {s.get('entry'):.2f} | "
                f"{s.get('confidence')}% | {s.get('status')}"
            )
        await query.edit_message_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=admin_menu())

    elif data == "admin_logs":
        errors = get_recent_errors(limit=5)
        lines  = ["<b>⚠️ Last 5 Errors:</b>\n"] if errors else ["✅ No errors"]
        for e in errors:
            lines.append(f"  [{str(e.get('logged_at',''))[:16]}] {str(e.get('message',''))[:80]}")
        await query.edit_message_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=admin_menu())

    elif data == "admin_reports":
        summary = get_performance_summary()
        text    = format_tracker_report(summary)
        await query.edit_message_text(
            f"<pre>{text}</pre>", parse_mode=ParseMode.HTML, reply_markup=admin_menu()
        )

    elif data == "admin_backtest":
        await query.edit_message_text(
            "⚙️ Running realistic 30-day backtest on M15…\n"
            "<i>(spread=3p slippage=1p — may take 30–60s)</i>",
            parse_mode=ParseMode.HTML,
        )
        end   = date.today().isoformat()
        start = (date.today() - timedelta(days=30)).isoformat()
        r     = run_backtest(start, end, "M15")
        await query.edit_message_text(
            f"<pre>{format_backtest_report(r)}</pre>",
            parse_mode=ParseMode.HTML, reply_markup=admin_menu(),
        )

    elif data == "admin_settings":
        from engine.adaptive_confidence import get_adaptive_threshold
        from engine.data_fetcher        import get_data_source_info
        from config.settings            import (SIGNAL_INTERVAL_MINUTES, MAX_SIGNALS_PER_DAY,
                                                MIN_RR_RATIO, BT_SPREAD_PIPS)
        text = (
            f"<b>⚙️ Bot Settings</b>\n{'─'*30}\n"
            f"Data source  : {get_data_source_info()}\n"
            f"Scan interval: {SIGNAL_INTERVAL_MINUTES} min\n"
            f"Max signals/d: {MAX_SIGNALS_PER_DAY}\n"
            f"Min RR       : 1:{MIN_RR_RATIO}\n"
            f"BT spread    : {BT_SPREAD_PIPS} pips\n"
            f"AutoTrade    : {'ON' if AUTO_TRADE_ENABLED else 'OFF'}\n"
            f"Threshold    : {get_adaptive_threshold()} (adaptive)\n"
        )
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=admin_menu())


def get_handlers():
    return [
        CommandHandler("admin",      cmd_admin),
        CommandHandler("users",      cmd_users),
        CommandHandler("broadcast",  cmd_broadcast),
        CommandHandler("signals",    cmd_admin_signals),
        CommandHandler("logs",       cmd_logs),
        CommandHandler("reports",    cmd_reports),
        CommandHandler("mt5",        cmd_mt5),
        CommandHandler("confidence", cmd_confidence),
        CallbackQueryHandler(cb_admin, pattern="^admin_"),
    ]
