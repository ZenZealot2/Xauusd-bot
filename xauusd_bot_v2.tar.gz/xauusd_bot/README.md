# 🤖 XAUUSD AI Signal Bot

Professional-grade Telegram bot that generates automated **XAUUSD (Gold) trading signals**
using Smart Money Concepts, Multi-Timeframe Analysis, and an AI Confidence Engine.

---

## ✨ Features

| Feature | Details |
|---|---|
| 📊 Analysis | BOS, CHOCH, Order Blocks, FVG, Liquidity Sweeps |
| ⏱ Timeframes | M1, M5, M15 (entry) + H1, H4 (trend) |
| 🤖 AI Scoring | 0–100 confidence score with letter grades |
| 📈 Chart | Auto-generated annotated chart with every signal |
| 📰 News Filter | ForexFactory calendar — blocks 30 min around events |
| ⚖️ Risk Mgmt | Entry, SL, TP1/TP2/TP3 auto-calculated |
| 📉 Backtester | Historical strategy testing with full report |
| 🗄 Database | SQLite — users, signals, performance, logs |
| 🐳 Docker | Fully containerised, production-ready |
| 🚂 Railway | One-click cloud deployment |

---

## 📁 Project Structure

```
xauusd_bot/
├── main.py                    ← Entry point
├── requirements.txt
├── .env.example
├── Dockerfile
├── docker-compose.yml
├── config/
│   └── settings.py            ← All configuration
├── utils/
│   ├── logger.py
│   ├── helpers.py
│   └── formatters.py
├── database/
│   ├── models.py              ← SQLite schema
│   └── operations.py          ← CRUD operations
├── engine/
│   ├── data_fetcher.py        ← yfinance multi-TF data
│   ├── confidence.py          ← AI scoring engine
│   ├── risk_management.py     ← Entry/SL/TP calculator
│   └── signal_generator.py    ← Main pipeline
├── analysis/
│   ├── market_structure.py    ← BOS, CHOCH, HH/HL/LH/LL
│   ├── smart_money.py         ← Liquidity, sweeps
│   ├── fair_value_gap.py      ← FVG detection
│   ├── order_blocks.py        ← OB detection & ranking
│   ├── trend_filter.py        ← EMA50/200 trend
│   ├── momentum.py            ← RSI, MACD, ATR
│   ├── volume.py              ← Volume analysis
│   ├── session.py             ← Trading session detection
│   ├── news_filter.py         ← Economic calendar
│   └── multi_timeframe.py     ← MTF orchestrator
├── charts/
│   └── chart_generator.py     ← mplfinance chart builder
├── performance/
│   ├── tracker.py             ← Live result tracking
│   └── backtester.py          ← Historical backtesting
├── bot/
│   ├── handlers/
│   │   ├── start.py           ← /start /help
│   │   ├── signals.py         ← /signal broadcast
│   │   ├── stats.py           ← /stats
│   │   └── admin.py           ← Admin panel
│   └── keyboards/
│       └── menus.py           ← Inline keyboards
└── scheduler/
    └── jobs.py                ← APScheduler jobs
```

---

## 🚀 Quick Start (Local)

### 1. Prerequisites

- Python 3.12+
- pip
- A Telegram bot token from [@BotFather](https://t.me/BotFather)

### 2. Clone & Install

```bash
git clone https://github.com/youruser/xauusd_bot.git
cd xauusd_bot

# Create virtual environment
python -m venv venv
source venv/bin/activate          # Linux/macOS
# venv\Scripts\activate           # Windows

# Install dependencies
pip install -r requirements.txt
```

### 3. Configure Environment

```bash
cp .env.example .env
nano .env   # or use any text editor
```

Fill in at minimum:

```env
TELEGRAM_BOT_TOKEN=your_token_here
ADMIN_CHAT_IDS=your_telegram_user_id
```

Get your Telegram user ID by messaging [@userinfobot](https://t.me/userinfobot).

### 4. Run

```bash
python main.py
```

Open Telegram, message your bot `/start` — done!

---

## 🖥 VPS Deployment (Ubuntu 22.04)

### Step 1 — Provision a VPS

Recommended: DigitalOcean, Hetzner, Linode (any $5–6/month Droplet works).

Minimum specs:
- 1 vCPU, 1 GB RAM, 20 GB SSD
- Ubuntu 22.04 LTS

### Step 2 — Connect via SSH

```bash
ssh root@YOUR_VPS_IP
```

### Step 3 — Install system dependencies

```bash
apt update && apt upgrade -y
apt install -y python3.12 python3.12-venv python3-pip git \
               libfreetype6-dev libpng-dev pkg-config \
               screen nano curl ufw

# Configure firewall (only allow SSH)
ufw allow OpenSSH
ufw enable
```

### Step 4 — Clone the project

```bash
cd /opt
git clone https://github.com/youruser/xauusd_bot.git
cd xauusd_bot

python3.12 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 5 — Configure .env

```bash
cp .env.example .env
nano .env
# Fill in TELEGRAM_BOT_TOKEN and ADMIN_CHAT_IDS
```

### Step 6 — Create a systemd service (auto-restart on crash)

```bash
nano /etc/systemd/system/xauusd-bot.service
```

Paste:

```ini
[Unit]
Description=XAUUSD AI Signal Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/xauusd_bot
ExecStart=/opt/xauusd_bot/venv/bin/python main.py
Restart=always
RestartSec=10
StandardOutput=append:/opt/xauusd_bot/logs/bot.log
StandardError=append:/opt/xauusd_bot/logs/bot.log
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
systemctl daemon-reload
systemctl enable xauusd-bot
systemctl start  xauusd-bot
systemctl status xauusd-bot
```

### Step 7 — Monitor logs

```bash
# Live log stream
tail -f /opt/xauusd_bot/logs/bot.log

# systemd logs
journalctl -u xauusd-bot -f
```

---

## 🐳 Docker Deployment

### Build and run with Docker Compose

```bash
# Copy and fill .env
cp .env.example .env
nano .env

# Build and start (detached)
docker-compose up -d --build

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

### Build standalone Docker image

```bash
docker build -t xauusd-bot .
docker run -d \
  --name xauusd_bot \
  --env-file .env \
  --restart unless-stopped \
  -v xauusd_db:/app/database \
  -v xauusd_logs:/app/logs \
  xauusd-bot
```

---

## 🚂 Railway Deployment (Cloud, Free Tier)

Railway gives a free cloud server with automatic deploys from GitHub.

### Step 1 — Create Railway account

Go to [railway.app](https://railway.app) → sign up with GitHub.

### Step 2 — Create new project

- Click **New Project** → **Deploy from GitHub repo**
- Select your `xauusd_bot` repository
- Railway auto-detects the `Dockerfile`

### Step 3 — Set environment variables

In the Railway dashboard:
- Click your service → **Variables** tab
- Add all variables from `.env.example`:

```
TELEGRAM_BOT_TOKEN = your_token
ADMIN_CHAT_IDS     = 123456789
CHANNEL_ID         = (optional)
...
```

### Step 4 — Deploy

Railway auto-builds from your Dockerfile and deploys.
Watch the **Deployments** tab for build logs.

### Step 5 — Persistent volume (important!)

SQLite needs a persistent disk. In Railway:
- Go to your service → **Volumes** tab
- Add a volume → mount path: `/app/database`
- This persists the SQLite DB across deploys

---

## 🤖 Telegram Commands

| Command | Description |
|---|---|
| `/start` | Register and welcome message |
| `/signal` | Run manual XAUUSD scan |
| `/stats` | View performance statistics |
| `/help` | Show all commands |
| `/admin` | Admin dashboard |
| `/users` | List registered users |
| `/broadcast <msg>` | Send message to all users |
| `/signals` | Recent signal history |
| `/logs` | Last 20 error log entries |
| `/reports` | Weekly performance report |

---

## 📊 AI Confidence Score

| Score | Grade | Classification | Action |
|---|---|---|---|
| 90–100 | A+ | 🚀 ELITE | Always trade |
| 80–89 | A | 💪 STRONG | Trade |
| 70–79 | B | 📊 NORMAL | Trade with caution |
| < 70 | C | ❌ NO SIGNAL | Skip |

### Score Breakdown

| Component | Max Score |
|---|---|
| Market Structure (BOS/CHOCH) | 20 |
| Liquidity Sweep | 15 |
| Order Block | 15 |
| Fair Value Gap (FVG) | 15 |
| Trend Alignment (EMA) | 15 |
| Volume Confirmation | 10 |
| Momentum (RSI/MACD) | 5 |
| Session Quality | 5 |
| **TOTAL** | **100** |

---

## ⚙️ Configuration Reference

All options are set in `.env`. Key settings:

| Variable | Default | Description |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | — | Required. BotFather token |
| `ADMIN_CHAT_IDS` | — | Required. Comma-separated admin IDs |
| `SIGNAL_INTERVAL_MINUTES` | 5 | How often to scan |
| `MIN_CONFIDENCE_SCORE` | 70 | Minimum score to generate signal |
| `MAX_SIGNALS_PER_DAY` | 10 | Daily safety cap |
| `ACCOUNT_BALANCE` | 10000 | For position size calculation |
| `RISK_PER_TRADE_PCT` | 1.0 | Risk % per trade |
| `GOLD_TICKER` | GC=F | Yahoo Finance Gold ticker |
| `ENABLE_NEWS_FILTER` | true | Block signals near events |
| `NEWS_BUFFER_MINUTES` | 30 | Minutes to avoid around news |
| `CHART_STYLE` | dark | `dark` or `light` |
| `LOG_LEVEL` | INFO | `DEBUG`, `INFO`, `WARNING`, `ERROR` |

---

## 📦 Dependencies

| Package | Purpose |
|---|---|
| `python-telegram-bot==20.7` | Telegram bot framework (async) |
| `pandas` | Data manipulation |
| `numpy` | Numerical computing |
| `yfinance` | XAUUSD (GC=F) market data |
| `ta` | Technical indicators (RSI, MACD, ATR) |
| `mplfinance` | Candlestick charts |
| `matplotlib` | Chart rendering |
| `APScheduler` | Signal scan scheduler |
| `requests` | HTTP (news calendar) |
| `python-dotenv` | `.env` loading |
| `Pillow` | Image processing |
| `pytz` | Timezone handling |

---

## 🔧 Troubleshooting

**Bot not responding:**
```bash
# Check the process is running
systemctl status xauusd-bot

# Check logs for errors
tail -50 logs/bot.log
```

**No data / `yfinance` errors:**
```bash
# Test data fetch manually
python -c "import yfinance as yf; df = yf.Ticker('GC=F').history('5d','15m'); print(df.tail())"
```
If empty, Yahoo Finance may be rate-limiting. Wait 30 seconds and retry.

**News filter always blocking:**
```bash
# Disable temporarily in .env
ENABLE_NEWS_FILTER=false
```

**Chart not generating (matplotlib error):**
```bash
# Ensure you're on a headless server (no display)
export MPLBACKEND=Agg
```
This is already set in the code, but the env var can force it.

**Permission denied (SQLite):**
```bash
chmod 755 database/
chmod 644 database/xauusd_bot.db   # if it exists
```

---

## ⚠️ Disclaimer

> This bot is for **educational purposes** only.
> Trading Gold involves significant financial risk.
> Past signal performance does not guarantee future results.
> Always use proper risk management and trade responsibly.
> The authors are not liable for any financial losses.

---

## 📄 License

MIT License — free for personal and commercial use.
