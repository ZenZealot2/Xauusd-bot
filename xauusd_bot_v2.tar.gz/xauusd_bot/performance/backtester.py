"""
performance/backtester.py
=========================
Realistic backtesting engine with spread, slippage, and commission simulation.

Realistic execution model:
  Entry = signal price + spread (worst-case fill)
  SL    = signal SL (no change)
  TP    = signal TP − spread (for close orders)
  Each trade deducts: spread_cost + slippage_cost + commission

XAUUSD typical costs:
  Spread:     2–5 pips ($0.20–$0.50) depending on session/broker
  Slippage:   0–2 pips (modelled as worst-case 1 pip average)
  Commission: $3–7 per standard lot (some brokers, 0 for spread-only)
"""

from __future__ import annotations

import traceback
from datetime import datetime, date
from typing import Any, Optional

import numpy as np
import pandas as pd

from engine.data_fetcher      import get_ohlcv, validate_dataframe
from analysis.market_structure import analyse_market_structure
from analysis.fair_value_gap   import analyse_fvg
from analysis.order_blocks     import analyse_order_blocks
from analysis.trend_filter     import analyse_trend
from analysis.momentum         import analyse_momentum
from analysis.volume           import analyse_volume
from engine.risk_management    import calculate_risk_parameters, _latest_atr
from database.operations       import save_backtest_run
from config.settings           import (
    MIN_CONFIDENCE_SCORE, MIN_RR_RATIO,
    BT_SPREAD_PIPS, BT_SLIPPAGE_PIPS, BT_COMMISSION_PER_LOT,
    AUTO_TRADE_LOT_SIZE,
)
from utils.logger import get_logger

logger = get_logger(__name__)

# Convert pip settings to price units
_SPREAD  = BT_SPREAD_PIPS  * 0.10
_SLIP    = BT_SLIPPAGE_PIPS * 0.10
_COMM    = BT_COMMISSION_PER_LOT * AUTO_TRADE_LOT_SIZE   # in $


# ─────────────────────────────────────────────────────────────────────────────
# Trade record
# ─────────────────────────────────────────────────────────────────────────────

class BacktestTrade:
    __slots__ = (
        "direction", "signal_entry", "actual_entry",
        "stop_loss", "tp1", "tp2", "tp3",
        "entry_time", "close_time",
        "status", "result_tp", "gross_pips",
        "spread_cost", "slip_cost", "commission",
        "net_pips", "rr", "confidence",
    )

    def __init__(self, direction: str, signal_entry: float,
                 stop_loss: float, tp1: float, tp2: float, tp3: float,
                 entry_time: datetime, confidence: int = 0, rr: float = 0.0):
        self.direction    = direction
        self.signal_entry = signal_entry
        self.stop_loss    = stop_loss
        self.tp1          = tp1
        self.tp2          = tp2
        self.tp3          = tp3
        self.entry_time   = entry_time
        self.close_time   : Optional[datetime] = None
        self.status       = "OPEN"
        self.result_tp    = 0
        self.gross_pips   = 0.0
        self.spread_cost  = 0.0
        self.slip_cost    = 0.0
        self.commission   = 0.0
        self.net_pips     = 0.0
        self.rr           = rr
        self.confidence   = confidence

        # Realistic entry with spread + slippage
        spread_adj = _SPREAD + _SLIP
        if direction == "BUY":
            self.actual_entry = signal_entry + spread_adj
        else:
            self.actual_entry = signal_entry - spread_adj

        # Adjust TPs for spread on close
        if direction == "BUY":
            self.tp1 -= _SPREAD
            self.tp2 -= _SPREAD
            self.tp3 -= _SPREAD
        else:
            self.tp1 += _SPREAD
            self.tp2 += _SPREAD
            self.tp3 += _SPREAD

        # Cost components
        self.spread_cost = BT_SPREAD_PIPS
        self.slip_cost   = BT_SLIPPAGE_PIPS
        self.commission  = _COMM / 0.10 if 0.10 > 0 else 0   # Convert to pips

    def close(self, status: str, result_tp: int, gross_pips: float, close_time: datetime):
        self.status     = status
        self.result_tp  = result_tp
        self.gross_pips = gross_pips
        self.close_time = close_time
        # Net pips = gross − all costs
        total_costs = self.spread_cost + self.slip_cost + self.commission
        self.net_pips = round(gross_pips - total_costs, 1)


# ─────────────────────────────────────────────────────────────────────────────
# Bar-by-bar simulation (worst-case fill)
# ─────────────────────────────────────────────────────────────────────────────

def _check_exit(trade: BacktestTrade, bar: pd.Series, bar_time: datetime) -> bool:
    """
    Check if the trade exits on this bar.
    Assumes worst-case intra-bar order: SL checked before TP.
    """
    if trade.status != "OPEN":
        return False

    high  = float(bar["high"])
    low   = float(bar["low"])
    entry = trade.actual_entry

    if trade.direction == "BUY":
        # SL first (worst case: low hits before high)
        if low <= trade.stop_loss:
            pips = (trade.stop_loss - entry) / 0.10
            trade.close("LOSS", 0, round(pips, 1), bar_time)
            return True
        if high >= trade.tp3:
            pips = (trade.tp3 - entry) / 0.10
            trade.close("WIN", 3, round(pips, 1), bar_time)
            return True
        if high >= trade.tp2:
            pips = (trade.tp2 - entry) / 0.10
            trade.close("WIN", 2, round(pips, 1), bar_time)
            return True
        if high >= trade.tp1:
            pips = (trade.tp1 - entry) / 0.10
            trade.close("WIN", 1, round(pips, 1), bar_time)
            return True

    else:  # SELL
        if high >= trade.stop_loss:
            pips = (entry - trade.stop_loss) / 0.10
            trade.close("LOSS", 0, round(pips, 1), bar_time)
            return True
        if low <= trade.tp3:
            pips = (entry - trade.tp3) / 0.10
            trade.close("WIN", 3, round(pips, 1), bar_time)
            return True
        if low <= trade.tp2:
            pips = (entry - trade.tp2) / 0.10
            trade.close("WIN", 2, round(pips, 1), bar_time)
            return True
        if low <= trade.tp1:
            pips = (entry - trade.tp1) / 0.10
            trade.close("WIN", 1, round(pips, 1), bar_time)
            return True

    return False


# ─────────────────────────────────────────────────────────────────────────────
# Lightweight scoring
# ─────────────────────────────────────────────────────────────────────────────

def _score_slice(df_slice: pd.DataFrame, direction: str) -> int:
    """Fast scoring for backtesting (no full MTF overhead)."""
    try:
        score  = 0
        price  = float(df_slice["close"].iloc[-1])
        ms     = analyse_market_structure(df_slice)
        tr     = analyse_trend(df_slice, direction)
        mom    = analyse_momentum(df_slice, direction)
        vol    = analyse_volume(df_slice, direction)
        fvg    = analyse_fvg(df_slice, price, direction)
        ob     = analyse_order_blocks(df_slice, price, direction)

        target_trend = "Bullish" if direction == "BUY" else "Bearish"
        if ms.trend == target_trend:    score += 16
        if tr.direction == target_trend: score += 12
        score += min(mom.score, 5)
        score += min(vol.score, 10)
        score += min(fvg.score, 15)
        score += min(ob.score,  15)
        return min(score, 100)
    except Exception:
        return 0


# ─────────────────────────────────────────────────────────────────────────────
# Report builder
# ─────────────────────────────────────────────────────────────────────────────

def _build_report(trades: list[BacktestTrade], costs: dict) -> dict[str, Any]:
    closed = [t for t in trades if t.status != "OPEN"]
    wins   = [t for t in closed if t.status == "WIN"]
    losses = [t for t in closed if t.status == "LOSS"]

    total = len(closed)
    n_w   = len(wins)
    n_l   = len(losses)
    wr    = round(n_w / total * 100, 1) if total > 0 else 0.0

    # Net pips (after costs)
    net_pips   = round(sum(t.net_pips for t in closed), 1)
    gross_pips = round(sum(t.gross_pips for t in closed), 1)
    total_cost = round(sum(t.spread_cost + t.slip_cost + t.commission for t in closed), 1)

    g_win  = sum(t.net_pips for t in wins  if t.net_pips > 0)
    g_loss = abs(sum(t.net_pips for t in losses if t.net_pips < 0))
    pf     = round(g_win / g_loss, 2) if g_loss > 0 else (float("inf") if g_win > 0 else 0.0)

    rr_vals  = [t.rr for t in closed if t.rr > 0]
    avg_rr   = round(float(np.mean(rr_vals)), 2) if rr_vals else 0.0

    # Max drawdown (net pip curve)
    curve = np.cumsum([t.net_pips for t in closed])
    peak  = 0.0
    dds   = []
    for p in curve:
        peak = max(peak, p)
        dds.append(peak - p)
    max_dd = round(max(dds) if dds else 0.0, 1)

    tp_dist = {1: 0, 2: 0, 3: 0}
    for t in wins:
        tp_dist[t.result_tp] = tp_dist.get(t.result_tp, 0) + 1

    return {
        "total_trades":    total,
        "wins":            n_w,
        "losses":          n_l,
        "open":            len([t for t in trades if t.status == "OPEN"]),
        "win_rate":        wr,
        "profit_factor":   pf,
        "gross_pips":      gross_pips,
        "total_costs_pips": total_cost,
        "net_pips":        net_pips,
        "avg_rr":          avg_rr,
        "max_drawdown":    max_dd,
        "tp1_hits":        tp_dist.get(1, 0),
        "tp2_hits":        tp_dist.get(2, 0),
        "tp3_hits":        tp_dist.get(3, 0),
        "cost_settings": costs,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Main runner
# ─────────────────────────────────────────────────────────────────────────────

def run_backtest(
    start_date: str,
    end_date:   str,
    timeframe:  str  = "M15",
    min_confidence: int  = MIN_CONFIDENCE_SCORE,
    warmup_bars:    int  = 100,
    max_concurrent: int  = 1,
    spread_pips:    float = BT_SPREAD_PIPS,
    slippage_pips:  float = BT_SLIPPAGE_PIPS,
    commission:     float = BT_COMMISSION_PER_LOT,
) -> dict[str, Any]:
    """
    Run realistic historical backtest.

    Parameters
    ----------
    spread_pips    : Simulated spread in pips (XAUUSD typical: 3.0)
    slippage_pips  : Order slippage in pips (typical: 1.0)
    commission     : Commission per standard lot in $ (0 for spread-based brokers)
    """
    global _SPREAD, _SLIP, _COMM
    _SPREAD = spread_pips  * 0.10
    _SLIP   = slippage_pips * 0.10
    _COMM   = commission * AUTO_TRADE_LOT_SIZE

    logger.info(
        f"Backtest: {start_date}→{end_date} | {timeframe} | "
        f"spread={spread_pips}p slippage={slippage_pips}p commission=${commission}/lot"
    )

    try:
        df = get_ohlcv(timeframe, force_refresh=True)
        if not validate_dataframe(df, min_bars=warmup_bars + 50):
            return {"error": "Insufficient historical data"}

        start_ts = pd.Timestamp(start_date, tz="UTC")
        end_ts   = pd.Timestamp(end_date,   tz="UTC") + pd.Timedelta(days=1)
        df_range = df[(df.index >= start_ts) & (df.index < end_ts)]

        if len(df_range) < warmup_bars + 10:
            return {"error": f"Not enough data in {start_date}–{end_date}"}

        logger.info(f"Backtest: {len(df_range)} bars in range")

        trades:     list[BacktestTrade] = []
        open_trades:list[BacktestTrade] = []
        last_sig_dir: Optional[str] = None
        scan_cycle = 0

        for i in range(warmup_bars, len(df_range)):
            bar      = df_range.iloc[i]
            bar_time = df_range.index[i]
            df_slice = df_range.iloc[max(0, i - warmup_bars): i + 1]
            scan_cycle += 1

            # Check open trades
            still_open = []
            for t in open_trades:
                closed = _check_exit(t, bar, pd.Timestamp(bar_time).to_pydatetime())
                if t.status == "OPEN":
                    still_open.append(t)
            open_trades = still_open

            if len(open_trades) >= max_concurrent:
                continue

            # Signal generation (every 3 bars to avoid overtrading)
            if scan_cycle % 3 != 0:
                continue

            price     = float(bar["close"])
            buy_score = _score_slice(df_slice, "BUY")
            sel_score = _score_slice(df_slice, "SELL")

            direction = None
            sig_score = 0
            if buy_score >= min_confidence and buy_score >= sel_score:
                direction = "BUY"
                sig_score = buy_score
            elif sel_score >= min_confidence and sel_score > buy_score:
                direction = "SELL"
                sig_score = sel_score

            if direction is None or direction == last_sig_dir:
                continue

            try:
                rp = calculate_risk_parameters(
                    df=df_slice, direction=direction, current_price=price
                )
                if not rp.valid or rp.rr_tp1 < MIN_RR_RATIO:
                    continue

                t = BacktestTrade(
                    direction=direction,
                    signal_entry=rp.entry,
                    stop_loss=rp.stop_loss,
                    tp1=rp.tp1, tp2=rp.tp2, tp3=rp.tp3,
                    entry_time=pd.Timestamp(bar_time).to_pydatetime(),
                    confidence=sig_score,
                    rr=rp.rr_tp2,
                )
                open_trades.append(t)
                trades.append(t)
                last_sig_dir = direction

                logger.debug(
                    f"BT #{len(trades)}: {direction} actual={t.actual_entry:.2f} "
                    f"SL={rp.stop_loss:.2f} TP1={rp.tp1:.2f} score={sig_score}"
                )
            except Exception as exc:
                logger.debug(f"BT risk calc error: {exc}")

        costs_info = {
            "spread_pips":   spread_pips,
            "slippage_pips": slippage_pips,
            "commission_per_lot": commission,
        }

        report = _build_report(trades, costs_info)
        report.update({
            "start_date": start_date, "end_date": end_date,
            "timeframe": timeframe, "min_confidence": min_confidence,
        })

        save_backtest_run({
            "start_date": start_date, "end_date": end_date,
            "total_trades": report["total_trades"],
            "win_rate": report["win_rate"],
            "profit_factor": report["profit_factor"],
            "max_drawdown": report["max_drawdown"],
            "net_pips": report["net_pips"],
            "report": report,
        })

        logger.info(
            f"Backtest: {report['total_trades']} trades | "
            f"WR={report['win_rate']}% | PF={report['profit_factor']} | "
            f"Gross={report['gross_pips']:+.1f}p Net={report['net_pips']:+.1f}p "
            f"Costs={report['total_costs_pips']:.1f}p"
        )
        return report

    except Exception as exc:
        tb = traceback.format_exc()
        logger.error(f"Backtest error: {exc}\n{tb}")
        return {"error": str(exc)}


def format_backtest_report(r: dict[str, Any]) -> str:
    if "error" in r:
        return f"❌ Backtest failed: {r['error']}"

    costs = r.get("cost_settings", {})
    return (
        f"📈 BACKTEST REPORT (Realistic)\n"
        f"{'═' * 38}\n"
        f"Period      : {r.get('start_date')} → {r.get('end_date')}\n"
        f"Timeframe   : {r.get('timeframe')} | MinConf: {r.get('min_confidence')}%\n"
        f"\n"
        f"── Execution Costs ──\n"
        f"  Spread    : {costs.get('spread_pips', 0):.1f} pips\n"
        f"  Slippage  : {costs.get('slippage_pips', 0):.1f} pips\n"
        f"  Commission: ${costs.get('commission_per_lot', 0):.1f}/lot\n"
        f"\n"
        f"── Results ──\n"
        f"Trades      : {r.get('total_trades', 0)}\n"
        f"Wins        : {r.get('wins', 0)} | Losses: {r.get('losses', 0)}\n"
        f"Win Rate    : {r.get('win_rate', 0):.1f}%\n"
        f"Profit Fac  : {r.get('profit_factor', 0):.2f}\n"
        f"Gross Pips  : {r.get('gross_pips', 0):+.1f}\n"
        f"Total Costs : {r.get('total_costs_pips', 0):.1f} pips\n"
        f"NET Pips    : {r.get('net_pips', 0):+.1f}  ← realistic\n"
        f"Avg RR      : 1:{r.get('avg_rr', 0):.2f}\n"
        f"Max Drawdown: {r.get('max_drawdown', 0):.1f} pips\n"
        f"\n"
        f"TP1: {r.get('tp1_hits',0)}  TP2: {r.get('tp2_hits',0)}  TP3: {r.get('tp3_hits',0)}\n"
    )
