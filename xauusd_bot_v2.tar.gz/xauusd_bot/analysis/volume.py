"""
analysis/volume.py
==================
Volume analysis for XAUUSD signal confirmation.

Note: Gold Futures (GC=F) volume data from yfinance represents contract volume.
Spot XAUUSD brokers don't publish true volume, but tick volume from GC=F is a
reliable proxy.

Detects:
  - Volume spikes (current volume vs rolling average)
  - Relative Volume (RVOL)
  - Volume trend (increasing vs decreasing)
  - Volume confirmation for direction

Score contribution: max 10 points.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from config.settings import VOLUME_MA_PERIOD, VOLUME_SPIKE_THRESHOLD, SCORE_WEIGHTS
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class VolumeResult:
    current_volume:  float
    average_volume:  float
    rvol:            float    # Relative volume (current / average)
    is_spike:        bool
    trend:           str      # 'increasing' | 'decreasing' | 'flat'
    confirms_dir:    bool     # Does volume confirm trade direction?
    score:           int
    reasons:         list[str]


# ─────────────────────────────────────────────────────────────────────────────
# Calculations
# ─────────────────────────────────────────────────────────────────────────────

def calculate_volume_ma(df: pd.DataFrame, period: int = VOLUME_MA_PERIOD) -> pd.Series:
    """Simple moving average of volume."""
    return df["volume"].rolling(window=period, min_periods=1).mean()


def calculate_rvol(df: pd.DataFrame, period: int = VOLUME_MA_PERIOD) -> float:
    """Relative Volume: current bar volume / average volume."""
    if len(df) < 2:
        return 1.0
    vol_ma = calculate_volume_ma(df, period)
    avg    = float(vol_ma.iloc[-2])   # Average up to prev bar
    curr   = float(df["volume"].iloc[-1])
    return curr / avg if avg > 0 else 1.0


def detect_volume_spike(rvol: float, threshold: float = VOLUME_SPIKE_THRESHOLD) -> bool:
    """A spike occurs when RVOL >= threshold (default: 1.5×)."""
    return rvol >= threshold


def detect_volume_trend(df: pd.DataFrame, lookback: int = 5) -> str:
    """
    Detect if volume is increasing or decreasing over the last *lookback* bars.
    Returns 'increasing' | 'decreasing' | 'flat'.
    """
    if len(df) < lookback + 1:
        return "flat"

    recent_vol = df["volume"].iloc[-lookback:]
    # Fit a simple linear trend
    x = np.arange(len(recent_vol))
    y = recent_vol.values
    if y.std() == 0:
        return "flat"
    slope = float(np.polyfit(x, y, 1)[0])   # linear slope

    # Express slope as % of mean
    mean_vol = float(y.mean())
    if mean_vol == 0:
        return "flat"
    slope_pct = slope / mean_vol * 100

    if slope_pct > 5:
        return "increasing"
    elif slope_pct < -5:
        return "decreasing"
    return "flat"


def volume_confirms_direction(
    df: pd.DataFrame,
    direction: str,
    lookback: int = 3,
) -> bool:
    """
    Check if recent up-bars or down-bars have higher volume than the opposite.

    For BUY:  volume on up-closes (close > open) should be > volume on down-closes.
    For SELL: opposite.
    """
    if len(df) < lookback or not direction:
        return True   # No opinion → neutral pass

    recent = df.tail(lookback)
    up_vol   = recent[recent["close"] > recent["open"]]["volume"].sum()
    down_vol = recent[recent["close"] < recent["open"]]["volume"].sum()

    if direction.upper() == "BUY":
        return up_vol >= down_vol
    elif direction.upper() == "SELL":
        return down_vol >= up_vol
    return True


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_volume(
    df: pd.DataFrame,
    signal_direction: str = "",
) -> VolumeResult:
    """
    Full volume analysis.

    Parameters
    ----------
    df               : OHLCV DataFrame
    signal_direction : 'BUY' | 'SELL' | ''
    """
    score   = 0
    reasons: list[str] = []
    max_score = SCORE_WEIGHTS["volume_confirmation"]  # 10

    if "volume" not in df.columns or len(df) < VOLUME_MA_PERIOD + 2:
        return VolumeResult(
            current_volume=0, average_volume=0, rvol=1.0,
            is_spike=False, trend="flat", confirms_dir=True,
            score=3, reasons=["Volume data limited — partial credit"],
        )

    # Guard against zero/NaN volume (can happen with Gold data outside market hours)
    vol_series = df["volume"].replace(0, np.nan).ffill()
    df_clean   = df.copy()
    df_clean["volume"] = vol_series.fillna(1)

    current_vol = float(df_clean["volume"].iloc[-1])
    vol_ma      = calculate_volume_ma(df_clean)
    avg_vol     = float(vol_ma.iloc[-2]) if len(vol_ma) >= 2 else float(vol_ma.iloc[-1])
    rvol        = current_vol / avg_vol if avg_vol > 0 else 1.0
    is_spike    = detect_volume_spike(rvol)
    vol_trend   = detect_volume_trend(df_clean)
    confirms    = volume_confirms_direction(df_clean, signal_direction)

    # ── Scoring ──────────────────────────────────────────────────────────────
    if is_spike:
        score += 5
        reasons.append(f"Volume spike detected: {rvol:.1f}× average ({current_vol:,.0f} contracts)")
    elif rvol >= 1.0:
        score += 3
        reasons.append(f"Volume above average: {rvol:.1f}× ({current_vol:,.0f})")

    if confirms and signal_direction:
        score += 3
        reasons.append(f"Volume confirms {signal_direction} direction ✅")
    elif not confirms and signal_direction:
        score -= 1
        reasons.append(f"Volume diverges from {signal_direction} direction ⚠️")

    if vol_trend == "increasing":
        score += 2
        reasons.append("Volume trend: increasing (institutional interest)")
    elif vol_trend == "decreasing":
        score -= 1
        reasons.append("Volume trend: decreasing (weakening conviction)")

    score = max(0, min(score, max_score))

    logger.debug(
        f"Volume | RVOL={rvol:.2f} spike={is_spike} trend={vol_trend} "
        f"confirms={confirms} score={score}/{max_score}"
    )

    return VolumeResult(
        current_volume=current_vol,
        average_volume=avg_vol,
        rvol=rvol,
        is_spike=is_spike,
        trend=vol_trend,
        confirms_dir=confirms,
        score=score,
        reasons=reasons,
    )
