"""
analysis/fair_value_gap.py
==========================
Improved FVG detection and quality filtering.

Key improvements:
  - FVG_MIN_SIZE_PIPS raised to 1.0 pip (stricter filter)
  - FVG only valid within FVG_MAX_AGE_BARS bars (old FVGs discarded)
  - Premium/discount zone check: BUY FVGs must be in discount, SELL in premium
  - Partial mitigation tracking (FVG 50% filled = retested, not mitigated)
  - Grade A requires: large FVG + strong impulse + correct zone
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

from config.settings import SCORE_WEIGHTS, FVG_MIN_SIZE_PIPS, FVG_MAX_AGE_BARS
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class FVG:
    kind:          str
    top:           float
    bottom:        float
    mid:           float = field(init=False)
    size:          float = field(init=False)
    bar_index:     int   = 0
    mitigated:     bool  = False
    retested:      bool  = False
    partially_filled: bool = False
    quality:       str   = "C"
    in_discount:   bool  = True    # BUY FVG should be in discount zone
    in_premium:    bool  = True    # SELL FVG should be in premium zone

    def __post_init__(self):
        self.mid  = (self.top + self.bottom) / 2
        self.size = abs(self.top - self.bottom)

    def price_in_fvg(self, price: float) -> bool:
        return self.bottom <= price <= self.top

    @property
    def fill_pct(self) -> float:
        """Placeholder: tracked dynamically after creation."""
        return 0.0


@dataclass
class FVGResult:
    all_fvgs:     list[FVG]
    active_fvgs:  list[FVG]
    last_bullish: Optional[FVG]
    last_bearish: Optional[FVG]
    price_in_fvg: bool
    in_fvg_kind:  str
    score:         int
    reasons:       list[str]


# ─────────────────────────────────────────────────────────────────────────────
# Detection
# ─────────────────────────────────────────────────────────────────────────────

def detect_fvgs(
    df: pd.DataFrame,
    min_size_usd: float = FVG_MIN_SIZE_PIPS * 0.10,   # Convert pips to price
    max_age_bars: int = FVG_MAX_AGE_BARS,
    equilibrium: float = 0.0,   # Premium/discount divider (optional)
) -> list[FVG]:
    if len(df) < 3:
        return []

    highs  = df["high"].values
    lows   = df["low"].values
    closes = df["close"].values
    opens  = df["open"].values
    n      = len(df)

    # Rolling average range for quality reference
    avg_range = float(np.mean(highs[-50:] - lows[-50:])) if n >= 50 else 1.0

    fvgs: list[FVG] = []
    start = max(2, n - max_age_bars)   # Only scan recent bars

    for i in range(start, n):
        # ── Bullish FVG ──────────────────────────────────────────────────
        gap_bottom = highs[i - 2]
        gap_top    = lows[i]
        if gap_top > gap_bottom:
            size = gap_top - gap_bottom
            if size >= min_size_usd:
                fvg = FVG(kind="bullish", top=gap_top, bottom=gap_bottom, bar_index=i)
                fvg.quality = _rate_fvg(fvg, opens, closes, highs, lows, i, avg_range)
                fvg.in_discount = gap_bottom < equilibrium if equilibrium else True
                fvgs.append(fvg)

        # ── Bearish FVG ──────────────────────────────────────────────────
        gap_top2   = lows[i - 2]
        gap_bottom2= highs[i]
        if gap_top2 > gap_bottom2:
            size = gap_top2 - gap_bottom2
            if size >= min_size_usd:
                fvg = FVG(kind="bearish", top=gap_top2, bottom=gap_bottom2, bar_index=i)
                fvg.quality = _rate_fvg(fvg, opens, closes, highs, lows, i, avg_range)
                fvg.in_premium = gap_top2 > equilibrium if equilibrium else True
                fvgs.append(fvg)

    return fvgs


def _rate_fvg(
    fvg: FVG, opens: np.ndarray, closes: np.ndarray,
    highs: np.ndarray, lows: np.ndarray, i: int, avg_range: float,
) -> str:
    """
    Grade A = large FVG (>1.5× avg range) + strong middle candle
    Grade B = medium FVG or moderate middle candle
    Grade C = small or weak
    """
    if i < 2:
        return "C"

    # Middle candle (impulse candle) analysis
    mid_i    = i - 1
    body     = abs(closes[mid_i] - opens[mid_i])
    wick     = highs[mid_i] - lows[mid_i]
    body_pct = body / wick if wick > 0 else 0

    # FVG size vs average range
    size_ratio = fvg.size / avg_range if avg_range > 0 else 0

    if body_pct >= 0.65 and size_ratio >= 1.5:
        return "A"
    elif body_pct >= 0.50 or size_ratio >= 1.0:
        return "B"
    return "C"


# ─────────────────────────────────────────────────────────────────────────────
# State updates (mitigation, partial fill, retest)
# ─────────────────────────────────────────────────────────────────────────────

def update_fvg_states(fvgs: list[FVG], df: pd.DataFrame) -> None:
    """
    Track:
      - Full mitigation: close beyond opposite edge
      - Partial fill: price entered but didn't fully close beyond
      - Retest: price entered the zone (wick or close)
    """
    closes = df["close"].values
    highs  = df["high"].values
    lows   = df["low"].values
    n      = len(df)

    for fvg in fvgs:
        if fvg.bar_index + 1 >= n:
            continue
        for i in range(fvg.bar_index + 1, n):
            if fvg.kind == "bullish":
                # Mitigated: close below bottom
                if closes[i] < fvg.bottom:
                    fvg.mitigated = True
                    break
                # Partial fill: wick entered but didn't close below bottom
                if lows[i] < fvg.mid and not fvg.partially_filled:
                    fvg.partially_filled = True
                # Retest: low entered the zone
                if lows[i] <= fvg.top and not fvg.retested:
                    fvg.retested = True
            else:
                if closes[i] > fvg.top:
                    fvg.mitigated = True
                    break
                if highs[i] > fvg.mid and not fvg.partially_filled:
                    fvg.partially_filled = True
                if highs[i] >= fvg.bottom and not fvg.retested:
                    fvg.retested = True


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_fvg(
    df: pd.DataFrame,
    current_price: float,
    signal_direction: str = "",
    equilibrium: float = 0.0,
) -> FVGResult:
    score   = 0
    reasons: list[str] = []
    max_sc  = SCORE_WEIGHTS["fvg"]

    fvgs = detect_fvgs(df, equilibrium=equilibrium)
    update_fvg_states(fvgs, df)

    active = [f for f in fvgs if not f.mitigated]

    last_bull = next((f for f in reversed(active) if f.kind == "bullish"), None)
    last_bear = next((f for f in reversed(active) if f.kind == "bearish"), None)

    expected = "bullish" if signal_direction == "BUY" else (
        "bearish" if signal_direction == "SELL" else "")

    in_fvg    = False
    fvg_kind  = ""
    match_fvg: Optional[FVG] = None

    for fvg in reversed(active):
        if expected and fvg.kind != expected:
            continue
        if fvg.price_in_fvg(current_price):
            in_fvg    = True
            fvg_kind  = fvg.kind
            match_fvg = fvg
            break

    # ── Scoring ──────────────────────────────────────────────────────────────
    if active:
        a_count = sum(1 for f in active if f.quality == "A")
        score += 2 + min(a_count, 2)
        reasons.append(f"{len(active)} active FVG(s) ({a_count} grade-A)")

    if in_fvg and match_fvg:
        q = match_fvg.quality
        if q == "A":
            score += 9
        elif q == "B":
            score += 7
        else:
            score += 5
        zone_ok = (signal_direction == "BUY" and match_fvg.in_discount) or \
                  (signal_direction == "SELL" and match_fvg.in_premium) or \
                  not signal_direction
        reasons.append(
            f"Price inside {fvg_kind.capitalize()} FVG (grade {q}) "
            f"@ {match_fvg.bottom:.2f}–{match_fvg.top:.2f}"
        )
        if match_fvg.retested and not match_fvg.partially_filled:
            score += 2
            reasons.append("FVG first retest (fresh) ✅")
        elif match_fvg.partially_filled:
            score += 1
            reasons.append("FVG partially filled — still valid")
        if zone_ok and signal_direction:
            score += 1
            reasons.append(f"FVG in correct zone for {signal_direction}")

    elif not in_fvg:
        nearby = [
            f for f in active
            if abs(f.mid - current_price) / max(current_price, 1) < 0.003
            and (not expected or f.kind == expected)
        ]
        if nearby:
            score += 3
            reasons.append(f"Grade-{nearby[-1].quality} FVG nearby @ {nearby[-1].mid:.2f}")

    score = min(score, max_sc)
    logger.debug(f"FVG | total={len(fvgs)} active={len(active)} in_fvg={in_fvg} score={score}/{max_sc}")

    return FVGResult(
        all_fvgs=fvgs, active_fvgs=active,
        last_bullish=last_bull, last_bearish=last_bear,
        price_in_fvg=in_fvg, in_fvg_kind=fvg_kind,
        score=score, reasons=reasons,
    )
