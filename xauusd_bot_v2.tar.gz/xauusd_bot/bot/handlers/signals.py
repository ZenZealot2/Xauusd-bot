"""
bot/handlers/signals.py
=======================
Handles:
  /signal  — Manual scan on demand
  Callback: scan_now, recent_signals, close_win/loss/be_<id>

Also exports broadcast_signal() used by the scheduler.
"""

from __future__ import annotations

import io
from typing import Any, Optional

from telegram import Update, InputMediaPhoto
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
from telegram.constants import ParseMode
from telegram.error import TelegramError

from engine.signal_generator import run_manual_scan
from database.operations     import (
    get_recent_signals,
    update_signal_result,
    get_all_active_users,
    get_user,
    increment_user_signals_today,
    get_user_signals_today,
    record_signal_sent,
)
from analysis.multi_timeframe import run_full_analysis
from charts.chart_generator   import generate_signal_chart
from bot.keyboards.menus      import main_menu, signal_detail_menu
from utils.formatters         import format_signal_message, format_signal_summary_line
from utils.logger             import get_logger
from config.settings          import SUBSCRIPTION_ENABLED, FREE_SIGNAL_LIMIT, CHANNEL_ID

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# /signal command
# ─────────────────────────────────────────────────────────────────────────────

async def cmd_signal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user:
        return

    # Check free limit
    if SUBSCRIPTION_ENABLED:
        signals_today = get_user_signals_today(user.id)
        user_data     = get_user(user.id)
        is_premium    = user_data.get("is_premium", 0) if user_data else 0

        if not is_premium and signals_today >= FREE_SIGNAL_LIMIT:
            await update.message.reply_text(
                f"⚠️ You've used your {FREE_SIGNAL_LIMIT} free signals today.\n"
                f"Upgrade to premium for unlimited signals.",
                reply_markup=main_menu(),
            )
            return

    msg = await update.message.reply_text(
        "🔍 <b>Scanning XAUUSD market…</b>\nAnalysing M1 → M5 → M15 → H1 → H4…",
        parse_mode=ParseMode.HTML,
    )

    signal = run_manual_scan()

    if signal is None:
        await msg.edit_text(
            "🔍 <b>No signal found.</b>\n\n"
            "Market conditions do not meet the minimum requirements:\n"
            "• H4 + H1 trend alignment required\n"
            "• Valid OB or FVG setup on M15\n"
            "• Minimum 70% AI confidence\n\n"
            "Try again in a few minutes.",
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu(),
        )
        return

    await _send_signal_to_user(context, user.id, signal, msg)
    increment_user_signals_today(user.id)


# ─────────────────────────────────────────────────────────────────────────────
# Signal sending to one user
# ─────────────────────────────────────────────────────────────────────────────

async def _send_signal_to_user(
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    signal: dict[str, Any],
    existing_msg=None,
) -> bool:
    """
    Send a formatted signal message + chart to a user.
    Deletes *existing_msg* if provided (the "scanning..." placeholder).
    Returns True on success.
    """
    text = format_signal_message(signal)

    # Generate chart
    chart_buf: Optional[io.BytesIO] = None
    try:
        mtf = run_full_analysis()
        if not mtf.m15.df.empty:
            obs  = mtf.m15.order_blocks.active_obs if mtf.m15.order_blocks else []
            fvgs = mtf.m15.fvg.active_fvgs         if mtf.m15.fvg         else []
            lv   = mtf.m15.smart_money.buy_side_levels + mtf.m15.smart_money.sell_side_levels \
                   if mtf.m15.smart_money else []
            chart_buf = generate_signal_chart(mtf.m15.df, signal, obs, fvgs, lv)
    except Exception as exc:
        logger.warning(f"Chart generation error (non-fatal): {exc}")

    try:
        if existing_msg:
            try:
                await existing_msg.delete()
            except Exception:
                pass

        signal_id = signal.get("id", 0)

        if chart_buf:
            chart_buf.seek(0)
            await context.bot.send_photo(
                chat_id=chat_id,
                photo=chart_buf,
                caption=text,
                parse_mode=ParseMode.HTML,
                reply_markup=signal_detail_menu(signal_id),
            )
        else:
            await context.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=signal_detail_menu(signal_id),
            )
        return True
    except TelegramError as exc:
        logger.error(f"Failed to send signal to {chat_id}: {exc}")
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Broadcast to all subscribers (called by scheduler)
# ─────────────────────────────────────────────────────────────────────────────

async def broadcast_signal(
    signal: dict[str, Any],
    context: ContextTypes.DEFAULT_TYPE,
) -> dict[str, int]:
    """
    Broadcast a signal to all active users + optional channel.
    Called by the scheduler when a new signal is generated.

    Returns {"sent": N, "failed": M}.
    """
    users = get_all_active_users()
    sent  = 0
    failed = 0

    text  = format_signal_message(signal)
    signal_id = signal.get("id", 0)

    # Generate chart once for all users
    chart_buf: Optional[io.BytesIO] = None
    chart_bytes: Optional[bytes] = None
    try:
        mtf = run_full_analysis()
        if not mtf.m15.df.empty:
            obs  = mtf.m15.order_blocks.active_obs if mtf.m15.order_blocks else []
            fvgs = mtf.m15.fvg.active_fvgs         if mtf.m15.fvg         else []
            lv   = (mtf.m15.smart_money.buy_side_levels + mtf.m15.smart_money.sell_side_levels
                    if mtf.m15.smart_money else [])
            chart_buf = generate_signal_chart(mtf.m15.df, signal, obs, fvgs, lv)
            if chart_buf:
                chart_bytes = chart_buf.read()
    except Exception as exc:
        logger.warning(f"Broadcast chart error: {exc}")

    # Send to channel first (if configured)
    if CHANNEL_ID:
        try:
            buf = io.BytesIO(chart_bytes) if chart_bytes else None
            if buf:
                await context.bot.send_photo(
                    chat_id=CHANNEL_ID, photo=buf,
                    caption=text, parse_mode=ParseMode.HTML,
                )
            else:
                await context.bot.send_message(
                    chat_id=CHANNEL_ID, text=text, parse_mode=ParseMode.HTML,
                )
            logger.info(f"Broadcast: signal sent to channel {CHANNEL_ID}")
        except TelegramError as exc:
            logger.warning(f"Broadcast: channel send failed: {exc}")

    # Send to individual users
    for user in users:
        uid = user.get("telegram_id")
        if not uid:
            continue

        try:
            buf = io.BytesIO(chart_bytes) if chart_bytes else None
            if buf:
                await context.bot.send_photo(
                    chat_id=uid, photo=buf,
                    caption=text, parse_mode=ParseMode.HTML,
                    reply_markup=signal_detail_menu(signal_id),
                )
            else:
                await context.bot.send_message(
                    chat_id=uid, text=text, parse_mode=ParseMode.HTML,
                    reply_markup=signal_detail_menu(signal_id),
                )

            # Record in DB
            db_user_id = user.get("id")
            if db_user_id and signal_id:
                record_signal_sent(signal_id, db_user_id)
            increment_user_signals_today(uid)
            sent += 1

        except TelegramError as exc:
            logger.warning(f"Broadcast: failed to send to user {uid}: {exc}")
            failed += 1

    logger.info(f"Broadcast complete: sent={sent} failed={failed}")
    return {"sent": sent, "failed": failed}


# ─────────────────────────────────────────────────────────────────────────────
# /signals — recent signal history
# ─────────────────────────────────────────────────────────────────────────────

async def cmd_recent_signals(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    recent = get_recent_signals(limit=5)
    if not recent:
        await update.message.reply_text("No signals yet.", reply_markup=main_menu())
        return

    lines = ["<b>📡 Recent Signals:</b>\n"]
    for s in recent:
        import json
        s["reasons"] = json.loads(s.get("reasons", "[]"))
        lines.append(f"  {format_signal_summary_line(s)}")
        status = s.get("status", "PENDING")
        lines.append(f"  → {status}\n")

    await update.message.reply_text(
        "\n".join(lines),
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu(),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callback: close_win/loss/be — manual result marking
# ─────────────────────────────────────────────────────────────────────────────

async def cb_close_signal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    data  = query.data   # e.g. "close_win_42"

    parts = data.split("_")
    if len(parts) < 3:
        return

    action    = parts[1]   # win | loss | be
    signal_id = int(parts[2])

    status_map = {"win": "WIN", "loss": "LOSS", "be": "BREAKEVEN"}
    status = status_map.get(action, "PENDING")

    update_signal_result(signal_id, status)
    await query.edit_message_caption(
        caption=(query.message.caption or "") + f"\n\n✅ Signal #{signal_id} marked as {status}",
        parse_mode=ParseMode.HTML,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Callback: scan_now
# ─────────────────────────────────────────────────────────────────────────────

async def cb_scan_now(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer("Scanning…")
    fake_update = update
    # Simulate /signal
    await query.edit_message_text(
        "🔍 <b>Scanning XAUUSD market…</b>",
        parse_mode=ParseMode.HTML,
    )
    signal = run_manual_scan()
    if signal:
        try:
            await query.delete_message()
        except Exception:
            pass
        await _send_signal_to_user(context, update.effective_user.id, signal)
    else:
        await query.edit_message_text(
            "🔍 No signal found at this time. Try again shortly.",
            reply_markup=main_menu(),
        )


# ─────────────────────────────────────────────────────────────────────────────
# Callback: recent_signals
# ─────────────────────────────────────────────────────────────────────────────

async def cb_recent_signals(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    recent = get_recent_signals(limit=5)
    if not recent:
        await query.edit_message_text("No signals yet.", reply_markup=main_menu())
        return

    lines = ["<b>📡 Recent Signals:</b>\n"]
    for s in recent:
        import json
        try:
            s["reasons"] = json.loads(s.get("reasons", "[]"))
        except Exception:
            s["reasons"] = []
        lines.append(f"  {format_signal_summary_line(s)} → {s.get('status', '?')}")

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu(),
    )


def get_handlers():
    return [
        CommandHandler("signal",  cmd_signal),
        CommandHandler("signals", cmd_recent_signals),
        CallbackQueryHandler(cb_scan_now,       pattern="^scan_now$"),
        CallbackQueryHandler(cb_recent_signals, pattern="^recent_signals$"),
        CallbackQueryHandler(cb_close_signal,   pattern="^close_(win|loss|be)_\\d+$"),
    ]
