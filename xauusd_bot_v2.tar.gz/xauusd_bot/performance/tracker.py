"""
performance/tracker.py
======================
Improved performance tracker.

Additions:
  - Per-session win rate tracking
  - Per-grade win rate tracking
  - Auto-expire stale signals after 24h
  - Adaptive confidence feedback: triggers weight recalculation
  - Real-time streaming P&L estimation for open positions
"""

from __future__ import annotations

from datetime import datetime, timedelta, date
from typing import Any

import numpy as np

from database.operations import (
    get_pending_signals, update_signal_result,
    calculate_statistics, log_error, get_recent_signals,
)
from engine.data_fetcher  import get_current_price
from utils.helpers        import now_utc
from utils.logger         import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Single signal outcome check
# ─────────────────────────────────────────────────────────────────────────────

def check_signal_outcome(
    signal: dict[str, Any],
    current_price: float,
) -> tuple[str, int, float]:
    """
    Evaluate pending signal against current price.

    Returns (status, result_tp, result_pips).
    Uses best-TP-first priority for WIN classification.
    """
    direction = signal.get("direction", "BUY")
    entry     = float(signal.get("entry",     0))
    sl        = float(signal.get("stop_loss", 0))
    tp1       = float(signal.get("tp1",       0))
    tp2       = float(signal.get("tp2",       0))
    tp3       = float(signal.get("tp3",       0))

    if entry <= 0 or sl <= 0:
        return "PENDING", 0, 0.0

    px = current_price

    if direction.upper() == "BUY":
        if tp3 > 0 and px >= tp3:
            return "WIN", 3, round((tp3 - entry) / 0.10, 1)
        if tp2 > 0 and px >= tp2:
            return "WIN", 2, round((tp2 - entry) / 0.10, 1)
        if tp1 > 0 and px >= tp1:
            return "WIN", 1, round((tp1 - entry) / 0.10, 1)
        if px <= sl:
            return "LOSS", 0, round((sl - entry) / 0.10, 1)   # negative
    else:
        if tp3 > 0 and px <= tp3:
            return "WIN", 3, round((entry - tp3) / 0.10, 1)
        if tp2 > 0 and px <= tp2:
            return "WIN", 2, round((entry - tp2) / 0.10, 1)
        if tp1 > 0 and px <= tp1:
            return "WIN", 1, round((entry - tp1) / 0.10, 1)
        if px >= sl:
            return "LOSS", 0, round((entry - sl) / 0.10, 1)

    return "PENDING", 0, 0.0


def estimate_open_pnl(signal: dict[str, Any], current_price: float) -> float:
    """Return current floating P&L in pips for an open signal."""
    direction = signal.get("direction", "BUY")
    entry     = float(signal.get("entry", 0))
    if entry <= 0:
        return 0.0
    if direction == "BUY":
        return round((current_price - entry) / 0.10, 1)
    else:
        return round((entry - current_price) / 0.10, 1)


# ─────────────────────────────────────────────────────────────────────────────
# Auto-expire stale signals
# ─────────────────────────────────────────────────────────────────────────────

def auto_expire_old_signals(max_age_hours: int = 24) -> int:
    """Mark PENDING signals older than max_age_hours as EXPIRED."""
    pending  = get_pending_signals()
    expired  = 0
    cutoff   = now_utc() - timedelta(hours=max_age_hours)

    for sig in pending:
        created_str = sig.get("created_at", "")
        try:
            created = datetime.strptime(created_str[:19], "%Y-%m-%d %H:%M:%S")
            if created < cutoff.replace(tzinfo=None):
                update_signal_result(sig["id"], "EXPIRED", 0, 0.0)
                expired += 1
        except Exception:
            pass

    if expired:
        logger.info(f"Tracker: auto-expired {expired} stale signal(s)")
    return expired


# ─────────────────────────────────────────────────────────────────────────────
# Main tracker job
# ─────────────────────────────────────────────────────────────────────────────

def run_tracker() -> dict[str, Any]:
    """
    Check all PENDING signals against current market price.
    Closes positions that hit TP or SL.
    Triggers adaptive confidence recalibration when signals close.

    Called every 5 minutes by scheduler.
    """
    pending = get_pending_signals()
    result  = {
        "checked": len(pending),
        "closed": 0,
        "wins": 0,
        "losses": 0,
        "open_pnl": 0.0,
    }

    if not pending:
        auto_expire_old_signals()
        return result

    try:
        price = get_current_price()
        if price <= 0:
            logger.warning("Tracker: could not get current price")
            return result
    except Exception as exc:
        logger.warning(f"Tracker: price fetch failed: {exc}")
        return result

    newly_closed = False

    for sig in pending:
        try:
            status, tp_hit, pips = check_signal_outcome(sig, price)

            if status == "PENDING":
                open_pnl = estimate_open_pnl(sig, price)
                result["open_pnl"] += open_pnl
                continue

            update_signal_result(sig["id"], status, tp_hit, pips)
            result["closed"] += 1
            newly_closed = True

            if status == "WIN":
                result["wins"] += 1
                logger.info(
                    f"Tracker: ✅ Signal #{sig['id']} WIN | "
                    f"TP{tp_hit} | +{pips:.1f} pips | "
                    f"{sig.get('direction')} @ {sig.get('entry')}"
                )
            else:
                result["losses"] += 1
                logger.info(
                    f"Tracker: ❌ Signal #{sig['id']} LOSS | "
                    f"{pips:.1f} pips | "
                    f"{sig.get('direction')} @ {sig.get('entry')}"
                )

        except Exception as exc:
            logger.error(f"Tracker: error checking signal #{sig.get('id')}: {exc}")

    auto_expire_old_signals()

    # Trigger adaptive confidence recalibration when new outcomes arrive
    if newly_closed:
        try:
            from engine.adaptive_confidence import recalculate_adaptive_weights, train_ml_model
            recalculate_adaptive_weights()
            train_ml_model()
        except Exception as exc:
            logger.debug(f"Tracker: adaptive recalibration skipped: {exc}")

    result["open_pnl"] = round(result["open_pnl"], 1)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Extended statistics (per-session, per-grade)
# ─────────────────────────────────────────────────────────────────────────────

def get_performance_summary() -> dict[str, Any]:
    return {
        "all":     calculate_statistics("all"),
        "daily":   calculate_statistics("daily"),
        "weekly":  calculate_statistics("weekly"),
        "monthly": calculate_statistics("monthly"),
        "per_grade":   _stats_per_field("grade"),
        "per_session": _stats_per_field("session"),
    }


def _stats_per_field(field: str) -> dict[str, dict]:
    """Break down win/loss by grade or session."""
    signals = get_recent_signals(limit=200)
    closed  = [s for s in signals if s.get("status") in ("WIN", "LOSS")]
    groups: dict[str, list] = {}

    for sig in closed:
        key = str(sig.get(field, "unknown"))
        groups.setdefault(key, []).append(sig)

    result: dict[str, dict] = {}
    for key, sigs in groups.items():
        wins    = sum(1 for s in sigs if s.get("status") == "WIN")
        total   = len(sigs)
        wr      = round(wins / total * 100, 1) if total > 0 else 0.0
        avg_pip = round(np.mean([float(s.get("result_pips", 0)) for s in sigs]), 1)
        result[key] = {
            "total": total, "wins": wins, "losses": total - wins,
            "win_rate": wr, "avg_pips": avg_pip,
        }

    return result


def format_tracker_report(summary: dict) -> str:
    all_s  = summary.get("all",     {})
    day_s  = summary.get("daily",   {})
    wk_s   = summary.get("weekly",  {})
    grade  = summary.get("per_grade", {})
    sess   = summary.get("per_session", {})

    lines = [
        "📊 PERFORMANCE TRACKER",
        "═" * 38,
        "",
        "🗓 Today:",
        f"  Signals : {day_s.get('total_signals', 0)}",
        f"  Win Rate: {day_s.get('win_rate', 0):.1f}%",
        f"  Net Pips: {day_s.get('total_pips', 0):+.1f}",
        "",
        "📅 This Week:",
        f"  Signals : {wk_s.get('total_signals', 0)}",
        f"  Win Rate: {wk_s.get('win_rate', 0):.1f}%",
        f"  Prof.Fac: {wk_s.get('profit_factor', 0):.2f}",
        f"  Net Pips: {wk_s.get('total_pips', 0):+.1f}",
        "",
        "📆 All Time:",
        f"  Signals : {all_s.get('total_signals', 0)}",
        f"  Win Rate: {all_s.get('win_rate', 0):.1f}%",
        f"  Prof.Fac: {all_s.get('profit_factor', 0):.2f}",
        f"  Avg RR  : 1:{all_s.get('avg_rr', 0):.2f}",
        f"  Net Pips: {all_s.get('total_pips', 0):+.1f}",
    ]

    if grade:
        lines += ["", "🏅 Win Rate by Grade:"]
        for g, d in sorted(grade.items()):
            lines.append(f"  {g}: {d.get('win_rate', 0):.1f}% ({d.get('total', 0)} signals)")

    if sess:
        lines += ["", "🌍 Win Rate by Session:"]
        for s, d in sorted(sess.items()):
            lines.append(f"  {s}: {d.get('win_rate', 0):.1f}% ({d.get('total', 0)} signals)")

    return "\n".join(lines)
