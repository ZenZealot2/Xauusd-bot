"""
bot/keyboards/menus.py
======================
All InlineKeyboardMarkup and ReplyKeyboardMarkup definitions.
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup


# ─────────────────────────────────────────────────────────────────────────────
# Main Menu
# ─────────────────────────────────────────────────────────────────────────────

def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📡 Scan Now",    callback_data="scan_now"),
            InlineKeyboardButton("📊 My Stats",    callback_data="my_stats"),
        ],
        [
            InlineKeyboardButton("📅 Today",       callback_data="stats_daily"),
            InlineKeyboardButton("📆 This Week",   callback_data="stats_weekly"),
        ],
        [
            InlineKeyboardButton("❓ Help",        callback_data="help"),
            InlineKeyboardButton("🔔 Signals",     callback_data="recent_signals"),
        ],
    ])


# ─────────────────────────────────────────────────────────────────────────────
# Admin Menu
# ─────────────────────────────────────────────────────────────────────────────

def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👥 Users",        callback_data="admin_users"),
            InlineKeyboardButton("📊 Stats",        callback_data="admin_stats"),
        ],
        [
            InlineKeyboardButton("📡 Signals",      callback_data="admin_signals"),
            InlineKeyboardButton("⚙️ Settings",     callback_data="admin_settings"),
        ],
        [
            InlineKeyboardButton("📢 Broadcast",    callback_data="admin_broadcast"),
            InlineKeyboardButton("📜 Logs",         callback_data="admin_logs"),
        ],
        [
            InlineKeyboardButton("📈 Backtest",     callback_data="admin_backtest"),
            InlineKeyboardButton("📋 Reports",      callback_data="admin_reports"),
        ],
    ])


# ─────────────────────────────────────────────────────────────────────────────
# Signal Detail Menu
# ─────────────────────────────────────────────────────────────────────────────

def signal_detail_menu(signal_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Mark WIN",      callback_data=f"close_win_{signal_id}"),
            InlineKeyboardButton("❌ Mark LOSS",     callback_data=f"close_loss_{signal_id}"),
        ],
        [
            InlineKeyboardButton("⚖️ Mark BE",       callback_data=f"close_be_{signal_id}"),
        ],
    ])


# ─────────────────────────────────────────────────────────────────────────────
# Stats period selector
# ─────────────────────────────────────────────────────────────────────────────

def stats_period_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📅 Today",       callback_data="stats_daily"),
            InlineKeyboardButton("📆 This Week",   callback_data="stats_weekly"),
            InlineKeyboardButton("🗓 This Month",  callback_data="stats_monthly"),
        ],
        [
            InlineKeyboardButton("📊 All Time",    callback_data="stats_all"),
        ],
    ])


# ─────────────────────────────────────────────────────────────────────────────
# Confirmation keyboards
# ─────────────────────────────────────────────────────────────────────────────

def confirm_broadcast() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Confirm Send", callback_data="broadcast_confirm"),
            InlineKeyboardButton("❌ Cancel",       callback_data="broadcast_cancel"),
        ]
    ])


def cancel_button() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ Cancel", callback_data="cancel")]
    ])
