"""
engine/confidence.py
====================
AI Confidence Scoring Engine — now backed by adaptive weights and optional ML.

Flow:
  1. Collect raw component scores from all analysis modules.
  2. Pass to AdaptiveConfidenceEngine for dynamic weight adjustment.
  3. Blend with ML prediction if available.
  4. Return ConfidenceResult with grade, classification, and breakdown.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from config.settings import SCORE_WEIGHTS, MAX_SCORE, GRADE_THRESHOLDS
from analysis.market_structure import MarketStructureResult
from analysis.smart_money      import SmartMoneyResult
from analysis.fair_value_gap   import FVGResult
from analysis.order_blocks     import OrderBlockResult
from analysis.trend_filter     import TrendFilterResult
from analysis.momentum         import MomentumResult
from analysis.volume           import VolumeResult
from analysis.session          import SessionResult
from analysis.multi_timeframe  import MTFAnalysisResult
from engine.adaptive_confidence import (
    calculate_adaptive_score,
    get_adaptive_threshold,
    ADAPTIVE_CONFIDENCE_ENABLED,
)
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class ComponentScore:
    component: str
    raw_score: int
    max_score: int
    reasons:   list[str]

    @property
    def pct(self) -> float:
        return (self.raw_score / self.max_score * 100) if self.max_score > 0 else 0.0


@dataclass
class ConfidenceResult:
    total_score:     int
    grade:           str
    classification:  str
    should_generate: bool
    components:      list[ComponentScore]
    all_reasons:     list[str]
    score_breakdown: dict[str, int]
    method:          str       # 'rule-based' | 'adaptive-weights' | 'adaptive-weights+ML'
    threshold_used:  int       # Actual threshold applied (may differ from config)


# ─────────────────────────────────────────────────────────────────────────────
# Grade / Classification
# ─────────────────────────────────────────────────────────────────────────────

def classify_signal(score: int, threshold: int) -> tuple[str, str, bool]:
    """Return (classification, grade, should_generate)."""
    if score >= GRADE_THRESHOLDS["ELITE"]:
        return "ELITE",  "A+", True
    elif score >= GRADE_THRESHOLDS["STRONG"]:
        return "STRONG", "A",  True
    elif score >= GRADE_THRESHOLDS["NORMAL"] and score >= threshold:
        return "NORMAL", "B",  True
    else:
        return "NO_SIGNAL", "C", False


# ─────────────────────────────────────────────────────────────────────────────
# Main confidence calculator
# ─────────────────────────────────────────────────────────────────────────────

def calculate_confidence(mtf: MTFAnalysisResult) -> ConfidenceResult:
    """
    Aggregate all analysis module scores → final AI confidence score.
    Uses adaptive weights and optional ML prediction.
    """
    components: list[ComponentScore] = []
    all_reasons: list[str]           = []

    def _pick(name: str, result, max_sc: int) -> ComponentScore:
        if result is None:
            return ComponentScore(name, 0, max_sc, [f"{name}: no data"])
        sc = max(0, int(getattr(result, "score", 0) or 0))
        rs = list(getattr(result, "reasons", []) or [])
        return ComponentScore(name, min(sc, max_sc), max_sc, rs)

    # ── Market Structure (M15 primary, H1 bonus) ───────────────────────────
    c_ms = _pick("market_structure", mtf.m15.market_structure, SCORE_WEIGHTS["market_structure"])
    if mtf.h1.market_structure and c_ms.raw_score > 0:
        if mtf.h1.market_structure.trend == mtf.htf_direction:
            c_ms = ComponentScore(
                "market_structure",
                min(c_ms.raw_score + 2, c_ms.max_score),
                c_ms.max_score,
                c_ms.reasons + ["H1 structure confirms M15"],
            )
    components.append(c_ms)

    # ── Liquidity Sweep (M15) ─────────────────────────────────────────────
    c_sm = _pick("liquidity_sweep", mtf.m15.smart_money, SCORE_WEIGHTS["liquidity_sweep"])
    components.append(c_sm)

    # ── Order Block (M15 + M5 confluence) ────────────────────────────────
    c_ob = _pick("order_block", mtf.m15.order_blocks, SCORE_WEIGHTS["order_block"])
    if mtf.m5.order_blocks and mtf.m5.order_blocks.price_in_ob:
        c_ob = ComponentScore(
            "order_block",
            min(c_ob.raw_score + 2, c_ob.max_score),
            c_ob.max_score,
            c_ob.reasons + ["M5 OB confluence ✅"],
        )
    components.append(c_ob)

    # ── FVG (M15 + M5 confluence) ────────────────────────────────────────
    c_fvg = _pick("fvg", mtf.m15.fvg, SCORE_WEIGHTS["fvg"])
    if mtf.m5.fvg and mtf.m5.fvg.price_in_fvg:
        c_fvg = ComponentScore(
            "fvg",
            min(c_fvg.raw_score + 2, c_fvg.max_score),
            c_fvg.max_score,
            c_fvg.reasons + ["M5 FVG confluence ✅"],
        )
    components.append(c_fvg)

    # ── Trend Alignment (H1 primary, H4 bonus) ───────────────────────────
    c_tr = _pick("trend_alignment", mtf.h1.trend, SCORE_WEIGHTS["trend_alignment"])
    if mtf.h4.trend and mtf.h4.trend.direction == mtf.htf_direction:
        c_tr = ComponentScore(
            "trend_alignment",
            min(c_tr.raw_score + 3, c_tr.max_score),
            c_tr.max_score,
            c_tr.reasons + [f"H4 trend: {mtf.htf_direction} ✅"],
        )
    components.append(c_tr)

    # ── Volume (M15) ─────────────────────────────────────────────────────
    c_vol = _pick("volume_confirmation", mtf.m15.volume, SCORE_WEIGHTS["volume_confirmation"])
    components.append(c_vol)

    # ── Momentum (M5) ────────────────────────────────────────────────────
    c_mom = _pick("momentum_confirmation", mtf.m5.momentum, SCORE_WEIGHTS["momentum_confirmation"])
    components.append(c_mom)

    # ── Session ──────────────────────────────────────────────────────────
    c_sess = ComponentScore(
        "session_quality",
        mtf.session.score,
        SCORE_WEIGHTS["session_quality"],
        mtf.session.reasons,
    )
    components.append(c_sess)

    # ── Build raw score breakdown ────────────────────────────────────────
    score_breakdown: dict[str, int] = {}
    component_raw_scores: dict[str, int] = {}
    for c in components:
        score_breakdown[c.component]      = c.raw_score
        component_raw_scores[c.component] = c.raw_score
        for r in c.reasons:
            if r and r not in all_reasons:
                all_reasons.append(r)

    # ── Adaptive scoring ─────────────────────────────────────────────────
    final_score, method = calculate_adaptive_score(component_raw_scores, score_breakdown)
    final_score = max(0, min(final_score, MAX_SCORE))

    # ── Threshold (may be adaptively raised) ────────────────────────────
    threshold = get_adaptive_threshold()

    classification, grade, should_gen = classify_signal(final_score, threshold)

    logger.info(
        f"Confidence | score={final_score}/100 grade={grade} "
        f"class={classification} method={method} threshold={threshold}"
    )

    return ConfidenceResult(
        total_score=final_score,
        grade=grade,
        classification=classification,
        should_generate=should_gen,
        components=components,
        all_reasons=all_reasons,
        score_breakdown=score_breakdown,
        method=method,
        threshold_used=threshold,
    )


def format_score_breakdown(result: ConfidenceResult) -> str:
    """Human-readable breakdown for admin panel."""
    lines = [f"🎯 Score: {result.total_score}/100 ({result.grade}) [{result.method}]\n"]
    for c in result.components:
        pct = int(c.pct)
        bar = "█" * (c.raw_score * 10 // c.max_score) if c.max_score else ""
        lines.append(f"  {c.component:<28} {c.raw_score:>3}/{c.max_score}  {bar}")
    return "\n".join(lines)
