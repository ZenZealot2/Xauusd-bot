"""
analysis/order_blocks.py
========================
Improved Order Block detection and ranking.

Improvements:
  - Volume-confirmed impulse required for Grade A OBs
  - OB age limit: OB_MAX_AGE_BARS (ignore stale blocks)
  - Premium/discount zone alignment check
  - "Breaker Block" detection: OB that was mitigated and now acts as opposing OB
  - Demand/supply zone (OB body, not full wick) for tighter entries
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

from config.settings import SCORE_WEIGHTS, OB_MIN_MOVE_MULTIPLIER, ATR_PERIOD, OB_MAX_AGE_BARS
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class OrderBlock:
    kind:          str     # 'bullish' | 'bearish'
    top:           float
    bottom:        float
    mid:           float   = field(init=False)
    bar_index:     int     = 0
    mitigated:     bool    = False
    fresh:         bool    = True
    quality:       str     = "C"
    impulse_size:  float   = 0.0
    volume_ratio:  float   = 1.0   # Volume on OB bar vs average
    is_breaker:    bool    = False  # Former OB now acting as opposing OB

    def __post_init__(self):
        self.mid = (self.top + self.bottom) / 2

    def price_in_ob(self, price: float) -> bool:
        return self.bottom <= price <= self.top

    @property
    def size(self) -> float:
        return abs(self.top - self.bottom)


@dataclass
class OrderBlockResult:
    all_obs:      list[OrderBlock]
    active_obs:   list[OrderBlock]
    last_bullish: Optional[OrderBlock]
    last_bearish: Optional[OrderBlock]
    price_in_ob:  bool
    in_ob_kind:   str
    matching_ob:  Optional[OrderBlock]
    score:         int
    reasons:       list[str]


# ─────────────────────────────────────────────────────────────────────────────
# ATR (local)
# ─────────────────────────────────────────────────────────────────────────────

def _atr_arr(df: pd.DataFrame, period: int = ATR_PERIOD) -> np.ndarray:
    high  = df["high"].values
    low   = df["low"].values
    close = df["close"].values
    n     = len(df)

    tr    = np.zeros(n)
    tr[0] = high[0] - low[0]
    for i in range(1, n):
        tr[i] = max(high[i] - low[i],
                    abs(high[i] - close[i-1]),
                    abs(low[i]  - close[i-1]))

    atr = np.zeros(n)
    if n >= period:
        atr[period - 1] = tr[:period].mean()
        for i in range(period, n):
            atr[i] = (atr[i-1] * (period - 1) + tr[i]) / period
    return atr


# ─────────────────────────────────────────────────────────────────────────────
# Detection
# ─────────────────────────────────────────────────────────────────────────────

def detect_order_blocks(
    df: pd.DataFrame,
    min_multiplier: float = OB_MIN_MOVE_MULTIPLIER,
    lookback:       int   = OB_MAX_AGE_BARS,
) -> list[OrderBlock]:
    if len(df) < ATR_PERIOD + 5:
        return []

    atr_arr = _atr_arr(df)
    opens   = df["open"].values
    closes  = df["close"].values
    highs   = df["high"].values
    lows    = df["low"].values
    vols    = df["volume"].values
    n       = len(df)

    # Volume moving average for normalisation
    vol_ma = pd.Series(vols).rolling(20, min_periods=1).mean().values

    start = max(ATR_PERIOD, n - lookback)
    obs: dict[int, OrderBlock] = {}

    for i in range(start + 1, n):
        body    = closes[i] - opens[i]
        atr_val = atr_arr[i - 1] if i > 0 else atr_arr[i]
        thresh  = atr_val * min_multiplier

        if abs(body) < thresh:
            continue

        v_ratio = vols[i] / vol_ma[i] if vol_ma[i] > 0 else 1.0

        if body > 0:  # Bullish impulse → last bearish candle before it
            for j in range(i - 1, max(i - 5, -1), -1):
                if closes[j] < opens[j]:
                    ob = OrderBlock(
                        kind="bullish",
                        top=opens[j],      # use body (not wick) for tighter zone
                        bottom=lows[j],    # extend to wick low for SL reference
                        bar_index=j,
                        impulse_size=abs(body),
                        volume_ratio=v_ratio,
                    )
                    ob.quality = _rate_ob(abs(body), atr_val, v_ratio)
                    existing   = obs.get(j)
                    if existing is None or ob.impulse_size > existing.impulse_size:
                        obs[j] = ob
                    break

        elif body < 0:  # Bearish impulse → last bullish candle
            for j in range(i - 1, max(i - 5, -1), -1):
                if closes[j] > opens[j]:
                    ob = OrderBlock(
                        kind="bearish",
                        top=highs[j],      # wick high for SL reference
                        bottom=opens[j],   # use body for tighter entry zone
                        bar_index=j,
                        impulse_size=abs(body),
                        volume_ratio=v_ratio,
                    )
                    ob.quality = _rate_ob(abs(body), atr_val, v_ratio)
                    existing   = obs.get(j)
                    if existing is None or ob.impulse_size > existing.impulse_size:
                        obs[j] = ob
                    break

    return sorted(obs.values(), key=lambda o: o.bar_index)


def _rate_ob(impulse: float, atr: float, v_ratio: float) -> str:
    """
    Grade A = impulse ≥ 2.5× ATR AND volume ≥ 1.5× average
    Grade B = impulse ≥ 1.5× ATR OR volume ≥ 1.3×
    Grade C = minimum qualifying OB
    """
    ratio = impulse / atr if atr > 0 else 0
    if ratio >= 2.5 and v_ratio >= 1.5:
        return "A"
    elif ratio >= 1.5 or v_ratio >= 1.3:
        return "B"
    return "C"


# ─────────────────────────────────────────────────────────────────────────────
# State updates (mitigation, fresh, breaker)
# ─────────────────────────────────────────────────────────────────────────────

def update_ob_states(obs: list[OrderBlock], df: pd.DataFrame) -> None:
    closes = df["close"].values
    highs  = df["high"].values
    lows   = df["low"].values
    n      = len(df)

    for ob in obs:
        if ob.bar_index + 1 >= n:
            continue
        touch_count = 0
        for i in range(ob.bar_index + 1, n):
            if ob.kind == "bullish":
                # Entered zone (lost freshness)
                if lows[i] <= ob.top:
                    ob.fresh = False
                    touch_count += 1
                # Mitigated by close below bottom
                if closes[i] < ob.bottom:
                    ob.mitigated = True
                    ob.is_breaker = True  # becomes a bearish breaker block
                    break
            else:
                if highs[i] >= ob.bottom:
                    ob.fresh = False
                    touch_count += 1
                if closes[i] > ob.top:
                    ob.mitigated = True
                    ob.is_breaker = True  # becomes a bullish breaker block
                    break


# ─────────────────────────────────────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────────────────────────────────────

def analyse_order_blocks(
    df: pd.DataFrame,
    current_price: float,
    signal_direction: str = "",
    equilibrium: float = 0.0,
) -> OrderBlockResult:
    score   = 0
    reasons: list[str] = []
    max_sc  = SCORE_WEIGHTS["order_block"]

    obs = detect_order_blocks(df)
    update_ob_states(obs, df)
    obs = obs[-15:]

    active = [o for o in obs if not o.mitigated]

    last_bull = next((o for o in reversed(active) if o.kind == "bullish"), None)
    last_bear = next((o for o in reversed(active) if o.kind == "bearish"), None)

    expected = "bullish" if signal_direction == "BUY" else (
        "bearish" if signal_direction == "SELL" else "")

    in_ob      = False
    in_ob_kind = ""
    match_ob: Optional[OrderBlock] = None

    for ob in reversed(active):
        if expected and ob.kind != expected:
            continue
        if ob.price_in_ob(current_price):
            in_ob      = True
            in_ob_kind = ob.kind
            match_ob   = ob
            break

    # Also check breaker blocks (flipped OBs)
    if not in_ob:
        breakers = [o for o in obs if o.is_breaker and o.mitigated]
        opp = "bearish" if expected == "bullish" else "bullish"
        for ob in reversed(breakers[-5:]):
            if ob.kind == opp and ob.price_in_ob(current_price):
                in_ob      = True
                in_ob_kind = f"breaker_{ob.kind}"
                match_ob   = ob
                reasons.append(f"Breaker Block (flipped {ob.kind} OB) active ✅")
                break

    # ── Scoring ──────────────────────────────────────────────────────────────
    if active:
        a_count = sum(1 for o in active if o.quality == "A")
        score += 2 + min(a_count, 2)
        reasons.append(f"{len(active)} active OB(s) ({a_count} grade-A)")

    if in_ob and match_ob:
        q = match_ob.quality
        if q == "A":
            score += 9
        elif q == "B":
            score += 7
        else:
            score += 5
        fresh_str = "Fresh" if match_ob.fresh else "Tested"
        kind_str  = in_ob_kind.replace("breaker_", "Breaker ").capitalize()
        vol_str   = f"vol={match_ob.volume_ratio:.1f}×"
        reasons.append(
            f"{fresh_str} {kind_str} OB (grade {q}, {vol_str}) "
            f"@ {match_ob.bottom:.2f}–{match_ob.top:.2f}"
        )
        if match_ob.fresh:
            score += 2
            reasons.append("OB first touch (pristine) ✅")
        if match_ob.volume_ratio >= 1.5:
            score += 1
            reasons.append(f"High-volume OB creation ({match_ob.volume_ratio:.1f}× avg)")

    elif not in_ob:
        nearby = [
            o for o in active
            if abs(o.mid - current_price) / max(current_price, 1) < 0.003
            and (not expected or o.kind == expected)
        ]
        if nearby:
            score += 3
            reasons.append(f"OB nearby @ {nearby[-1].mid:.2f} (grade {nearby[-1].quality})")

    score = min(score, max_sc)
    logger.debug(f"OB | total={len(obs)} active={len(active)} in_ob={in_ob} score={score}/{max_sc}")

    return OrderBlockResult(
        all_obs=obs, active_obs=active,
        last_bullish=last_bull, last_bearish=last_bear,
        price_in_ob=in_ob, in_ob_kind=in_ob_kind,
        matching_ob=match_ob, score=score, reasons=reasons,
    )
