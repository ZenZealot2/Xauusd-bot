"""
engine/data_fetcher.py
======================
Multi-source OHLCV fetcher with intelligent fallback chain.

Priority:
  1. MetaTrader 5  — perfect real-time XAUUSD (Windows only)
  2. TwelveData    — real-time XAU/USD REST API (cross-platform, free tier)
  3. yfinance      — GC=F Gold Futures fallback (15-20min delayed, last resort)

Each source has an in-memory cache with per-timeframe TTL to:
  - Minimise API calls (TwelveData free: 800 credits/day)
  - Avoid hammering the source on every 5-minute scan cycle
"""

from __future__ import annotations

import time
import threading
from datetime import datetime, timedelta
from typing import Optional

import numpy as np
import pandas as pd

from config.settings import (
    DATA_SOURCE, TWELVEDATA_API_KEY, TWELVEDATA_SYMBOL,
    TWELVEDATA_INTERVALS, MT5_LOGIN, MT5_PASSWORD, MT5_SERVER, MT5_SYMBOL,
    YFINANCE_INTERVALS, YFINANCE_PERIODS, BARS_TO_KEEP, CACHE_TTL,
    GOLD_TICKER, TIMEFRAMES,
)
from utils.logger  import get_logger
from utils.helpers import retry

logger = get_logger(__name__)

# ─── Optional import guards ───────────────────────────────────────────────────
try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
    logger.info("MetaTrader5 module found.")
except ImportError:
    mt5 = None
    MT5_AVAILABLE = False
    logger.info("MetaTrader5 not installed — MT5 source unavailable.")

try:
    from twelvedata import TDClient
    _td_client: Optional[TDClient] = None
    TD_AVAILABLE = bool(TWELVEDATA_API_KEY)
except ImportError:
    TDClient = None
    _td_client = None
    TD_AVAILABLE = False
    logger.warning("twelvedata package not installed — using yfinance fallback.")

# ─────────────────────────────────────────────────────────────────────────────
# Time-based in-memory cache
# ─────────────────────────────────────────────────────────────────────────────

class _Cache:
    def __init__(self):
        self._lock  = threading.Lock()
        self._store: dict[str, tuple[pd.DataFrame, float]] = {}

    def get(self, key: str, ttl: int) -> Optional[pd.DataFrame]:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            df, ts = entry
            if time.time() - ts > ttl:
                del self._store[key]
                return None
            return df.copy()

    def set(self, key: str, df: pd.DataFrame) -> None:
        with self._lock:
            self._store[key] = (df.copy(), time.time())

    def clear(self, key: str | None = None) -> None:
        with self._lock:
            if key:
                self._store.pop(key, None)
            else:
                self._store.clear()


_cache = _Cache()

# ─────────────────────────────────────────────────────────────────────────────
# Source 1 — MetaTrader 5
# ─────────────────────────────────────────────────────────────────────────────

_MT5_TF_MAP = {
    "M1":  1,    # mt5.TIMEFRAME_M1
    "M5":  5,    # mt5.TIMEFRAME_M5
    "M15": 15,   # mt5.TIMEFRAME_M15
    "H1":  16385, # mt5.TIMEFRAME_H1
    "H4":  16388, # mt5.TIMEFRAME_H4
}

_mt5_connected = False

def _ensure_mt5_connected() -> bool:
    """Initialise MT5 connection once."""
    global _mt5_connected
    if not MT5_AVAILABLE:
        return False
    if _mt5_connected:
        return True
    try:
        if not mt5.initialize(login=MT5_LOGIN, password=MT5_PASSWORD, server=MT5_SERVER):
            logger.error(f"MT5 initialize failed: {mt5.last_error()}")
            return False
        _mt5_connected = True
        info = mt5.terminal_info()
        logger.info(f"MT5 connected: {info.name} build {info.build}")
        return True
    except Exception as exc:
        logger.error(f"MT5 connection error: {exc}")
        return False


def _fetch_mt5(timeframe: str) -> pd.DataFrame:
    """Fetch OHLCV from MetaTrader 5."""
    if not _ensure_mt5_connected():
        raise RuntimeError("MT5 not available")

    tf_val = _MT5_TF_MAP.get(timeframe)
    if tf_val is None:
        raise ValueError(f"Unknown TF: {timeframe}")

    n = BARS_TO_KEEP.get(timeframe, 300)
    rates = mt5.copy_rates_from_pos(MT5_SYMBOL, tf_val, 0, n)
    if rates is None or len(rates) == 0:
        raise RuntimeError(f"MT5: no data for {timeframe}")

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time")
    df = df.rename(columns={
        "open": "open", "high": "high", "low": "low",
        "close": "close", "tick_volume": "volume",
    })
    df = df[["open", "high", "low", "close", "volume"]].astype(float)
    logger.debug(f"MT5: fetched {len(df)} bars for {timeframe}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Source 2 — TwelveData
# ─────────────────────────────────────────────────────────────────────────────

def _get_td_client() -> TDClient:
    global _td_client
    if _td_client is None:
        _td_client = TDClient(apikey=TWELVEDATA_API_KEY)
    return _td_client


@retry(max_attempts=3, delay=2.0, exceptions=(Exception,))
def _fetch_twelvedata(timeframe: str) -> pd.DataFrame:
    """Fetch OHLCV from TwelveData REST API (real XAU/USD spot data)."""
    if not TD_AVAILABLE or not TWELVEDATA_API_KEY:
        raise RuntimeError("TwelveData not configured")

    td      = _get_td_client()
    n       = BARS_TO_KEEP.get(timeframe, 300)
    interval = TWELVEDATA_INTERVALS.get(timeframe, "15min")

    ts = td.time_series(
        symbol=TWELVEDATA_SYMBOL,
        interval=interval,
        outputsize=min(n, 5000),
        timezone="UTC",
        order="ASC",
    )
    df: pd.DataFrame = ts.as_pandas()

    if df is None or df.empty:
        raise RuntimeError(f"TwelveData: empty response for {timeframe}")

    # Normalise
    df.columns = [c.lower() for c in df.columns]
    df = df[["open", "high", "low", "close", "volume"]].astype(float)
    df.index = pd.DatetimeIndex(df.index, tz="UTC")
    df = df.tail(n)

    logger.debug(
        f"TwelveData: {len(df)} bars for {timeframe} "
        f"(latest close={df['close'].iloc[-1]:.2f})"
    )
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Source 3 — yfinance (fallback)
# ─────────────────────────────────────────────────────────────────────────────

@retry(max_attempts=3, delay=2.0, exceptions=(Exception,))
def _fetch_yfinance(timeframe: str) -> pd.DataFrame:
    """Fetch from Yahoo Finance GC=F (Gold Futures, DELAYED — last resort)."""
    import yfinance as yf

    interval = YFINANCE_INTERVALS[timeframe]
    period   = YFINANCE_PERIODS[timeframe]
    n        = BARS_TO_KEEP.get(timeframe, 300)

    logger.warning(
        f"Using yfinance fallback for {timeframe} — data may be delayed 15-20 minutes"
    )

    ticker = yf.Ticker(GOLD_TICKER)
    df     = ticker.history(period=period, interval=interval, auto_adjust=True)

    if df.empty:
        raise RuntimeError(f"yfinance: no data for {timeframe}")

    df.columns = [c.lower() for c in df.columns]
    df = df[["open", "high", "low", "close", "volume"]].astype(float)

    if df.index.tzinfo is None:
        df.index = df.index.tz_localize("UTC")
    else:
        df.index = df.index.tz_convert("UTC")

    if timeframe == "H4":
        df = df.resample("4h", closed="left", label="left").agg(
            {"open": "first", "high": "max", "low": "min",
             "close": "last",  "volume": "sum"}
        ).dropna()

    df = df.dropna(subset=["open", "high", "low", "close"]).tail(n)
    logger.debug(f"yfinance: {len(df)} bars for {timeframe}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Fetch dispatcher
# ─────────────────────────────────────────────────────────────────────────────

def _fetch_raw(timeframe: str) -> pd.DataFrame:
    """
    Try data sources in priority order:
      1. MT5   (if DATA_SOURCE=mt5 or MT5 is available and connected)
      2. TwelveData (if API key set and package installed)
      3. yfinance   (always available as last resort)
    """
    # Explicit MT5 source
    if DATA_SOURCE == "mt5" or (MT5_AVAILABLE and DATA_SOURCE == "mt5"):
        try:
            return _fetch_mt5(timeframe)
        except Exception as exc:
            logger.warning(f"MT5 source failed for {timeframe}: {exc} — trying TwelveData")

    # TwelveData source (default)
    if DATA_SOURCE in ("twelvedata", "td") or (TD_AVAILABLE and DATA_SOURCE != "yfinance"):
        try:
            return _fetch_twelvedata(timeframe)
        except Exception as exc:
            logger.warning(f"TwelveData failed for {timeframe}: {exc} — falling back to yfinance")

    # yfinance fallback
    return _fetch_yfinance(timeframe)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def get_ohlcv(timeframe: str, force_refresh: bool = False) -> pd.DataFrame:
    """
    Return OHLCV DataFrame for *timeframe*. Uses cache if data is fresh.

    Parameters
    ----------
    timeframe     : 'M1' | 'M5' | 'M15' | 'H1' | 'H4'
    force_refresh : Bypass cache and fetch fresh data.
    """
    if timeframe not in TIMEFRAMES:
        raise ValueError(f"Unknown timeframe: {timeframe}")

    ttl = CACHE_TTL.get(timeframe, 60)

    if not force_refresh:
        cached = _cache.get(timeframe, ttl)
        if cached is not None:
            return cached

    df = _fetch_raw(timeframe)
    if not df.empty:
        _cache.set(timeframe, df)
    return df


def get_all_timeframes(force_refresh: bool = False) -> dict[str, pd.DataFrame]:
    """Fetch all timeframes. Returns dict keyed by TF label."""
    result: dict[str, pd.DataFrame] = {}
    for tf in TIMEFRAMES:
        try:
            result[tf] = get_ohlcv(tf, force_refresh=force_refresh)
        except Exception as exc:
            logger.error(f"Failed to fetch {tf}: {exc}")
            result[tf] = pd.DataFrame()
    return result


def get_current_price() -> float:
    """Return the most recent close price."""
    for tf in ("M1", "M5", "M15"):
        try:
            df = get_ohlcv(tf, force_refresh=True)
            if not df.empty:
                return float(df["close"].iloc[-1])
        except Exception:
            continue
    return 0.0


def validate_dataframe(df: pd.DataFrame, min_bars: int = 50) -> bool:
    """Validate that a DataFrame has correct structure and sufficient data."""
    if df is None or df.empty:
        return False
    required = {"open", "high", "low", "close", "volume"}
    if not required.issubset(df.columns):
        return False
    if len(df) < min_bars:
        return False
    if (df[["open", "high", "low", "close"]] <= 0).any().any():
        return False
    return True


def invalidate_cache(timeframe: str | None = None) -> None:
    _cache.clear(timeframe)
    logger.debug(f"Cache cleared: {timeframe or 'ALL'}")


def get_data_source_info() -> str:
    """Return a human-readable string about the active data source."""
    if DATA_SOURCE == "mt5" and MT5_AVAILABLE and _mt5_connected:
        return f"MetaTrader 5 ({MT5_SYMBOL}) — real-time"
    elif TD_AVAILABLE and TWELVEDATA_API_KEY:
        return f"TwelveData ({TWELVEDATA_SYMBOL}) — real-time spot"
    else:
        return f"yfinance ({GOLD_TICKER}) — DELAYED FUTURES (fallback)"
