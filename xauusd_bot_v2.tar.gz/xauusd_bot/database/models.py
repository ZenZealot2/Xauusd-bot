"""
database/models.py
==================
SQLite schema definitions.
Call `create_tables(conn)` once at startup to ensure all tables exist.
"""

import sqlite3
from utils.logger import get_logger

logger = get_logger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# DDL statements
# ─────────────────────────────────────────────────────────────────────────────

SQL_CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id     INTEGER NOT NULL UNIQUE,
    username        TEXT,
    first_name      TEXT,
    last_name       TEXT,
    is_premium      INTEGER NOT NULL DEFAULT 0,    -- 0=free, 1=premium
    is_active       INTEGER NOT NULL DEFAULT 1,
    is_banned       INTEGER NOT NULL DEFAULT 0,
    signals_today   INTEGER NOT NULL DEFAULT 0,
    last_signal_date TEXT,                          -- YYYY-MM-DD
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    last_seen_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

SQL_CREATE_SIGNALS = """
CREATE TABLE IF NOT EXISTS signals (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    direction       TEXT NOT NULL,                 -- BUY | SELL
    entry           REAL NOT NULL,
    stop_loss       REAL NOT NULL,
    tp1             REAL NOT NULL,
    tp2             REAL NOT NULL,
    tp3             REAL NOT NULL,
    confidence      INTEGER NOT NULL,
    grade           TEXT NOT NULL,                 -- A+ | A | B | C
    classification  TEXT NOT NULL,                 -- ELITE | STRONG | NORMAL
    trend           TEXT,
    session         TEXT,
    rr_ratio        REAL,
    reasons         TEXT,                          -- JSON array
    analysis_json   TEXT,                          -- Full analysis snapshot (JSON)
    status          TEXT NOT NULL DEFAULT 'PENDING', -- PENDING | WIN | LOSS | BREAKEVEN | EXPIRED
    result_tp       INTEGER DEFAULT 0,             -- 0=none, 1=TP1, 2=TP2, 3=TP3
    result_pips     REAL DEFAULT 0.0,
    chart_path      TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    closed_at       TEXT
);
"""

SQL_CREATE_SIGNAL_RECIPIENTS = """
CREATE TABLE IF NOT EXISTS signal_recipients (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_id   INTEGER NOT NULL REFERENCES signals(id) ON DELETE CASCADE,
    user_id     INTEGER NOT NULL REFERENCES users(id)   ON DELETE CASCADE,
    sent_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

SQL_CREATE_PERFORMANCE = """
CREATE TABLE IF NOT EXISTS performance (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    period          TEXT NOT NULL,    -- daily | weekly | monthly
    period_label    TEXT NOT NULL,    -- e.g. '2024-01' for monthly
    total_signals   INTEGER DEFAULT 0,
    wins            INTEGER DEFAULT 0,
    losses          INTEGER DEFAULT 0,
    break_evens     INTEGER DEFAULT 0,
    win_rate        REAL DEFAULT 0.0,
    profit_factor   REAL DEFAULT 0.0,
    avg_rr          REAL DEFAULT 0.0,
    total_pips      REAL DEFAULT 0.0,
    updated_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(period, period_label)
);
"""

SQL_CREATE_SETTINGS = """
CREATE TABLE IF NOT EXISTS settings (
    key     TEXT PRIMARY KEY,
    value   TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

SQL_CREATE_ERROR_LOG = """
CREATE TABLE IF NOT EXISTS error_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    module      TEXT,
    message     TEXT NOT NULL,
    traceback   TEXT,
    logged_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

SQL_CREATE_BROADCASTS = """
CREATE TABLE IF NOT EXISTS broadcasts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    message     TEXT NOT NULL,
    sent_by     INTEGER,               -- admin telegram_id
    total_sent  INTEGER DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

SQL_CREATE_BACKTEST_RUNS = """
CREATE TABLE IF NOT EXISTS backtest_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    start_date  TEXT NOT NULL,
    end_date    TEXT NOT NULL,
    total_trades INTEGER DEFAULT 0,
    win_rate    REAL DEFAULT 0.0,
    profit_factor REAL DEFAULT 0.0,
    max_drawdown REAL DEFAULT 0.0,
    net_pips    REAL DEFAULT 0.0,
    report_json TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

# ─────────────────────────────────────────────────────────────────────────────
# Indexes
# ─────────────────────────────────────────────────────────────────────────────

SQL_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_signals_created   ON signals(created_at);",
    "CREATE INDEX IF NOT EXISTS idx_signals_status    ON signals(status);",
    "CREATE INDEX IF NOT EXISTS idx_signals_direction ON signals(direction);",
    "CREATE INDEX IF NOT EXISTS idx_users_telegram    ON users(telegram_id);",
    "CREATE INDEX IF NOT EXISTS idx_sr_signal         ON signal_recipients(signal_id);",
    "CREATE INDEX IF NOT EXISTS idx_sr_user           ON signal_recipients(user_id);",
    "CREATE INDEX IF NOT EXISTS idx_perf_period       ON performance(period, period_label);",
    "CREATE INDEX IF NOT EXISTS idx_errorlog_at       ON error_log(logged_at);",
]

ALL_DDL = [
    SQL_CREATE_USERS,
    SQL_CREATE_SIGNALS,
    SQL_CREATE_SIGNAL_RECIPIENTS,
    SQL_CREATE_PERFORMANCE,
    SQL_CREATE_SETTINGS,
    SQL_CREATE_ERROR_LOG,
    SQL_CREATE_BROADCASTS,
    SQL_CREATE_BACKTEST_RUNS,
]


# ─────────────────────────────────────────────────────────────────────────────
# Table creation
# ─────────────────────────────────────────────────────────────────────────────

def create_tables(conn: sqlite3.Connection) -> None:
    """
    Execute all DDL statements to create tables and indexes if they don't exist.
    Call once during application startup.
    """
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA journal_mode=WAL;")   # Better concurrency
        cursor.execute("PRAGMA foreign_keys=ON;")
        cursor.execute("PRAGMA synchronous=NORMAL;")

        for ddl in ALL_DDL:
            cursor.execute(ddl)

        for idx in SQL_INDEXES:
            cursor.execute(idx)

        conn.commit()
        logger.info("Database tables and indexes verified / created successfully.")
    except sqlite3.Error as exc:
        conn.rollback()
        logger.error(f"Failed to create database tables: {exc}")
        raise


def seed_default_settings(conn: sqlite3.Connection) -> None:
    """Insert default settings rows if they don't already exist."""
    defaults = {
        "bot_active":           "true",
        "signals_enabled":      "true",
        "maintenance_mode":     "false",
        "welcome_message":      "Welcome to XAUUSD AI Signal Bot!",
        "signals_sent_today":   "0",
        "last_signal_date":     "",
    }
    cursor = conn.cursor()
    for key, value in defaults.items():
        cursor.execute(
            "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?);",
            (key, value),
        )
    conn.commit()
    logger.debug("Default settings seeded.")
